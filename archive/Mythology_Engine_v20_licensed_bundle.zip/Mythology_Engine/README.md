# Mythology Engine

Human‑guided AI documentary production pipeline.

This project generates:
- topic ideas
- scripts
- scene plans
- narration
- video storyboards

A mobile control center allows a human operator to review content
and emit decisions that drive the engine.

## Licensing

This repository uses a **source‑available license**.

You may:
- view the source
- run the system locally
- modify for personal/research use

You may NOT:
- sell the software
- host it as a service
- redistribute commercially

For commercial licensing contact the author.
