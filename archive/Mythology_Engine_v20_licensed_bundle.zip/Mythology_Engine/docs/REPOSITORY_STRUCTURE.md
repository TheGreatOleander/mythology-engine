# Repository Structure

core/            engine logic
media/           rendering + narration
android/         mobile control center
tools/           automation scripts
docs/            technical documentation
legal/           licensing and legal material
examples/        example episode packages
