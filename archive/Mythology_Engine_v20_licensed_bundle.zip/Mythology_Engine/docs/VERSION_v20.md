Version 20 introduces legal structure for future commercialization.

Additions:
- Source‑available license
- Commercial licensing framework
- Contributor license agreement
- Repository structure documentation
