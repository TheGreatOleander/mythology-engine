# Commercial Licensing

The Mythology Engine is available for commercial licensing.

Commercial rights include:
- SaaS deployment
- resale or bundling
- enterprise internal deployment

Contact the author to negotiate a commercial license.

This allows the project to remain source‑available while protecting
the creator's ability to commercialize the system.
