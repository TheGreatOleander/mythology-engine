# Contributor License Agreement (CLA)

By submitting contributions you agree that:

1. You grant the project maintainer the right to use, modify,
   and redistribute your contributions.
2. Your contributions may be included in both open and
   commercial versions of the software.
3. You confirm that you have the legal right to submit the code.

This protects the project from licensing conflicts in the future.
