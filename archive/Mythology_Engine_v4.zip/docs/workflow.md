
Workflow

1 discover topic
2 generate script
3 synthesize narration
4 assemble video
5 generate thumbnail
6 upload
7 collect analytics
