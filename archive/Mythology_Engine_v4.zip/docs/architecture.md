
Architecture

Discovery -> Story -> Media -> Publishing -> Analytics -> Universe
