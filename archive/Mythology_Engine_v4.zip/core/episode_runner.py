
from discovery.topic_discovery import get_topic
from story.hook_generator import generate_hook
from story.narrative_builder import build_story
from media.narration import synthesize
from media.thumbnail_generator import generate_thumbnail_prompt
from media.video_assembler import assemble_video

def run_episode():

    topic = get_topic()

    hook = generate_hook()
    script = build_story(topic)

    narration_audio = synthesize(script)

    thumbnail = generate_thumbnail_prompt(topic)

    assemble_video(script,narration_audio)

    print("Episode generated:",topic)
