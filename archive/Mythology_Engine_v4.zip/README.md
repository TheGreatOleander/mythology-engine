
# Mythology Engine v4

Mythology Engine v4 is an automated narrative production system capable of
generating documentary-style mystery videos for YouTube.

Pipeline

topic discovery
→ hook generation
→ narrative generation
→ narration synthesis (TTS)
→ visual generation
→ ffmpeg video assembly
→ thumbnail generation
→ metadata generation
→ YouTube upload
→ analytics feedback
→ mythology universe update

Run

python scheduler/daily_run.py

This version introduces:

• episode runner pipeline
• FFmpeg render pipeline
• TTS integration layer
• thumbnail generation
• topic discovery
• YouTube upload stub
• analytics hooks
• mythology universe memory

Human review before publishing is recommended.
