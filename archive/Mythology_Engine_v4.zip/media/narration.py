
def synthesize(script):
    print("Synthesizing narration...")
    return "assets/audio/narration.wav"
