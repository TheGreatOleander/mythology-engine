
def generate_thumbnail_prompt(topic):
    return f"dark mysterious cinematic scene of {topic}"
