
def assemble_video(script,audio):
    print("Rendering video using ffmpeg pipeline...")
