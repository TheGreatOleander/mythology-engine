
import random

topics=[
"the Baghdad Battery",
"the Antikythera Mechanism",
"the Voynich Manuscript",
"a lost Siberian expedition",
"a forbidden monastery archive",
"an unexplained underground structure"
]

def get_topic():
    return random.choice(topics)
