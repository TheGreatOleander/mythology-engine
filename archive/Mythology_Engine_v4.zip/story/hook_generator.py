
import random
hooks=[
"In 1924 researchers discovered something impossible.",
"A sealed archive resurfaced after a century.",
"The ruins revealed an artifact historians refuse to discuss."
]
def generate_hook():
    return random.choice(hooks)
