
def build_story(topic):
    return f'''
Background:
Records reference {topic}.

Discovery:
Investigators uncover new fragments.

Twist:
Evidence suggests the discovery connects to something much older.

Conclusion:
The mystery deepens…
'''
