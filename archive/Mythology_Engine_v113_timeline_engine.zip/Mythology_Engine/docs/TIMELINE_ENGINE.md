# Timeline Engine

Tracks chronological events across the mythology universe.

## Purpose

Maintain narrative chronology including:

- discoveries
- historical events
- artifact appearances
- organization actions

This allows stories to reference a structured past.
