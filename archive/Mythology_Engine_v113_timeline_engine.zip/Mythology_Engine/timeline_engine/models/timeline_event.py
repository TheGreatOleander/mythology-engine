class TimelineEvent:
    def __init__(self, title, description, date, episode=None):
        self.title = title
        self.description = description
        self.date = date
        self.episode = episode

    def to_dict(self):
        return {
            "title": self.title,
            "description": self.description,
            "date": self.date,
            "episode": self.episode
        }
