from timeline_engine.storage.timeline_store import TimelineStore

class TimelineEngine:

    def __init__(self):
        self.store = TimelineStore()

    def add_event(self, event):
        self.store.add(event.to_dict())

    def get_timeline(self):
        items = self.store.load()
        return sorted(items, key=lambda x: x.get("date"))

    def find_related(self, keyword):
        items = self.store.load()
        return [i for i in items if keyword.lower() in i.get("description","").lower()]
