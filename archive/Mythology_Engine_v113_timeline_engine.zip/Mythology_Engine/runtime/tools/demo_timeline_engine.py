from timeline_engine.models.timeline_event import TimelineEvent
from timeline_engine.engines.timeline_engine import TimelineEngine
import json

engine = TimelineEngine()

event = TimelineEvent(
    title="Sealing of the Archive",
    description="The Hidden Archive was sealed after discovery of forbidden maps.",
    date="1923",
    episode="Episode_002"
)

engine.add_event(event)

print(json.dumps(engine.get_timeline(), indent=2))
