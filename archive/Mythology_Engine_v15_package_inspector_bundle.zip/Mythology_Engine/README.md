# Mythology Engine – Package Inspector Bundle

A documentary content production engine with an Android control center.

## What this version adds

This version turns the Android app into a stronger review tool.

The mobile control center can now import:
- `manifest.json`
- `scene_plan.json`
- `thumbnail_variants.json`

That means the operator can inspect both the episode identity and the cinematic package on-device.

## Core workflow

topic discovery
→ packaging variants
→ script
→ narration
→ subtitle file
→ scene plan
→ thumbnail variants
→ review bundle
→ human approval
