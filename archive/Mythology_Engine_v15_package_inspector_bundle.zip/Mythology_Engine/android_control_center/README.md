# Android Control Center

This Android app is the mobile cockpit for Mythology Engine.

## What it does now

- dashboard overview
- draft episode queue
- variant pack review
- settings panel
- import `manifest.json`
- import `scene_plan.json`
- import `thumbnail_variants.json`

## Why that matters

The app can now review both:
- episode identity
- cinematic package direction

That makes it a genuine package inspector.
