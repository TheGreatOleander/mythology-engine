package com.jimmydev.mythologycontrolcenter.data

import com.jimmydev.mythologycontrolcenter.model.DashboardStats
import com.jimmydev.mythologycontrolcenter.model.Episode
import com.jimmydev.mythologycontrolcenter.model.PipelineLog
import com.jimmydev.mythologycontrolcenter.model.SettingsState
import com.jimmydev.mythologycontrolcenter.model.VariantPack
import kotlinx.coroutines.delay

class FakeRepository {

    private val episodes = mutableListOf(
        Episode(
            id = "EP_20260309_120101",
            title = "The Mystery Historians Still Cannot Explain About the Piri Reis map",
            topic = "the Piri Reis map",
            status = "draft_review",
            score = 8.2,
            selectedHook = "Some discoveries refuse to stay buried, and the Piri Reis map is one of them.",
            thumbnailPrompt = "the Piri Reis map, one central object, dark archival mood, cinematic fog, high contrast"
        ),
        Episode(
            id = "EP_20260309_120455",
            title = "The Case Of a Buried Mechanical Chamber Still Does Not Add Up",
            topic = "a buried mechanical chamber",
            status = "draft_review",
            score = 8.6,
            selectedHook = "The deeper researchers went into a buried mechanical chamber, the stranger it became.",
            thumbnailPrompt = "a buried mechanical chamber, ancient document texture, red markers, hidden institution vibe"
        ),
        Episode(
            id = "EP_20260309_121300",
            title = "What Made the Baghdad Battery So Difficult To Explain?",
            topic = "the Baghdad Battery",
            status = "ready",
            score = 7.9,
            selectedHook = "At first glance, the Baghdad Battery looks like a footnote. It is not.",
            thumbnailPrompt = "the Baghdad Battery, mysterious artifact on black background, dramatic spotlight"
        )
    )

    private val logs = mutableListOf(
        PipelineLog("12:01:04", "Topic scored at 8.2 and passed novelty filter."),
        PipelineLog("12:01:06", "Variant pack generated with 3 titles, 3 hooks, 3 thumbnail prompts."),
        PipelineLog("12:01:08", "Draft package written to review queue.")
    )

    suspend fun getDashboardStats(settings: SettingsState): DashboardStats {
        delay(120)
        val avg = episodes.map { it.score }.average().takeIf { !it.isNaN() } ?: 0.0
        return DashboardStats(
            episodesGenerated = episodes.size,
            draftsWaitingReview = episodes.count { it.status == "draft_review" },
            averageTopicScore = avg,
            uploadMode = if (settings.uploadEnabled) "Draft upload enabled" else "Review only"
        )
    }

    suspend fun getEpisodes(): List<Episode> {
        delay(120)
        return episodes.toList().sortedByDescending { it.id }
    }

    suspend fun getVariantPackFor(episodeId: String): VariantPack {
        delay(100)
        val ep = episodes.firstOrNull { it.id == episodeId } ?: episodes.first()
        return VariantPack(
            titles = listOf(
                ep.title,
                "What Made ${ep.topic.replaceFirstChar { it.uppercase() }} So Difficult To Explain?",
                "The Case Of ${ep.topic.replaceFirstChar { it.uppercase() }} Still Does Not Add Up"
            ),
            hooks = listOf(
                ep.selectedHook,
                "At first glance, ${ep.topic} looks like a footnote. It is not.",
                "The deeper researchers went into ${ep.topic}, the stranger it became."
            ),
            thumbnailPrompts = listOf(
                ep.thumbnailPrompt,
                "${ep.topic}, mysterious artifact on black background, dramatic spotlight, minimal text energy",
                "${ep.topic}, ancient archive mood, red markers, hidden institution vibe"
            )
        )
    }

    suspend fun runEpisodeNow(): PipelineLog {
        delay(300)
        val next = Episode(
            id = "EP_20260309_12${episodes.size}9${episodes.size}0",
            title = "The Mystery Historians Still Cannot Explain About a Sealed Monastery Archive",
            topic = "a sealed monastery archive",
            status = "draft_review",
            score = 8.8,
            selectedHook = "Some discoveries refuse to stay buried, and a sealed monastery archive is one of them.",
            thumbnailPrompt = "sealed archive, dark documentary style, one central object, cinematic fog"
        )
        episodes.add(0, next)
        val log = PipelineLog("12:09:00", "New episode package created and pushed into review.")
        logs.add(0, log)
        return log
    }

    suspend fun getLogs(): List<PipelineLog> {
        delay(80)
        return logs.toList()
    }
}
