package com.jimmydev.mythologycontrolcenter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jimmydev.mythologycontrolcenter.ui.MythologyApp
import com.jimmydev.mythologycontrolcenter.ui.theme.MythologyControlCenterTheme
import com.jimmydev.mythologycontrolcenter.viewmodel.ControlCenterViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MythologyControlCenterTheme {
                val vm: ControlCenterViewModel = viewModel()
                MythologyApp(vm = vm)
            }
        }
    }
}
