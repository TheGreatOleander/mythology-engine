package com.jimmydev.mythologycontrolcenter.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jimmydev.mythologycontrolcenter.data.FakeRepository
import com.jimmydev.mythologycontrolcenter.model.DashboardStats
import com.jimmydev.mythologycontrolcenter.model.Episode
import com.jimmydev.mythologycontrolcenter.model.PipelineLog
import com.jimmydev.mythologycontrolcenter.model.SettingsState
import com.jimmydev.mythologycontrolcenter.model.VariantPack
import kotlinx.coroutines.launch

class ControlCenterViewModel : ViewModel() {

    private val repo = FakeRepository()

    var settings by mutableStateOf(SettingsState())
        private set

    var stats by mutableStateOf(DashboardStats(0, 0, 0.0, "Review only"))
        private set

    var episodes by mutableStateOf<List<Episode>>(emptyList())
        private set

    var logs by mutableStateOf<List<PipelineLog>>(emptyList())
        private set

    var selectedEpisodeId by mutableStateOf<String?>(null)
        private set

    var selectedVariantPack by mutableStateOf(VariantPack(emptyList(), emptyList(), emptyList()))
        private set

    var isBusy by mutableStateOf(false)
        private set

    init {
        refreshAll()
    }

    fun refreshAll() {
        viewModelScope.launch {
            isBusy = true
            stats = repo.getDashboardStats(settings)
            episodes = repo.getEpisodes()
            logs = repo.getLogs()
            if (selectedEpisodeId == null && episodes.isNotEmpty()) {
                selectEpisode(episodes.first().id)
            } else if (selectedEpisodeId != null) {
                selectedVariantPack = repo.getVariantPackFor(selectedEpisodeId!!)
            }
            isBusy = false
        }
    }

    fun selectEpisode(episodeId: String) {
        selectedEpisodeId = episodeId
        viewModelScope.launch {
            selectedVariantPack = repo.getVariantPackFor(episodeId)
        }
    }

    fun toggleUploadEnabled() {
        settings = settings.copy(uploadEnabled = !settings.uploadEnabled)
        refreshAll()
    }

    fun updateChannelName(name: String) {
        settings = settings.copy(channelName = name)
        refreshAll()
    }

    fun runEpisodeNow() {
        viewModelScope.launch {
            isBusy = true
            repo.runEpisodeNow()
            refreshAll()
            isBusy = false
        }
    }
}
