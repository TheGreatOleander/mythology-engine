# Mythology Control Center (Android)

This is an Android Studio importable Kotlin project for a **Mythology Engine control center**.

It is designed as a mobile cockpit for your content machine:
- dashboard
- episode queue
- variant pack review
- channel settings
- run-now action

## Why an Android app?

Because a content engine wants a cockpit.
Not a pile of scripts with their guts hanging out.

This app is meant to become the operator layer for Mythology Engine:
- review titles, hooks, and thumbnail variants
- inspect draft packages
- trigger runs
- later connect to local files, cloud storage, or APIs

## Current state

This build is a **real Android Studio scaffold**, not a screenshot fantasy.

It includes:
- Gradle project files
- Compose UI
- bottom navigation
- dashboard stats
- episode list
- variant pack viewer
- settings screen
- fake repository for sample data

## What it does right now

Right now it runs with internal demo data so the UI is immediately useful after import.

That means:
- no backend required
- no compile trickery on my side
- easy to open and extend in Android Studio

## Suggested next upgrades

1. connect the app to generated episode `manifest.json` files
2. add local file picker support
3. add review actions like Approve / Reject / Regenerate
4. add YouTube draft metadata editor
5. add run-history and analytics charts
6. add Tasker or Termux bridge for one-tap pipeline runs

## Import

Open the project root in Android Studio and let Gradle sync.

Minimum SDK: 26  
Target SDK: 34  
Language: Kotlin  
UI: Jetpack Compose
