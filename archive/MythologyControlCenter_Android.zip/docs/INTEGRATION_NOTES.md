# Integration Notes

## Local manifest integration
The fastest real upgrade is reading files from your episode package folders:
- manifest.json
- metadata_package.json
- REVIEW.txt

## Android bridge ideas
You could trigger the engine through:
- Termux intent
- Tasker task
- local HTTP endpoint
- cloud function

## Why this matters
The phone becomes the command throne.
You review, trigger, and steer the machine without living in a terminal.
