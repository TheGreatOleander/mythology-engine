package com.mythology.missioncontrol

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val headerStatus = findViewById<TextView>(R.id.txtHeaderStatus)
        val generate = findViewById<Button>(R.id.btnGenerateEpisode)
        val publish = findViewById<Button>(R.id.btnPublishQueue)
        val analytics = findViewById<Button>(R.id.btnAnalytics)
        val audience = findViewById<Button>(R.id.btnAudience)
        val brain = findViewById<Button>(R.id.btnChannelBrain)
        val trends = findViewById<Button>(R.id.btnTrendRadar)

        headerStatus.text = "System nominal • awaiting engine wiring"

        generate.setOnClickListener {
            Toast.makeText(this, "Episode Factory triggered", Toast.LENGTH_SHORT).show()
        }

        publish.setOnClickListener {
            Toast.makeText(this, "Publish Queue opened", Toast.LENGTH_SHORT).show()
        }

        analytics.setOnClickListener {
            Toast.makeText(this, "Performance Feedback opened", Toast.LENGTH_SHORT).show()
        }

        audience.setOnClickListener {
            Toast.makeText(this, "Audience Interface opened", Toast.LENGTH_SHORT).show()
        }

        brain.setOnClickListener {
            Toast.makeText(this, "Channel Brain opened", Toast.LENGTH_SHORT).show()
        }

        trends.setOnClickListener {
            Toast.makeText(this, "Trend Radar opened", Toast.LENGTH_SHORT).show()
        }
    }
}
