# Mythology Mission Control v2

Android Studio project scaffold for the Mythology Engine control interface.

## What's new in v2

- stronger command-console aesthetic
- dashboard header
- status text
- quick metrics cards
- operations panel
- audience / brain / radar buttons
- cleaner theming for future productization

## Import

Open the project folder in Android Studio.

## Purpose

This app is the control layer for Mythology Engine:

- Generate Episode
- Publish Queue
- Channel Analytics
- Audience Interface
- Channel Brain
- Trend Radar

Next step is wiring these actions to the engine through a local API or task runner.
