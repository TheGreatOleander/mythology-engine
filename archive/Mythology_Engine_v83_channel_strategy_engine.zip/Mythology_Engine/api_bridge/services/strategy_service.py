from strategy_engine.engines.strategy_engine import run_strategy

def channel_strategy_service():
    return run_strategy()
