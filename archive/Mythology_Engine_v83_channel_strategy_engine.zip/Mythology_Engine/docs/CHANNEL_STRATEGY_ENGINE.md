# Channel Strategy Engine

This module chooses what the channel should pursue next at the arc level.

## Inputs

- intelligence recommendations
- viral pattern topic clusters

## Outputs

- selected arc theme
- release cadence
- planned episode schedule

## API

GET /channel-strategy

## Why it matters

This shifts the project from:
- generating content

to:
- planning long-term channel direction
