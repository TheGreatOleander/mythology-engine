class StrategyState:
    def __init__(self, current_arc=None, recommended_topic=None, cadence_days=2):
        self.current_arc = current_arc
        self.recommended_topic = recommended_topic
        self.cadence_days = cadence_days

    def to_dict(self):
        return {
            "current_arc": self.current_arc,
            "recommended_topic": self.recommended_topic,
            "cadence_days": self.cadence_days
        }
