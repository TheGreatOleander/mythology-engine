def choose_next_arc(topic_clusters, recommended_topic=None):
    if recommended_topic:
        return {
            "arc_theme": recommended_topic,
            "reason": "Chosen from current intelligence recommendation."
        }

    if topic_clusters:
        top = topic_clusters[0][0]
        return {
            "arc_theme": top,
            "reason": "Chosen from strongest historical topic cluster."
        }

    return {
        "arc_theme": "ancient map discovery",
        "reason": "Fallback default theme."
    }
