import datetime

def build_release_strategy(arc_theme, cadence_days=2, episodes=5):
    start = datetime.date.today()
    schedule = []

    for i in range(episodes):
        publish_date = start + datetime.timedelta(days=i * cadence_days)
        schedule.append({
            "episode_number": i + 1,
            "publish_date": publish_date.isoformat(),
            "status": "planned"
        })

    return {
        "arc_theme": arc_theme,
        "cadence_days": cadence_days,
        "episodes": episodes,
        "schedule": schedule
    }
