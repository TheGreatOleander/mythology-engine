import json
from pathlib import Path
from strategy_engine.planners.arc_selector import choose_next_arc
from strategy_engine.planners.release_planner import build_release_strategy

INTEL = Path("examples/strategy/intelligence.json")
PATTERNS = Path("examples/strategy/viral_patterns.json")

def _load_json(path, default):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return default

def run_strategy():
    intelligence = _load_json(INTEL, {
        "recommended_topic": "oak island treasure mystery",
        "ranked_topics": [["oak island treasure mystery", 9]]
    })

    patterns = _load_json(PATTERNS, {
        "topic_clusters": [["ancient maps", 3], ["oak island", 2]]
    })

    arc = choose_next_arc(
        topic_clusters=patterns.get("topic_clusters", []),
        recommended_topic=intelligence.get("recommended_topic")
    )

    release = build_release_strategy(
        arc_theme=arc["arc_theme"],
        cadence_days=2,
        episodes=5
    )

    return {
        "recommended_topic": intelligence.get("recommended_topic"),
        "top_topic_clusters": patterns.get("topic_clusters", [])[:5],
        "selected_arc": arc,
        "release_strategy": release,
        "generated_at": __import__("datetime").datetime.utcnow().isoformat()
    }
