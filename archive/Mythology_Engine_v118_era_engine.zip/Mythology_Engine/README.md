# Mythology Engine v118 – Era Engine

Adds multi-season era management to the mythology system.

## Run

python runtime/tools/demo_era_engine.py

## Output

- stored eras
- active era list
- suggested current era
