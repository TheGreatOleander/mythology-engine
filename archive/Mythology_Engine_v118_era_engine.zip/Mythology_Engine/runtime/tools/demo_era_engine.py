from era_engine.models.era import Era
from era_engine.engines.era_engine import EraEngine
import json

engine = EraEngine()

era = Era(
    name="Era I – The Archive Awakens",
    theme="the rediscovery of buried knowledge and the return of forbidden cartography",
    seasons=[
        "Season I – The Hidden Archive",
        "Season II – The Order Beneath Stone",
        "Season III – Maps of the Forgotten Roads"
    ],
    status="planned",
    description="The first great era of the mythology, where sealed archives, lost maps, and hidden orders re-enter the world."
)

engine.create_era(era)

print(json.dumps({
    "all_eras": engine.list_eras(),
    "suggested_current_era": engine.suggest_current_era()
}, indent=2))
