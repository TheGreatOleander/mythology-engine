class Era:
    def __init__(self, name, theme, seasons, status="planned", description=""):
        self.name = name
        self.theme = theme
        self.seasons = seasons
        self.status = status
        self.description = description

    def to_dict(self):
        return {
            "name": self.name,
            "theme": self.theme,
            "seasons": self.seasons,
            "status": self.status,
            "description": self.description
        }
