from era_engine.storage.era_store import EraStore

class EraEngine:
    def __init__(self):
        self.store = EraStore()

    def create_era(self, era):
        self.store.add(era.to_dict())
        return era.to_dict()

    def list_eras(self):
        return self.store.load()

    def get_active_eras(self):
        return [e for e in self.store.load() if e.get("status") in ("planned", "active")]

    def suggest_current_era(self):
        active = self.get_active_eras()
        if active:
            return active[0]
        return None
