# Era Engine

Groups multiple seasons into larger mythic periods.

## Purpose

Provide a narrative layer above seasons so the mythology can evolve through:

- eras
- ages
- civilizational phases
- long-term world movements

## Why it matters

This is how a channel stops feeling like a sequence of seasons and starts feeling like a world passing through history.
