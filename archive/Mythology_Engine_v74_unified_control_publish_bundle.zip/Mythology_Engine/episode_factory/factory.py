import json, datetime
from pathlib import Path

def generate_episode(output_dir="examples/generated"):
    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    episode_id = f"EP_{stamp}"
    ep = outdir / episode_id
    ep.mkdir(parents=True, exist_ok=True)

    script = """TITLE: Ancient Map Discovery

## HOOK
A map found beneath centuries of dust may change history.

## STORY
Researchers uncovered symbols pointing to a forgotten trade route.

## MYSTERY
The route may lead to a lost city never recorded in history.
"""

    (ep / "script.txt").write_text(script, encoding="utf-8")
    (ep / "narration.wav").write_text("placeholder narration", encoding="utf-8")
    (ep / "final_video.mp4").write_text("placeholder video", encoding="utf-8")
    (ep / "thumbnail.png").write_text("placeholder thumbnail", encoding="utf-8")

    manifest = {
        "episode_id": episode_id,
        "topic": "Ancient Map Discovery",
        "state": "READY_TO_PUBLISH",
        "video": str(ep / "final_video.mp4"),
        "thumbnail": str(ep / "thumbnail.png"),
        "title": "The Map That Shouldn't Exist",
        "description": "An ancient discovery that may rewrite history."
    }
    (ep / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
