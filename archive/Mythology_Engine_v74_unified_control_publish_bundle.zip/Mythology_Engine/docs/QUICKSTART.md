# Quickstart

## Start the API
`python tools/start_api.py`

## In another terminal run the demo flow
`python tools/demo_flow.py`

## Optional: create a dev token
`python tools/create_dev_token.py`

## Optional: check OAuth
`python tools/check_oauth.py`
