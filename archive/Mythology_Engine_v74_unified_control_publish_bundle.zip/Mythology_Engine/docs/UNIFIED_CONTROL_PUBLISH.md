# Unified Control + Publish Bundle

This version tightens the loop between:

- episode generation
- pipeline tracking
- YouTube intelligence
- OAuth readiness
- publishing

## API

GET /health
GET /pipeline-status
GET /youtube-intelligence
GET /youtube-auth-status
POST /generate-episode
POST /publish

## Flow

1. Generate episode
2. Check pipeline
3. Check auth
4. Publish latest episode

This is the first bundle where those steps live together cleanly.
