#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
python tools/start_api.py
