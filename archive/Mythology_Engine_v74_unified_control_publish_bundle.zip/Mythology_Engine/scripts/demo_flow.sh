#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
python tools/demo_flow.py
