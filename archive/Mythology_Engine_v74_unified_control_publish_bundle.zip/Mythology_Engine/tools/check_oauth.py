from publishing_engine.providers.youtube.oauth_manager import auth_status
import json
print(json.dumps(auth_status(), indent=2))
