import json, urllib.request

BASE = "http://127.0.0.1:8765"

def call(path, method="GET"):
    req = urllib.request.Request(BASE + path, method=method)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode("utf-8"))

print("Health")
print(json.dumps(call("/health"), indent=2))

print("\nGenerate episode")
print(json.dumps(call("/generate-episode", method="POST"), indent=2))

print("\nPipeline")
print(json.dumps(call("/pipeline-status"), indent=2))

print("\nYouTube intelligence")
print(json.dumps(call("/youtube-intelligence"), indent=2))

print("\nOAuth status")
print(json.dumps(call("/youtube-auth-status"), indent=2))

print("\nPublish latest")
print(json.dumps(call("/publish", method="POST"), indent=2))
