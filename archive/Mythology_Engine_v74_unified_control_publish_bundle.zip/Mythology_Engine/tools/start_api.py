from api_bridge.routes.http_server import run_server
run_server()
