from publishing_engine.providers.youtube.oauth_manager import create_dev_token
print(create_dev_token())
