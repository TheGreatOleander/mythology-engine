import json
from pathlib import Path

STORE = Path("examples/pipeline/pipeline.json")

def load_records():
    if STORE.exists():
        return json.loads(STORE.read_text(encoding="utf-8"))
    return []

def save_records(records):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(records, indent=2), encoding="utf-8")
    return str(STORE)

def add_record(record):
    records = load_records()
    records.append(record)
    save_records(records)
    return record

def summarize(records):
    summary = {}
    for r in records:
        state = r.get("state", "UNKNOWN")
        summary.setdefault(state, 0)
        summary[state] += 1
    return summary
