from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from api_bridge.services.studio_service import (
    health_service,
    generate_episode_service,
    pipeline_status_service,
    youtube_intelligence_service,
    oauth_status_service,
    publish_service
)

class Handler(BaseHTTPRequestHandler):
    def send_json(self, data, code=200):
        body = json.dumps(data, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self.send_json(health_service())
        elif self.path == "/pipeline-status":
            self.send_json(pipeline_status_service())
        elif self.path == "/youtube-intelligence":
            self.send_json(youtube_intelligence_service())
        elif self.path == "/youtube-auth-status":
            self.send_json(oauth_status_service())
        else:
            self.send_json({"error":"not_found","path":self.path},404)

    def do_POST(self):
        if self.path == "/generate-episode":
            self.send_json(generate_episode_service())
        elif self.path == "/publish":
            self.send_json(publish_service())
        else:
            self.send_json({"error":"not_found","path":self.path},404)

def run_server(host="127.0.0.1", port=8765):
    server = HTTPServer((host, port), Handler)
    print(f"Mythology Studio API running on http://{host}:{port}")
    server.serve_forever()

if __name__ == "__main__":
    run_server()
