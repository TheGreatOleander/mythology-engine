from studio.engines.studio_engine import StudioEngine

engine = StudioEngine()

def health_service():
    return engine.health()

def generate_episode_service():
    return engine.generate_episode()

def pipeline_status_service():
    return engine.pipeline_status()

def youtube_intelligence_service():
    return engine.youtube_intelligence()

def oauth_status_service():
    return engine.oauth_status()

def publish_service():
    return engine.publish_latest()
