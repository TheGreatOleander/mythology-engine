from youtube_intelligence.providers.youtube.youtube_signal_provider import YouTubeSignalProvider

def build_report():
    provider = YouTubeSignalProvider()
    scores = {}
    for group in [provider.fetch_comment_signals(), provider.fetch_behavior_signals()]:
        for item in group:
            scores.setdefault(item["topic"], 0)
            scores[item["topic"]] += item["weight"]
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return {
        "ranked_topics": ranked,
        "recommended_next_topic": ranked[0][0] if ranked else None
    }
