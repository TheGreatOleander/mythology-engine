class YouTubeSignalProvider:
    def fetch_comment_signals(self):
        return [
            {"topic": "Oak Island treasure mystery", "weight": 5},
            {"topic": "Atlantis evidence", "weight": 3},
            {"topic": "Ark of the Covenant location", "weight": 4}
        ]

    def fetch_behavior_signals(self):
        return [
            {"topic": "Oak Island treasure mystery", "weight": 4},
            {"topic": "Lost Roman map discovery", "weight": 2}
        ]
