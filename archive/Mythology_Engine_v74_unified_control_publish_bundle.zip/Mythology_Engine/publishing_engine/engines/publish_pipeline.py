from publishing_engine.providers.youtube.youtube_uploader import YouTubeUploader

def publish_episode(video, title, description, thumbnail=None):
    return YouTubeUploader().upload(video, title, description, thumbnail)
