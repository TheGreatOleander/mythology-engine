from pathlib import Path
import json

CLIENT_SECRET = Path("secrets/client_secret.json")
TOKEN_FILE = Path("secrets/oauth_token.json")

def auth_status():
    return {
        "client_secret_exists": CLIENT_SECRET.exists(),
        "token_exists": TOKEN_FILE.exists(),
        "client_secret_path": str(CLIENT_SECRET),
        "token_path": str(TOKEN_FILE)
    }

def create_dev_token():
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps({
        "access_token": "DEV_TOKEN",
        "refresh_token": "DEV_REFRESH",
        "scopes": ["https://www.googleapis.com/auth/youtube.upload"]
    }, indent=2), encoding="utf-8")
    return str(TOKEN_FILE)
