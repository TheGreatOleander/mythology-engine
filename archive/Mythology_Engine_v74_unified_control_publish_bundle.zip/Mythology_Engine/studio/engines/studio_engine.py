from episode_factory.factory import generate_episode
from publishing_engine.engines.publish_pipeline import publish_episode
from pipeline_manager.engines.pipeline_store import add_record, load_records, summarize
from youtube_intelligence.engines.intelligence_report import build_report
from publishing_engine.providers.youtube.oauth_manager import auth_status

class StudioEngine:
    def health(self):
        return {"status": "ok", "service": "mythology_studio_engine_v74"}

    def generate_episode(self):
        manifest = generate_episode()
        add_record({
            "episode_id": manifest["episode_id"],
            "topic": manifest["topic"],
            "state": manifest["state"]
        })
        return manifest

    def pipeline_status(self):
        records = load_records()
        return {
            "records": records,
            "summary": summarize(records)
        }

    def youtube_intelligence(self):
        return build_report()

    def oauth_status(self):
        return auth_status()

    def publish_latest(self):
        records = load_records()
        if not records:
            return {"status": "no_episodes", "note": "Generate an episode first."}
        latest = records[-1]
        episode_id = latest["episode_id"]
        base = f"examples/generated/{episode_id}"
        return publish_episode(
            video=f"{base}/final_video.mp4",
            title="The Map That Shouldn't Exist",
            description="An ancient discovery that may rewrite history.",
            thumbnail=f"{base}/thumbnail.png"
        )
