# Mythology Engine v74 – Unified Control + Publish Bundle

This version tightens the operational loop.

## Included

- Studio Engine
- Episode generation
- Pipeline tracking
- YouTube intelligence
- OAuth readiness
- Publishing scaffold
- Packaging basics

## Main API

- `GET /health`
- `GET /pipeline-status`
- `GET /youtube-intelligence`
- `GET /youtube-auth-status`
- `POST /generate-episode`
- `POST /publish`

## Start

`python tools/start_api.py`

## Demo

`python tools/demo_flow.py`
