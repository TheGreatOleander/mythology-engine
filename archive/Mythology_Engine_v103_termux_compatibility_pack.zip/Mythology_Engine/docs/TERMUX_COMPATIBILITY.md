# Mythology Engine – Termux Compatibility

## Honest answer

A lot of the system is compatible with Termux on Android, but not every part is equally comfortable there.

## Strong fit on Termux

- Python orchestration
- JSON pipelines
- prompt / metadata generation
- title and thumbnail planning
- strategy / calendar / story engines
- FFmpeg-based assembly
- release package generation
- manual-first publishing workflows

## Conditional fit on Termux

- local TTS via Piper
- local image generation
- subtitle burn-in
- music mixing

These depend on:
- device RAM
- storage
- CPU / thermal limits
- whether the needed binaries and models are installed

## Weakest fit on pure Termux

- large local image models
- heavy video generation
- some official platform upload APIs
- anything expecting desktop/browser OAuth flows without adjustment

## Best architecture

Use Termux as:
- control room
- orchestrator
- packager
- FFmpeg workstation
- manual or semi-automatic publisher

Use external machines or hosted APIs for:
- heavyweight generation
- some provider auth flows
- large model inference

## Rule of thumb

Termux is excellent for:
- running the brain
- decent for running the hands
- not ideal for being the entire body all the time
