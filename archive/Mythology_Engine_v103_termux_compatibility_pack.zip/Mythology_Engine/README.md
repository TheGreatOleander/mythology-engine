# Mythology Engine v103 – Termux Compatibility Pack

This pack clarifies and prepares the studio for Android Termux usage.

## Included

- Termux environment probe
- runtime path policy
- setup script
- safe-run wrapper
- bootstrap path tool
- compatibility docs

## Start

bash termux_compat/scripts/setup_termux.sh

Then:

python termux_compat/tools/check_termux.py
python termux_compat/tools/bootstrap_paths.py
