import os
import platform
import shutil
import sys

def probe_environment():
    return {
        "platform": platform.platform(),
        "python_version": sys.version.split()[0],
        "is_android_like": "ANDROID_ROOT" in os.environ or "com.termux" in os.environ.get("PREFIX", ""),
        "binaries": {
            "python": shutil.which("python"),
            "ffmpeg": shutil.which("ffmpeg"),
            "git": shutil.which("git"),
            "pkg": shutil.which("pkg"),
            "bash": shutil.which("bash")
        },
        "paths": {
            "home": os.environ.get("HOME"),
            "prefix": os.environ.get("PREFIX"),
            "tmpdir": os.environ.get("TMPDIR")
        }
    }
