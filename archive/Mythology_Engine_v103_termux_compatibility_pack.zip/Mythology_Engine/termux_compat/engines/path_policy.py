from pathlib import Path
import os

def get_runtime_paths():
    home = Path(os.environ.get("HOME", "."))
    base = home / "MythologyStudio"
    return {
        "base": str(base),
        "projects": str(base / "projects"),
        "output": str(base / "output"),
        "models": str(base / "models"),
        "cache": str(base / "cache"),
        "logs": str(base / "logs")
    }
