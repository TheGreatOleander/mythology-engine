#!/data/data/com.termux/files/usr/bin/bash
set -e

pkg update -y
pkg upgrade -y

pkg install -y python git ffmpeg clang make cmake rust
pkg install -y termux-tools libjpeg-turbo libpng freetype

python -m pip install --upgrade pip wheel setuptools

echo ""
echo "Base Termux dependencies installed."
echo "Next steps:"
echo "  1. python termux_compat/tools/check_termux.py"
echo "  2. python termux_compat/tools/bootstrap_paths.py"
echo ""
