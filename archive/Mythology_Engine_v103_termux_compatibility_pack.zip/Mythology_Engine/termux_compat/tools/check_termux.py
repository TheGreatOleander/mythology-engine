from termux_compat.engines.environment_probe import probe_environment
from termux_compat.engines.path_policy import get_runtime_paths
import json

print(json.dumps({
    "environment": probe_environment(),
    "runtime_paths": get_runtime_paths()
}, indent=2))
