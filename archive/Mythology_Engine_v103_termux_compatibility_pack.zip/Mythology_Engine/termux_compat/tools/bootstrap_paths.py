from termux_compat.engines.path_policy import get_runtime_paths
from pathlib import Path
import json

paths = get_runtime_paths()
for p in paths.values():
    Path(p).mkdir(parents=True, exist_ok=True)

print(json.dumps(paths, indent=2))
