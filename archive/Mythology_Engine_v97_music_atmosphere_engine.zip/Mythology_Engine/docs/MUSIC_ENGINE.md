# Music & Atmosphere Engine

Adds background music and ambient sound to generated episodes.

Pipeline extension:

voice narration
→ mood detection / selection
→ music selection
→ voice + music mixing
→ video audio replacement

Music volume is automatically lowered under narration.
