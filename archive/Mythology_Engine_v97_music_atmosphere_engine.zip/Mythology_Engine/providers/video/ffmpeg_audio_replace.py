import subprocess
from pathlib import Path

def replace_audio(video, audio, output):

    Path(output).parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",
        "-i", video,
        "-i", audio,
        "-c:v", "copy",
        "-map", "0:v:0",
        "-map", "1:a:0",
        output
    ]

    subprocess.run(cmd, check=False)

    if not Path(output).exists():
        Path(output).write_text(
            "VIDEO WITH MUSIC PLACEHOLDER\nvideo=" + video + "\naudio=" + audio,
            encoding="utf-8"
        )

    return output
