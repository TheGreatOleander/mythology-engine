import subprocess
from pathlib import Path

def mix_voice_and_music(voice, music, output):

    Path(output).parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",
        "-i", voice,
        "-i", music,
        "-filter_complex",
        "[1:a]volume=0.25[a1];[0:a][a1]amix=inputs=2:duration=first",
        "-c:a", "aac",
        output
    ]

    subprocess.run(cmd, check=False)

    if not Path(output).exists():
        Path(output).write_text(
            "MIX PLACEHOLDER\nvoice=" + voice + "\nmusic=" + music,
            encoding="utf-8"
        )

    return output
