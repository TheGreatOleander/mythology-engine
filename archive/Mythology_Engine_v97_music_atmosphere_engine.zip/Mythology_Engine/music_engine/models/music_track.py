class MusicTrack:

    def __init__(self, name, mood, file_path):
        self.name = name
        self.mood = mood
        self.file_path = file_path

    def to_dict(self):
        return {
            "name": self.name,
            "mood": self.mood,
            "file_path": self.file_path
        }
