from music_engine.models.music_track import MusicTrack

def select_music(mood):

    library = {
        "mystery": "examples/music/mystery_track.mp3",
        "ancient": "examples/music/ancient_ambience.mp3",
        "dramatic": "examples/music/dramatic_pulse.mp3",
        "calm": "examples/music/ambient_pad.mp3"
    }

    path = library.get(mood, library["mystery"])

    return MusicTrack(
        name=mood + "_track",
        mood=mood,
        file_path=path
    )
