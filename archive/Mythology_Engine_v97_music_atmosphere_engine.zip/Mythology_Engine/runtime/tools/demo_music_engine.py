from music_engine.engines.music_selector import select_music
from providers.audio.audio_mixer import mix_voice_and_music
from providers.video.ffmpeg_audio_replace import replace_audio
import json

voice = "examples/output/narration.wav"
video = "examples/output/episode.mp4"

track = select_music("mystery")

mixed_audio = mix_voice_and_music(
    voice,
    track.file_path,
    "examples/output/mixed_audio.m4a"
)

final_video = replace_audio(
    video,
    mixed_audio,
    "examples/output/episode_with_music.mp4"
)

print(json.dumps({
    "music_track": track.to_dict(),
    "mixed_audio": mixed_audio,
    "final_video": final_video
}, indent=2))
