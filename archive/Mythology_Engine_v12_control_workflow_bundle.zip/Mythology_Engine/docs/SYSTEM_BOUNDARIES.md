# System Boundaries

This project intentionally limits its scope.

## Included

The engine manages:

• topic discovery
• narrative scaffolding
• episode packaging
• metadata generation
• subtitle preparation
• review bundles
• operator dashboard

## Explicitly Not Included

The system does not attempt to:

• automatically upload content without review
• impersonate human creators
• mass‑spam content
• generate misleading historical claims

The system supports responsible content creation.

## Design Philosophy

Automation should remove **repetitive labor**, not **creative responsibility**.
