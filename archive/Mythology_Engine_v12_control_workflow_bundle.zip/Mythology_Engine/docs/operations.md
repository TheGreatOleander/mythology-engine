# Operations

## One episode
```bash
python -m scheduler.daily_run
```

## Batch generation
```bash
python -m scheduler.batch_run 5
```

## Review before upload

Check:
- `REVIEW.txt`
- `metadata_package.json`
- `script.txt`

Pick the strongest title / hook / thumbnail combination before publishing.
