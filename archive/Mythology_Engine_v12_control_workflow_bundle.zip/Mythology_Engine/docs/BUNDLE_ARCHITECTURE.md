# Bundle Architecture

The repository contains two major components.

## 1. Mythology Engine (Python)

The engine performs the content pipeline.

Modules include:

• discovery
• story generation
• media preparation
• publishing package generation
• analytics scaffolding

Output is written to:

episodes/EP_XXXX/

Each episode folder contains:

• script.txt
• manifest.json
• metadata_package.json
• subtitles.srt
• REVIEW.txt

## 2. Android Control Center

The Android application acts as the **operator cockpit**.

The app allows the operator to:

• review episode packages
• inspect title / hook variants
• trigger generation runs
• adjust settings

Future versions may connect directly to local files or remote APIs.

## Relationship

Python engine → generates content packages  
Android app → reviews and manages them
