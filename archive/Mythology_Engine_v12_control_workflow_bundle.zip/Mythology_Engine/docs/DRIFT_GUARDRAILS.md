# Drift Guardrails

To prevent conceptual drift, the project maintains several rules.

## Rule 1 — Human Approval Required

The engine never publishes content automatically.

## Rule 2 — Narrative Quality First

Episodes must be designed as structured narratives, not content dumps.

## Rule 3 — Packaging Matters

Each episode must include:

• multiple titles
• multiple hooks
• thumbnail concepts

## Rule 4 — Maintain Focus

The project exists to support documentary storytelling.

Future features must reinforce this mission rather than expand into unrelated domains.
