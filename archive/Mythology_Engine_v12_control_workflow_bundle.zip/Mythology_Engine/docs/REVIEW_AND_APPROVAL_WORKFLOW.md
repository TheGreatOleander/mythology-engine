# Review and Approval Workflow

The system is intentionally built around a **human approval gate**.

Automation prepares an episode package.  
The operator decides whether it should move forward.

## Episode States

draft_generated
→ imported_to_mobile
→ under_review
→ approved_for_publish
→ rejected
→ regenerate_requested

## Operator Actions

Approve
: Accept the episode packaging and move toward publication.

Reject
: Mark the episode as unsuitable for publication.

Regenerate
: Request the engine to create a new variant pack or script.

## Why this exists

The most important risk for automated systems is **quality drift**.

The approval workflow ensures:

- narrative quality
- packaging strength
- channel identity
- human judgment
