# Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m scheduler.daily_run
```

Generated episode bundles appear in `episodes/`.
