# Roadmap

## v8 delivered
- variant packs
- novelty filtering
- topic scoring
- stronger review package
- metadata packaging

## next serious leap
- real TTS
- real thumbnail generation
- source-backed discovery
- YouTube draft upload
- analytics feedback loop that actually changes topic selection
