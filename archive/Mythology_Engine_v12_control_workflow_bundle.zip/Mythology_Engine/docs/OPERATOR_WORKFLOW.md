# Operator Workflow

## Desktop / engine side
1. Run one or more episode generations.
2. Inspect the resulting package folders.
3. Confirm that every package contains:
   - `manifest.json`
   - `metadata_package.json`
   - `script.txt`
   - `REVIEW.txt`

## Mobile / Android side
1. Open Android Control Center.
2. Import a `manifest.json` file from a generated episode package.
3. Review the title, topic, status, and selected packaging direction.
4. Compare variants.
5. Approve, reject, or regenerate externally.

## Why this split exists
The engine is the forge.
The phone is the helm.

Trying to force both jobs into one interface makes the system worse, not better.
