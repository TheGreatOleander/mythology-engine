# Product Definition

## Product name
Mythology Engine

## Companion application
Android Control Center

## One-sentence definition
A human-guided production system for documentary-style mystery videos, with a mobile control layer for reviewing, steering, and managing episode packages.

## Primary user
A single operator or small creative team producing curiosity-driven YouTube content.

## Job to be done
Turn a repeatable production process into a controlled pipeline:

- discover or select a topic
- generate multiple packaging angles
- produce a draft episode package
- review the package from desktop or mobile
- publish only after approval

## Deliverables per episode
Every draft episode package is expected to contain:
- script
- manifest
- metadata package
- subtitle file
- review notes

## Success criteria
The project succeeds when:
- the channel maintains clear identity
- packaging quality improves over time
- human review remains central
- the Android control center meaningfully reduces friction
