# Review Checklist

Before upload, ask:

1. Which of the three titles creates the strongest curiosity gap?
2. Which hook lands hardest in the first 5 seconds?
3. Which thumbnail prompt produces the cleanest single-image concept?
4. Is this topic too similar to the last ten uploads?
5. Does the package feel like mystery, not mush?

If one of those answers is weak, fix it before publishing.
