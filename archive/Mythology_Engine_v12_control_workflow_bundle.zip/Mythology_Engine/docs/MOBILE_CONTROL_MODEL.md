# Mobile Control Model

The Android Control Center is designed to become the **operator console**.

It should support:

• importing episode manifests  
• reviewing variant packs  
• approving or rejecting episodes  
• requesting regeneration  
• viewing pipeline logs  

The phone acts as the steering wheel for the engine.

The engine performs the work.
The operator performs the decisions.
