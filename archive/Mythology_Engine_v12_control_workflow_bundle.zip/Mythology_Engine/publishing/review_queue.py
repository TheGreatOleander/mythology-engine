from pathlib import Path

def write_review(epdir, manifest):
    review = f'''Review Episode
Episode ID: {manifest["episode_id"]}
Topic: {manifest["topic"]}
Selected title: {manifest["selected_title"]}

Title variants:
- {manifest["variants"]["titles"][0]}
- {manifest["variants"]["titles"][1]}
- {manifest["variants"]["titles"][2]}

Hook variants:
- {manifest["variants"]["hooks"][0]}
- {manifest["variants"]["hooks"][1]}
- {manifest["variants"]["hooks"][2]}

Thumbnail prompt variants:
- {manifest["variants"]["thumbnail_prompts"][0]}
- {manifest["variants"]["thumbnail_prompts"][1]}
- {manifest["variants"]["thumbnail_prompts"][2]}

Topic score:
{manifest["topic_score"]}

Status: {manifest["status"]}
'''
    (Path(epdir) / "REVIEW.txt").write_text(review, encoding="utf-8")
