def upload(video, title, description):
    return {"status": "stub", "video": video, "title": title}
