from story.variant_pack import build_variant_pack

def test_variant_pack_count():
    pack = build_variant_pack("the Voynich Manuscript", variant_count=3)
    assert len(pack["titles"]) == 3
    assert len(pack["hooks"]) == 3
    assert len(pack["thumbnail_prompts"]) == 3
