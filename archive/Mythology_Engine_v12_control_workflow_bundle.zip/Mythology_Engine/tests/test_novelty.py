from discovery.novelty_filter import passes_novelty_filter

def test_novelty_filter_blocks_repeat():
    history = [{"topic": "the Voynich Manuscript"}]
    assert passes_novelty_filter("the Voynich Manuscript", history, lookback=10) is False
