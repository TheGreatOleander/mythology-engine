package com.jimmydev.mythologycontrolcenter.data

import com.jimmydev.mythologycontrolcenter.model.Episode
import org.json.JSONObject

object ManifestParser {

    fun parseEpisode(json: String): Episode {
        val obj = JSONObject(json)
        val title = obj.optString("selected_title")
            .ifBlank { obj.optString("title", "Untitled Episode") }
        val topic = obj.optString("topic", "unknown topic")
        val status = obj.optString("status", "imported")
        val selectedHook = obj.optString("selected_hook", "No selected hook in manifest.")
        val selectedThumb = obj.optString(
            "selected_thumbnail_prompt",
            "No selected thumbnail prompt in manifest."
        )

        val score = when {
            obj.has("topic_score") && obj.optJSONObject("topic_score") != null ->
                obj.optJSONObject("topic_score")?.optDouble("weighted_total", 0.0) ?: 0.0
            else -> obj.optDouble("score", 0.0)
        }

        return Episode(
            id = obj.optString("episode_id", "IMPORTED_${System.currentTimeMillis()}"),
            title = title,
            topic = topic,
            status = status,
            score = score,
            selectedHook = selectedHook,
            thumbnailPrompt = selectedThumb,
            imported = true
        )
    }
}
