package com.jimmydev.mythologycontrolcenter.model

data class Episode(
    val id: String,
    val title: String,
    val topic: String,
    val status: String,
    val score: Double,
    val selectedHook: String,
    val thumbnailPrompt: String,
    val imported: Boolean = false
)

data class VariantPack(
    val titles: List<String>,
    val hooks: List<String>,
    val thumbnailPrompts: List<String>
)

data class PipelineLog(
    val timestamp: String,
    val message: String
)

data class SettingsState(
    val channelName: String = "The Hidden Archive",
    val videoResolution: String = "1920x1080",
    val defaultDurationSeconds: Int = 540,
    val uploadEnabled: Boolean = false,
    val variantCount: Int = 3
)

data class DashboardStats(
    val episodesGenerated: Int,
    val draftsWaitingReview: Int,
    val averageTopicScore: Double,
    val uploadMode: String
)
