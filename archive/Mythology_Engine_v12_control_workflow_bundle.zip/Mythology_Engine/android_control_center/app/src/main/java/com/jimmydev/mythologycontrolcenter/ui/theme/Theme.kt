package com.jimmydev.mythologycontrolcenter.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFFD4AF37),
    onPrimary = Color(0xFF111111),
    secondary = Color(0xFF8C6E15),
    background = Color(0xFF101216),
    surface = Color(0xFF171B22),
    onSurface = Color(0xFFF2F2F2)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF7A5A00),
    onPrimary = Color.White,
    secondary = Color(0xFF8C6E15),
    background = Color(0xFFF7F4EC),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF111111)
)

@Composable
fun MythologyControlCenterTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
