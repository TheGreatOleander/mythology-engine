package com.jimmydev.mythologycontrolcenter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jimmydev.mythologycontrolcenter.model.Episode
import com.jimmydev.mythologycontrolcenter.viewmodel.ControlCenterViewModel

private val tabs = listOf("Dashboard", "Episodes", "Variants", "Settings")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MythologyApp(
    vm: ControlCenterViewModel,
    onImportManifest: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(vm.infoMessage) {
        if (vm.infoMessage.isNotBlank()) {
            snackbarHostState.showSnackbar(vm.infoMessage)
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column {
                        Text("Mythology Control Center")
                        Text(
                            text = vm.settings.channelName,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors()
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Text(label.take(1)) },
                        label = { Text(label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            Column(Modifier.fillMaxSize()) {
                if (vm.isBusy) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                when (selectedTab) {
                    0 -> DashboardScreen(vm, onImportManifest)
                    1 -> EpisodesScreen(vm)
                    2 -> VariantsScreen(vm)
                    3 -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(vm: ControlCenterViewModel, onImportManifest: () -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Episodes", vm.stats.episodesGenerated.toString(), Modifier.weight(1f))
                StatCard("Drafts", vm.stats.draftsWaitingReview.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Avg Score", String.format("%.2f", vm.stats.averageTopicScore), Modifier.weight(1f))
                StatCard("Mode", vm.stats.uploadMode, Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Control Deck", style = MaterialTheme.typography.titleMedium)
                    Text("Trigger a fresh package, import a real manifest, and keep the machine aimed at quality instead of sludge.")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.runEpisodeNow() }) {
                            Text("Run Episode Now")
                        }
                        OutlinedButton(onClick = onImportManifest) {
                            Text("Import Manifest")
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Recent Pipeline Logs", style = MaterialTheme.typography.titleMedium)
                    vm.logs.take(5).forEach {
                        Text("• ${it.timestamp}  ${it.message}")
                    }
                }
            }
        }
    }
}

@Composable
fun EpisodesScreen(vm: ControlCenterViewModel) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(vm.episodes) { episode ->
            EpisodeCard(
                episode = episode,
                selected = vm.selectedEpisodeId == episode.id,
                onSelect = { vm.selectEpisode(episode.id) }
            )
        }
    }
}

@Composable
fun VariantsScreen(vm: ControlCenterViewModel) {
    val pack = vm.selectedVariantPack
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Variant Pack", style = MaterialTheme.typography.titleMedium)
                    Text("This is the multiplier. Pick the sharpest bait, not the first bait.")
                }
            }
        }
        item { VariantSection("Title Variants", pack.titles) }
        item { VariantSection("Hook Variants", pack.hooks) }
        item { VariantSection("Thumbnail Prompt Variants", pack.thumbnailPrompts) }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Operator Decision", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.approveEpisode() }) {
                            Text("Approve Episode")
                        }
                        Button(onClick = { vm.rejectEpisode() }) {
                            Text("Reject")
                        }
                        OutlinedButton(onClick = { vm.regenerateEpisode() }) {
                            Text("Regenerate")
                        }
                    }
                }
            }
        }
        
    }
}

@Composable
fun SettingsScreen(vm: ControlCenterViewModel) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Channel Settings", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = vm.settings.channelName,
                        onValueChange = vm::updateChannelName,
                        label = { Text("Channel Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Draft Upload Mode")
                            Text(
                                "Keep this off until real upload wiring exists. Blind automation is how channels become haunted by bad decisions.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = vm.settings.uploadEnabled,
                            onCheckedChange = { vm.toggleUploadEnabled() }
                        )
                    }
                    AssistChip(
                        onClick = { },
                        label = { Text("Resolution: ${vm.settings.videoResolution}") }
                    )
                    AssistChip(
                        onClick = { },
                        label = { Text("Variant Count: ${vm.settings.variantCount}") }
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
fun EpisodeCard(
    episode: Episode,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        onClick = onSelect
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(episode.title, style = MaterialTheme.typography.titleMedium)
            Text("Topic: ${episode.topic}")
            Text("Status: ${episode.status}${if (episode.imported) " • imported" else ""}")
            Text("Topic Score: ${String.format("%.2f", episode.score)}")
            if (selected) {
                Divider()
                Text("Selected Hook:")
                Text(episode.selectedHook, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun VariantSection(title: String, items: List<String>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            items.forEachIndexed { index, item ->
                Text("${index + 1}. $item")
            }
        }
    }
}
