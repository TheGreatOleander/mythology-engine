package com.jimmydev.mythologycontrolcenter

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jimmydev.mythologycontrolcenter.ui.MythologyApp
import com.jimmydev.mythologycontrolcenter.ui.theme.MythologyControlCenterTheme
import com.jimmydev.mythologycontrolcenter.viewmodel.ControlCenterViewModel

class MainActivity : ComponentActivity() {

    private lateinit var vm: ControlCenterViewModel

    private val manifestPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
            vm.importManifestJson(reader.readText())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MythologyControlCenterTheme {
                vm = viewModel()
                MythologyApp(
                    vm = vm,
                    onImportManifest = {
                        manifestPicker.launch(arrayOf("application/json", "text/plain"))
                    }
                )
            }
        }
    }
}
