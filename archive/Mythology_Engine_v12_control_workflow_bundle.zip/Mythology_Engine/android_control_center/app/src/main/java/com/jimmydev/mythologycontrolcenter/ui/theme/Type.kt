package com.jimmydev.mythologycontrolcenter.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
