package com.jimmydev.mythologycontrolcenter.model

data class ReviewDecision(
    val episodeId: String,
    val decision: String,
    val notes: String
)
