# Android Control Center

This Android app is the mobile cockpit for Mythology Engine.

## What it does now
- dashboard overview
- draft episode queue
- variant pack review
- settings panel
- import `manifest.json` from a generated episode package

## Why manifest import matters
The app no longer has to be just a pretty shell with fake data.
It can ingest a real episode package manifest and surface it in the queue.

That is the first real bridge between:
- the Python engine
- the Android control layer

## Expected workflow
1. Generate an episode package with Mythology Engine.
2. On Android, use **Import Manifest**.
3. Pick `manifest.json` from an episode folder.
4. Review the package on-device.

## Note
This is still a scaffold-first app.
Import currently focuses on `manifest.json`.
Later versions should also ingest:
- `metadata_package.json`
- `REVIEW.txt`
- analytics summaries
