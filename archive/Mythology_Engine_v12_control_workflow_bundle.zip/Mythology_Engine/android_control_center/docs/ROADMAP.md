# Roadmap

## v1 in this zip
- Android Studio project
- Kotlin + Gradle
- Compose UI
- dashboard
- episodes list
- variant pack review
- settings
- fake repo
- run-now control

## Next smart moves
- hook to episode manifest files
- add approve/reject actions
- add regeneration actions
- add analytics graphs
- add remote engine endpoint support
- add review notes persistence
