# Architecture

## App shape

The app is intentionally simple and sane.

### Screens
- Dashboard
- Episodes
- Variants
- Settings

### Layers
- `model/` plain data classes
- `data/` repository layer
- `viewmodel/` state orchestration
- `ui/` Compose screens and components

## Why demo data first?

Because a dead UI scaffold is useless.
This boots with believable data so you can:
- see the flow
- shape the UX
- wire the real engine later

## Intended future integration points

- local JSON manifest directory import
- shared storage folder scanning
- REST API for remote engine control
- Termux / Tasker trigger bridge
- analytics feed ingestion
