# Decision Workflow

The Android Control Center now includes operator decision controls.

Buttons:

Approve Episode
Reject Episode
Regenerate

These actions represent the **human checkpoint** in the pipeline.

In future versions these actions should:

• write a decision JSON file
• trigger engine actions through Termux, HTTP, or local scripts
