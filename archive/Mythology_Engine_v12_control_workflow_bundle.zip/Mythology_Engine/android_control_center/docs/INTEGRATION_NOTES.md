# Integration Notes

## Implemented in this version
The app now supports importing a `manifest.json` file through Android's Storage Access Framework.

That means the operator can point the app at a generated episode package and load it into the queue without manually copying values around.

## Immediate next integrations
- import `metadata_package.json`
- import `REVIEW.txt`
- persist imported episodes locally
- add approve / reject state
- connect run actions to Termux / Tasker / HTTP trigger

## Why SAF was chosen
Because it is the sane Android way to open files without hardcoded storage hacks.
