# Manifest Import

This version adds a concrete bridge between the engine and the Android app.

## Supported file
- `manifest.json`

## How it works
1. Tap **Import Manifest** in the dashboard.
2. Use Android's file picker to choose a generated `manifest.json`.
3. The app parses the episode id, topic, title, selected hook, selected thumbnail prompt, and score.
4. The imported episode appears in the queue.

## Why this matters
The app is no longer just a decorative shell.
It can now ingest real engine output.
