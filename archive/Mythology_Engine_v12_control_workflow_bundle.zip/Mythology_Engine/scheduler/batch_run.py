import sys
from core.episode_runner import run_episode

def batch(n: int):
    for _ in range(n):
        manifest = run_episode()
        print("Generated:", manifest["episode_id"], "->", manifest["selected_title"])

if __name__ == "__main__":
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    batch(count)
