from core.episode_runner import run_episode

if __name__ == "__main__":
    manifest = run_episode()
    print("Episode created:", manifest["episode_id"])
    print("Topic:", manifest["topic"])
    print("Selected title:", manifest["selected_title"])
