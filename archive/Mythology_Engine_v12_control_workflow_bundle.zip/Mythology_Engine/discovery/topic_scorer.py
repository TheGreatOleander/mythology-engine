def score_topic(topic: str) -> dict:
    lowered = topic.lower()
    mystery_strength = 8
    visual_potential = 7
    novelty = 7

    if "map" in lowered or "manuscript" in lowered or "archive" in lowered:
        visual_potential = 9
    if "expedition" in lowered or "buried" in lowered:
        mystery_strength = 9

    weighted_total = round((mystery_strength * 0.4) + (visual_potential * 0.3) + (novelty * 0.3), 2)

    return {
        "mystery_strength": mystery_strength,
        "visual_potential": visual_potential,
        "novelty": novelty,
        "weighted_total": weighted_total
    }
