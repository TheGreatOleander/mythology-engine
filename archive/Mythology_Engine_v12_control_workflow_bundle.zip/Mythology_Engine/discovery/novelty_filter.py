def passes_novelty_filter(topic: str, history: list, lookback: int = 10) -> bool:
    recent_topics = [item.get("topic", "").lower() for item in history[-lookback:]]
    return topic.lower() not in recent_topics
