import random

TOPICS = [
    "the Voynich Manuscript",
    "the Antikythera Mechanism",
    "the Baghdad Battery",
    "the Piri Reis map",
    "a sealed monastery archive",
    "a vanished polar expedition",
    "an impossible map fragment",
    "a buried mechanical chamber",
    "a forgotten laboratory beneath a ruin"
]

def get_topic(exclude=None):
    exclude = exclude or []
    options = [t for t in TOPICS if t not in exclude]
    return random.choice(options) if options else random.choice(TOPICS)
