from pathlib import Path

def synthesize(script: str, out: Path):
    out.write_text("placeholder narration", encoding="utf-8")
    return str(out)
