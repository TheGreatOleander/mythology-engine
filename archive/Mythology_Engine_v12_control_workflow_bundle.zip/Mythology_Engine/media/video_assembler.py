from tools.ffmpeg_tools import render_command

def render_video(audio, out):
    cmd = render_command(audio, out)
    out.write_text(cmd, encoding="utf-8")
    return str(out)
