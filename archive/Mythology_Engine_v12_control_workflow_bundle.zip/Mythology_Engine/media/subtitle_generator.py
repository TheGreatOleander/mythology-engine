from pathlib import Path

def generate_subtitles(script: str, out: Path):
    out.write_text("1\n00:00:00,000 --> 00:00:05,000\nPlaceholder subtitle\n", encoding="utf-8")
    return str(out)
