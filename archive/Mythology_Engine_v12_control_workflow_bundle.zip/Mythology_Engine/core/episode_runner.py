from pathlib import Path
import datetime
import json

from core.config import load_config
from core.history import append_history, load_history
from discovery.topic_discovery import get_topic
from discovery.topic_scorer import score_topic
from discovery.novelty_filter import passes_novelty_filter
from story.variant_pack import build_variant_pack
from story.script_builder import build_script
from media.narration import synthesize
from media.subtitle_generator import generate_subtitles
from media.video_assembler import render_video
from publishing.review_queue import write_review
from publishing.metadata_package import write_metadata_package


def run_episode():
    config = load_config()
    history = load_history()

    topic = get_topic()
    if not passes_novelty_filter(topic, history):
        topic = get_topic(exclude=[topic])

    topic_score = score_topic(topic)
    variants = build_variant_pack(topic, variant_count=config.get("variant_count", 3))

    selected_title = variants["titles"][0]
    selected_hook = variants["hooks"][0]
    selected_thumb = variants["thumbnail_prompts"][0]
    script = build_script(topic, selected_hook)

    eid = datetime.datetime.utcnow().strftime("EP_%Y%m%d_%H%M%S")
    epdir = Path("episodes") / eid
    epdir.mkdir(parents=True, exist_ok=True)

    script_file = epdir / "script.txt"
    script_file.write_text(script, encoding="utf-8")

    audio_file = synthesize(script, epdir / "narration.wav")
    video_file = render_video(audio_file, epdir / "video.mp4")
    subtitle_file = generate_subtitles(script, epdir / "subtitles.srt")

    manifest = {
        "episode_id": eid,
        "topic": topic,
        "topic_score": topic_score,
        "selected_title": selected_title,
        "selected_hook": selected_hook,
        "selected_thumbnail_prompt": selected_thumb,
        "variants": variants,
        "script": str(script_file),
        "audio": str(audio_file),
        "video": str(video_file),
        "subtitles": str(subtitle_file),
        "status": "draft_review"
    }

    (epdir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    write_metadata_package(epdir, manifest)
    write_review(epdir, manifest)

    append_history({
        "episode_id": eid,
        "topic": topic,
        "selected_title": selected_title,
        "generated_at_utc": datetime.datetime.utcnow().isoformat() + "Z"
    })

    return manifest
