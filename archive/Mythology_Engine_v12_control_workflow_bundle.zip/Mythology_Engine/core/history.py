import json
from pathlib import Path

HISTORY_PATH = Path("bible/universe_graph.json")

def load_history() -> list:
    if not HISTORY_PATH.exists():
        return []
    data = json.loads(HISTORY_PATH.read_text(encoding="utf-8"))
    return data.get("history", [])

def append_history(item: dict) -> None:
    data = {"history": []}
    if HISTORY_PATH.exists():
        data = json.loads(HISTORY_PATH.read_text(encoding="utf-8"))
    data.setdefault("history", []).append(item)
    HISTORY_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
