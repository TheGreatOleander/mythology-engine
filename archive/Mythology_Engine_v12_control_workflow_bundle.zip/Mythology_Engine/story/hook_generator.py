def generate_hook(topic: str, style: int = 1) -> str:
    if style == 1:
        return f"Some discoveries refuse to stay buried, and {topic} is one of them."
    if style == 2:
        return f"At first glance, {topic} looks like a footnote. It is not."
    return f"The deeper researchers went into {topic}, the stranger it became."
