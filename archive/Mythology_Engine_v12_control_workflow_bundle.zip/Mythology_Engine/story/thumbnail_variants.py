def generate_thumbnail_prompt(topic: str, title: str, style: int = 1) -> str:
    if style == 1:
        return f"{topic}, one central object, dark archival mood, cinematic fog, high contrast"
    if style == 2:
        return f"{topic}, mysterious artifact on black background, dramatic spotlight, minimal text energy"
    return f"{topic}, ancient document texture, red markers, hidden institution vibe, documentary mystery thumbnail"
