from story.title_optimizer import optimize_title
from story.hook_generator import generate_hook
from story.thumbnail_variants import generate_thumbnail_prompt

def build_variant_pack(topic: str, variant_count: int = 3) -> dict:
    titles = []
    hooks = []
    thumbs = []

    for i in range(1, variant_count + 1):
        title = optimize_title(topic, style=i)
        hook = generate_hook(topic, style=i)
        thumb = generate_thumbnail_prompt(topic, title, style=i)
        titles.append(title)
        hooks.append(hook)
        thumbs.append(thumb)

    return {
        "titles": titles,
        "hooks": hooks,
        "thumbnail_prompts": thumbs
    }
