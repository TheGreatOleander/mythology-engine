def build_script(topic: str, hook: str) -> str:
    return f'''
TITLE
{topic.upper()}

HOOK
{hook}

BACKGROUND
Researchers examining {topic} noticed patterns that should not exist.

DISCOVERY
Each investigation uncovered contradictions in accepted explanations.

EVIDENCE
The surviving details do not sit cleanly inside the official story.

TWIST
The case may belong to a much larger hidden pattern.

CLOSING QUESTION
If {topic} is not isolated, what else belongs to the same unseen system?
'''
