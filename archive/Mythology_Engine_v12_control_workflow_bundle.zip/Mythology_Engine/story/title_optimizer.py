def optimize_title(topic: str, style: int = 1) -> str:
    if style == 1:
        return f"The Mystery Historians Still Cannot Explain About {topic}"
    if style == 2:
        return f"What Made {topic} So Difficult To Explain?"
    return f"The Case Of {topic} Still Does Not Add Up"
