# Mythology Engine (Operator Bundle)

This repository contains a **documentary content production system** and a companion
**Android control center**.

The system exists to help a human operator produce mystery-driven documentary videos
through a controlled workflow:

topic discovery
→ title / hook / thumbnail variants
→ narrative script
→ media preparation
→ review bundle
→ human approval
→ publication

## Included components

### Mythology Engine (Python)
Generates episode packages and metadata.

### Android Control Center
A Kotlin / Android Studio app that acts as the mobile operator cockpit.

It is intended to:
- review recent episodes
- inspect title / hook / thumbnail variants
- monitor pipeline state
- import episode manifests directly from generated package folders

## Principle
Automation supports the creator.
It does not replace the creator.

See `docs/` for the canonical system definition.
