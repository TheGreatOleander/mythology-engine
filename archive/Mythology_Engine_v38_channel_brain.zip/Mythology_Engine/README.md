# Mythology Engine v38 – Channel Brain

Adds a strategy layer that decides what episode should be produced next.

Subsystem:

channel_brain/

Capabilities:

- remembers past topics
- avoids repetition
- suggests next episode topic

Tool:

python tools/channel_brain_decide.py
