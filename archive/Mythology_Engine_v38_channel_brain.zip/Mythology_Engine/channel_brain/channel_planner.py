from channel_brain.strategy.strategy_engine import choose_next_topic

def plan_next_episode():
    decision = choose_next_topic()

    return {
        "next_topic": decision["chosen_topic"],
        "strategy_reason": decision["reason"],
        "recommended_action": "Run Episode Factory using this topic."
    }
