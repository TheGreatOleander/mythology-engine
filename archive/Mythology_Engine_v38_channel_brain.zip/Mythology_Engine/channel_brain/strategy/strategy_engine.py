import random
from channel_brain.memory.channel_memory import load_memory, save_memory

TOPIC_POOL = [
    "Ancient maps that shouldn't exist",
    "Strange signals detected from space",
    "Artifacts that defy modern science",
    "Lost civilizations erased from history",
    "Unexplained historical documents",
    "Technology far ahead of its time"
]

def choose_next_topic():
    memory = load_memory()

    available = [t for t in TOPIC_POOL if t not in memory["topics_used"]]
    if not available:
        available = TOPIC_POOL

    topic = random.choice(available)
    memory["topics_used"].append(topic)

    save_memory(memory)

    return {
        "chosen_topic": topic,
        "reason": "Diversify channel topics while avoiding repetition."
    }
