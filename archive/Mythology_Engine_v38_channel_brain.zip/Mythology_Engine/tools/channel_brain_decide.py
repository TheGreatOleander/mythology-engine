from channel_brain.channel_planner import plan_next_episode
import json

plan = plan_next_episode()
print(json.dumps(plan, indent=2))
