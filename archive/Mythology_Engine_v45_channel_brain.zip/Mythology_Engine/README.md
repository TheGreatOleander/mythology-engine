# Mythology Engine v45 – Channel Brain

Channel Brain is the strategic decision system for the channel.

It determines:

- what topic to produce next
- which audience signals matter
- how trends influence production

## Core concept

Trend signals + Audience requests = next episode topic

## Run example

python tools/run_channel_brain.py
