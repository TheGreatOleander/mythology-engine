from channel_brain.engines.decision_engine import choose_next_topic
import json

trend_topics = [
    "Oak Island treasure mystery",
    "Lost Roman map discovery",
    "Antarctica pyramid conspiracy"
]

audience_requests = [
    "Atlantis evidence",
    "Oak Island treasure mystery",
    "Ark of the Covenant location"
]

topic = choose_next_topic(trend_topics, audience_requests)

print(json.dumps({
    "trend_topics": trend_topics,
    "audience_requests": audience_requests,
    "chosen_topic": topic
}, indent=2))
