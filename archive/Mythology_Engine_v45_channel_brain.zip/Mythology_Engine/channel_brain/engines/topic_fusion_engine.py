from channel_brain.models.topic_signal import TopicSignal

def fuse_signals(trend_topics, audience_requests):
    signals = {}

    for t in trend_topics:
        signals[t] = TopicSignal(t, trend_score=5)

    for a in audience_requests:
        if a in signals:
            signals[a].audience_score += 5
        else:
            signals[a] = TopicSignal(a, audience_score=5)

    ranked = sorted(signals.values(), key=lambda s: s.total_score(), reverse=True)

    return ranked
