from channel_brain.engines.topic_fusion_engine import fuse_signals

def choose_next_topic(trends, audience):

    ranked = fuse_signals(trends, audience)

    if not ranked:
        return None

    return ranked[0].topic
