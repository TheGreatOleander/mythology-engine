class TopicSignal:
    def __init__(self, topic, trend_score=0, audience_score=0):
        self.topic = topic
        self.trend_score = trend_score
        self.audience_score = audience_score

    def total_score(self):
        return self.trend_score + self.audience_score
