# Channel Brain

Channel Brain decides:

- what topic to produce next
- which audience signals matter
- how trends influence episode selection

## Signals

Two sources currently:

1. trend radar
2. audience comments

## Fusion

Signals combine into a score.

trend signal = +5
audience request = +5

Topics with both signals win.

## Example

trend: Oak Island
audience: Oak Island

score = 10 → selected
