from optimization_engine.engines.ctr_optimizer import optimize
import json

titles = [
    "The Oak Island Mystery Nobody Can Explain",
    "Did They Finally Solve Oak Island?",
    "Secrets Buried Beneath Oak Island"
]

thumbnails = [
    "treasure_chest_glow.png",
    "mysterious_map.png",
    "ancient_tunnel.png"
]

results = optimize(titles, thumbnails)

top = [r.to_dict() for r in results[:5]]

print(json.dumps({
    "top_creative_pairs": top
}, indent=2))
