# Title + Thumbnail Optimization Engine

This subsystem evaluates combinations of:

- titles
- thumbnails

to estimate click-through-rate potential.

The engine generates combinations and assigns a heuristic CTR score.

Highest scoring combinations become recommended creative pairs.
