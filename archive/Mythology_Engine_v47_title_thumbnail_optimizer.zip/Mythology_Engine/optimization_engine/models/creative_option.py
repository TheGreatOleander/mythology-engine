class CreativeOption:
    def __init__(self, title, thumbnail, score=0):
        self.title = title
        self.thumbnail = thumbnail
        self.score = score

    def to_dict(self):
        return {
            "title": self.title,
            "thumbnail": self.thumbnail,
            "score": self.score
        }
