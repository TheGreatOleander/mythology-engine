import random
from optimization_engine.models.creative_option import CreativeOption

def simulate_ctr_score(title, thumbnail):

    score = 0

    # crude heuristic signals
    if "?" in title:
        score += 2
    if "secret" in title.lower():
        score += 2
    if "mystery" in title.lower():
        score += 2

    score += random.randint(0, 3)

    return score

def optimize(title_options, thumbnail_options):

    results = []

    for t in title_options:
        for th in thumbnail_options:
            score = simulate_ctr_score(t, th)
            results.append(CreativeOption(t, th, score))

    ranked = sorted(results, key=lambda r: r.score, reverse=True)

    return ranked
