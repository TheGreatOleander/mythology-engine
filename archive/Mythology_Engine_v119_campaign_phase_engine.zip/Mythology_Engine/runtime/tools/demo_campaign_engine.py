from campaign_engine.models.campaign import Campaign
from campaign_engine.engines.campaign_engine import CampaignEngine
import json

engine = CampaignEngine()

campaign = Campaign(
    name="Campaign Alpha – The Archive Revelation",
    focus="discovering hidden cartography and the Order of Ash",
    eras=[
        "Era I – The Archive Awakens"
    ],
    status="planned",
    description="Initial campaign focusing on uncovering the hidden archive and the organizations guarding it."
)

engine.create_campaign(campaign)

print(json.dumps({
    "campaigns": engine.list_campaigns(),
    "recommended_focus": engine.recommend_focus()
}, indent=2))
