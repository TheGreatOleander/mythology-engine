# Campaign / Phase Engine

Coordinates long-term content focus across eras.

## Purpose

Campaigns define the operational focus of the channel:

- investigation focus
- myth themes
- discovery goals
- narrative emphasis

Campaigns guide which arcs and episodes should be produced next.
