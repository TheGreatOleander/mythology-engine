# Mythology Engine v119 – Campaign / Phase Engine

Adds campaign-level control for long-term narrative direction.

## Run

python runtime/tools/demo_campaign_engine.py

## Output

- stored campaigns
- recommended narrative focus
