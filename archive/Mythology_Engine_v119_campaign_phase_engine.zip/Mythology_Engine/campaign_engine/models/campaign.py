class Campaign:
    def __init__(self, name, focus, eras, status="planned", description=""):
        self.name = name
        self.focus = focus
        self.eras = eras
        self.status = status
        self.description = description

    def to_dict(self):
        return {
            "name": self.name,
            "focus": self.focus,
            "eras": self.eras,
            "status": self.status,
            "description": self.description
        }
