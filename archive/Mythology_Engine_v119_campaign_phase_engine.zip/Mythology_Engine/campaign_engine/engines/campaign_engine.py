from campaign_engine.storage.campaign_store import CampaignStore

class CampaignEngine:

    def __init__(self):
        self.store = CampaignStore()

    def create_campaign(self, campaign):
        self.store.add(campaign.to_dict())
        return campaign.to_dict()

    def list_campaigns(self):
        return self.store.load()

    def get_active_campaign(self):
        active = [c for c in self.store.load() if c.get("status") in ("active", "planned")]
        if active:
            return active[0]
        return None

    def recommend_focus(self):
        campaign = self.get_active_campaign()
        if not campaign:
            return "No active campaign."
        return f"Content focus: {campaign['focus']}"
