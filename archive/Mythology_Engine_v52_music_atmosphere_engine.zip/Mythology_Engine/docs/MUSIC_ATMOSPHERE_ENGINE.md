Music Bed + Atmosphere Engine

Adds background audio layers to narration.

Features:
- topic-based music selection
- background music mixing
- narration priority in audio mix
- FFmpeg based audio pipeline

Music volume automatically lowered beneath narration.
