from audio_engine.engines.music_mixer import mix_music
from audio_engine.engines.atmosphere_selector import choose_music

topic = "Oak Island treasure mystery"

music = choose_music(topic)

output = mix_music(
    "examples/narration.wav",
    music,
    "examples/narration_with_music.wav"
)

print("Audio mix complete:", output)
