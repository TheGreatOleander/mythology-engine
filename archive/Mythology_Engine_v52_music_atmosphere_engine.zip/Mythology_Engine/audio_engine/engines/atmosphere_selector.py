def choose_music(topic):

    topic = topic.lower()

    if "mystery" in topic or "treasure" in topic:
        return "examples/mystery_music.mp3"

    if "ancient" in topic:
        return "examples/ancient_music.mp3"

    return "examples/default_music.mp3"
