import subprocess

def mix_music(narration, music, output):

    cmd = [
        "ffmpeg",
        "-y",
        "-i", narration,
        "-i", music,
        "-filter_complex",
        "[1:a]volume=0.25[a1];[0:a][a1]amix=inputs=2:duration=first",
        "-c:a", "aac",
        output
    ]

    subprocess.run(cmd)

    return output
