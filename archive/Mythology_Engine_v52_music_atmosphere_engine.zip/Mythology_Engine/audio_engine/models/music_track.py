class MusicTrack:
    def __init__(self, path, mood="mystery", volume=0.3):
        self.path = path
        self.mood = mood
        self.volume = volume
