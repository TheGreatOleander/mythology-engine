Mythology Engine v52 – Music Bed + Atmosphere Engine

Adds background music and atmospheric sound layers.

Workflow:

narration
+ topic-selected music
→ mixed audio track

Run demo:

python tools/demo_music_mix.py

Requires FFmpeg installed.
