def render_scene(scene):
    return {
        "background": "archive_texture",
        "motion": scene.get("motion", "slow_zoom"),
        "text": scene.get("text")
    }
