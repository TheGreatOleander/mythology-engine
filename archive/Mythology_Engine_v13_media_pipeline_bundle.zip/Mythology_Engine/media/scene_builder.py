def build_scenes(script: str):
    scenes = []
    paragraphs = [p.strip() for p in script.split("\n") if p.strip()]

    for p in paragraphs:
        scenes.append({
            "text": p,
            "visual_type": "artifact",
            "motion": "slow_zoom"
        })

    return scenes
