# Mythology Engine v63 – Title + Thumbnail Optimizer

Adds a CTR optimization layer.

Modules:

optimization/title_engine
optimization/thumbnail_engine

Run:

python optimization/tools/run_optimizer.py

This generates ranked title and thumbnail concepts for an episode topic.
