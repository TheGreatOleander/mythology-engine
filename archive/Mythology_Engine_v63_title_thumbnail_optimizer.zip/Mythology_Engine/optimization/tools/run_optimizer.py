from optimization.title_engine.title_generator import generate_titles
from optimization.title_engine.title_ranker import rank_titles
from optimization.thumbnail_engine.thumbnail_generator import generate_thumbnail_prompts
from optimization.thumbnail_engine.thumbnail_ranker import rank_thumbnails
import json

def run(subject):
    titles = generate_titles(subject)
    ranked_titles = rank_titles(titles)

    thumbs = generate_thumbnail_prompts(subject)
    ranked_thumbs = rank_thumbnails(thumbs)

    result = {
        "subject": subject,
        "titles": ranked_titles,
        "thumbnails": ranked_thumbs,
        "best_title": ranked_titles[0]["title"],
        "best_thumbnail_prompt": ranked_thumbs[0]["prompt"]
    }

    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    run("Ancient Map Discovery")
