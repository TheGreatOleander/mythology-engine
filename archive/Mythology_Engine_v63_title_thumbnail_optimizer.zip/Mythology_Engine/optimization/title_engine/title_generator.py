import random

TEMPLATES = [
    "The {subject} That Shouldn't Exist",
    "Archaeologists Stunned by {subject}",
    "The Truth Behind {subject}",
    "{subject}: Discovery That Could Change History",
    "Scientists Can't Explain This {subject}"
]

def generate_titles(subject):
    titles = []
    for t in TEMPLATES:
        titles.append(t.format(subject=subject))
    return titles
