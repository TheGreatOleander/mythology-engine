import random

def rank_titles(titles):
    ranked = []
    for t in titles:
        ranked.append({
            "title": t,
            "score": random.randint(1,100)
        })
    ranked.sort(key=lambda x: x["score"], reverse=True)
    return ranked
