def generate_thumbnail_prompts(subject):
    prompts = [
        f"dramatic cinematic thumbnail of {subject}, glowing artifacts, shocked archaeologist",
        f"mysterious ancient {subject} glowing in darkness documentary thumbnail",
        f"lost civilization map discovery dramatic youtube thumbnail"
    ]
    return prompts
