import random

def rank_thumbnails(prompts):
    results = []
    for p in prompts:
        results.append({
            "prompt": p,
            "score": random.randint(1,100)
        })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results
