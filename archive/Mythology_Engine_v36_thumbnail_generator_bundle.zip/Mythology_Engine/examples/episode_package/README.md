# Example Episode Package

This package contains placeholder assets so the render executor can be tested structurally.

Use it to:
- generate `render_plan.json`
- generate `concat.txt`
- inspect FFmpeg commands
- test dry-run render execution

Replace placeholders before attempting a meaningful live render.
