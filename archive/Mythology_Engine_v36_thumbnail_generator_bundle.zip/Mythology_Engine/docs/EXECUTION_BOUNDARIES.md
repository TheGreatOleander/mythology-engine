# Execution Boundaries

The renderer can now run FFmpeg commands, but only when the episode package contains:

- usable background assets
- usable narration audio
- usable subtitles
- a valid scene plan

The placeholders in `examples/` are for structure and testing, not production quality.
