# TTS Integration

This version adds the first real narration bridge.

## Supported providers

- placeholder
- OpenAI TTS
- ElevenLabs

## Environment

Copy `.env.example` and configure:

- `OPENAI_API_KEY`
- or `ELEVENLABS_API_KEY`
- `ELEVENLABS_VOICE_ID`
- `TTS_PROVIDER`
- `TTS_VOICE`
- `TTS_MODEL`

## Tools

Synthesize narration from a script file:

`python tools/synthesize_script_audio.py <script.txt>`

Quick smoke test:

`python tools/tts_smoke_test.py`

## Notes

- Placeholder mode writes a text artifact for safe development.
- OpenAI mode writes binary audio if credentials are valid.
- ElevenLabs mode writes binary audio if credentials are valid.

This is the first serious step away from placeholder narration.
