# Thumbnail Generation

This module generates YouTube thumbnails.

Providers:

- placeholder (safe development)
- OpenAI image generation

## Example

python tools/generate_thumbnail.py "ancient mysterious map glowing torchlight cinematic" thumb.png

## Tips

Best thumbnails usually contain:

- strong central object
- high contrast lighting
- very few words
- emotional intrigue
