# Voice Direction

The ideal channel voice is:

- calm
- intelligent
- deliberate
- slightly ominous
- never theatrical in a cheesy way

## Good qualities

- documentary restraint
- clean pacing
- quiet confidence
- no hype-man energy

## Bad qualities

- robotic clipping
- overexcited delivery
- exaggerated YouTube shock voice
- fake epic trailer voice for everything

## Recommendation

Start with one restrained voice and keep it consistent.
Consistency builds channel identity faster than novelty does.
