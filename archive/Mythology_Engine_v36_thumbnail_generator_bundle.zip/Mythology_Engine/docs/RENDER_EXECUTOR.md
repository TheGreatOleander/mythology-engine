# Render Executor

This version adds the missing step between a render plan and actual FFmpeg execution.

## New capabilities

- write `concat.txt`
- execute per-scene FFmpeg commands
- execute final concat command
- write `render_report.json`

## Safety model

The executor defaults to **dry run**.

That means:

- commands are generated
- reports are written
- nothing is actually rendered unless `--live` is provided

## Commands

Generate plan:

`python tools/generate_render_plan.py <episode_dir>`

Execute as dry run:

`python tools/execute_render_plan.py <episode_dir>/render_plan.json`

Execute live:

`python tools/execute_render_plan.py <episode_dir>/render_plan.json --live`
