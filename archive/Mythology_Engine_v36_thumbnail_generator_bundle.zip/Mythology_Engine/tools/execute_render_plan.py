import sys
from cinematic_engine.render_executor import (
    load_render_plan,
    write_concat_file,
    execute_scene_commands,
    execute_final_concat,
)
from cinematic_engine.render_report import write_render_report

def main():
    if len(sys.argv) < 2:
        print("Usage: python tools/execute_render_plan.py <render_plan.json> [--live]")
        return

    render_plan_path = sys.argv[1]
    live = "--live" in sys.argv[2:]
    dry_run = not live

    render_plan = load_render_plan(render_plan_path)
    concat_path = write_concat_file(render_plan)
    print("Concat file written:", concat_path)

    scene_results = execute_scene_commands(render_plan, dry_run=dry_run)
    concat_result = execute_final_concat(render_plan, dry_run=dry_run)

    report = write_render_report(render_plan["episode_dir"], scene_results, concat_result)
    print("Render report written:", report)

    if dry_run:
        print("Dry run complete. No FFmpeg commands were executed.")
    else:
        print("Live render attempted. Check render_report.json for results.")

if __name__ == "__main__":
    main()
