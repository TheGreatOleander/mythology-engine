from cinematic_engine.render_plan import write_render_plan
from cinematic_engine.render_executor import load_render_plan, write_concat_file, final_concat_command

if __name__ == "__main__":
    episode_dir = "examples/episode_package"
    render_plan_path = write_render_plan(episode_dir)
    plan = load_render_plan(render_plan_path)
    concat_path = write_concat_file(plan)

    print("Render plan:", render_plan_path)
    print("Concat file:", concat_path)
    print("Final command:")
    print(final_concat_command(plan))
