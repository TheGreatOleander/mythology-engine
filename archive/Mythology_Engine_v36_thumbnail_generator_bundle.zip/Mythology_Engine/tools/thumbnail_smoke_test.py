from thumbnail_engine.thumbnail_manager import generate_thumbnail

prompt = "ancient mysterious map glowing under torchlight cinematic documentary style"

if __name__ == "__main__":
    result = generate_thumbnail(prompt, "examples/test_thumbnail.png")
    print(result)
