from tts_engine.tts_manager import synthesize_text

sample = '''
Some discoveries refuse to stay buried.
And some stories become stranger the longer you look at them.
'''

if __name__ == "__main__":
    result = synthesize_text(sample, "examples/tts_smoke_test_output.mp3")
    print(result)
