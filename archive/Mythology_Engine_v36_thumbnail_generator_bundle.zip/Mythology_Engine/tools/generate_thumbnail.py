import sys
from thumbnail_engine.thumbnail_manager import generate_thumbnail

if __name__ == "__main__":

    if len(sys.argv) < 3:
        print("Usage: python tools/generate_thumbnail.py <prompt> <output_file>")
        raise SystemExit(1)

    prompt = sys.argv[1]
    out = sys.argv[2]

    result = generate_thumbnail(prompt, out)
    print(result)
