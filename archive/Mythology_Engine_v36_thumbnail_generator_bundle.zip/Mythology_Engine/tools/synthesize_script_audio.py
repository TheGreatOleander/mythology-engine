import sys
from pathlib import Path
from tts_engine.tts_manager import synthesize_text

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tools/synthesize_script_audio.py <script.txt> [output_file]")
        raise SystemExit(1)

    script_path = Path(sys.argv[1])
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else script_path.with_suffix(".mp3")

    text = script_path.read_text(encoding="utf-8")
    result = synthesize_text(text=text, output_path=str(output))
    print(result)
