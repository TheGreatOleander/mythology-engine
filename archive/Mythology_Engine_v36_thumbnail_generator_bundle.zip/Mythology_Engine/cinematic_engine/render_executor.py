import json
import subprocess
from pathlib import Path

def load_render_plan(render_plan_path: str) -> dict:
    return json.loads(Path(render_plan_path).read_text(encoding="utf-8"))

def write_concat_file(render_plan: dict) -> str:
    episode_dir = Path(render_plan["episode_dir"])
    concat_path = episode_dir / "concat.txt"
    scene_outputs = [item["output"] for item in render_plan.get("scene_commands", [])]
    lines = [f"file '{Path(p).name}'" for p in scene_outputs]
    concat_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(concat_path)

def execute_scene_commands(render_plan: dict, dry_run: bool = True) -> list:
    results = []
    for item in render_plan.get("scene_commands", []):
        cmd = item["command"]
        if dry_run:
            results.append({
                "scene_index": item["scene_index"],
                "status": "dry_run",
                "command": cmd
            })
            continue

        proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        results.append({
            "scene_index": item["scene_index"],
            "status": "ok" if proc.returncode == 0 else "error",
            "returncode": proc.returncode,
            "stdout": proc.stdout[-1000:],
            "stderr": proc.stderr[-1000:]
        })
    return results

def final_concat_command(render_plan: dict) -> str:
    episode_dir = Path(render_plan["episode_dir"])
    concat_path = episode_dir / "concat.txt"
    audio = episode_dir / "narration.wav"
    subtitles = episode_dir / "subtitles.srt"
    output = episode_dir / "final_video.mp4"

    subtitles_escaped = str(subtitles).replace("\\", "/").replace(":", "\\:")
    return (
        f'ffmpeg -y -f concat -safe 0 -i "{concat_path}" '
        f'-i "{audio}" -vf "subtitles={subtitles_escaped}" '
        f'-c:v libx264 -c:a aac -shortest "{output}"'
    )

def execute_final_concat(render_plan: dict, dry_run: bool = True) -> dict:
    cmd = final_concat_command(render_plan)

    if dry_run:
        return {
            "status": "dry_run",
            "command": cmd
        }

    proc = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return {
        "status": "ok" if proc.returncode == 0 else "error",
        "returncode": proc.returncode,
        "stdout": proc.stdout[-1000:],
        "stderr": proc.stderr[-1000:],
        "command": cmd
    }
