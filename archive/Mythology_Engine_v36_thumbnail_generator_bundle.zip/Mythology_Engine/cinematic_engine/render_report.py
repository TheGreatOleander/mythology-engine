import json
from pathlib import Path

def write_render_report(episode_dir: str, scene_results: list, concat_result: dict) -> str:
    ep = Path(episode_dir)
    path = ep / "render_report.json"
    report = {
        "scene_results": scene_results,
        "concat_result": concat_result
    }
    path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return str(path)
