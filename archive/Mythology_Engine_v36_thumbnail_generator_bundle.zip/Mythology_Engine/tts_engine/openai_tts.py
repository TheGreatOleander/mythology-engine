from pathlib import Path
import requests

def synthesize_openai_tts(text: str, output_path: str, model: str, voice: str, api_key: str) -> dict:
    out = Path(output_path)

    if not api_key:
        out.write_text("missing_openai_api_key", encoding="utf-8")
        return {
            "status": "missing_api_key",
            "provider": "openai",
            "output_path": str(out)
        }

    url = "https://api.openai.com/v1/audio/speech"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "voice": voice,
        "input": text
    }

    try:
        r = requests.post(url, headers=headers, json=payload, timeout=120)
        if r.status_code != 200:
            out.write_text(r.text[:4000], encoding="utf-8")
            return {
                "status": "api_error",
                "provider": "openai",
                "http_status": r.status_code,
                "output_path": str(out)
            }

        out.write_bytes(r.content)
        return {
            "status": "ok",
            "provider": "openai",
            "output_path": str(out),
            "voice": voice,
            "model": model
        }
    except Exception as e:
        out.write_text(str(e), encoding="utf-8")
        return {
            "status": "exception",
            "provider": "openai",
            "output_path": str(out)
        }
