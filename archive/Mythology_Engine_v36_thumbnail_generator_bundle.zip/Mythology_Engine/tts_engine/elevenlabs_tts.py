from pathlib import Path
import requests

def synthesize_elevenlabs_tts(text: str, output_path: str, voice_id: str, api_key: str) -> dict:
    out = Path(output_path)

    if not api_key or not voice_id:
        out.write_text("missing_elevenlabs_config", encoding="utf-8")
        return {
            "status": "missing_api_key_or_voice",
            "provider": "elevenlabs",
            "output_path": str(out)
        }

    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    headers = {
        "xi-api-key": api_key,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg"
    }
    payload = {
        "text": text,
        "model_id": "eleven_multilingual_v2"
    }

    try:
        r = requests.post(url, headers=headers, json=payload, timeout=120)
        if r.status_code != 200:
            out.write_text(r.text[:4000], encoding="utf-8")
            return {
                "status": "api_error",
                "provider": "elevenlabs",
                "http_status": r.status_code,
                "output_path": str(out)
            }

        out.write_bytes(r.content)
        return {
            "status": "ok",
            "provider": "elevenlabs",
            "output_path": str(out),
            "voice_id": voice_id
        }
    except Exception as e:
        out.write_text(str(e), encoding="utf-8")
        return {
            "status": "exception",
            "provider": "elevenlabs",
            "output_path": str(out)
        }
