from pathlib import Path

def synthesize_placeholder_tts(text: str, output_path: str) -> dict:
    out = Path(output_path)
    out.write_text(
        "placeholder_tts_output\n\n" + text,
        encoding="utf-8"
    )
    return {
        "status": "placeholder",
        "provider": "placeholder",
        "output_path": str(out)
    }
