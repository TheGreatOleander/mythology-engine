import os
from pathlib import Path
from tts_engine.openai_tts import synthesize_openai_tts
from tts_engine.elevenlabs_tts import synthesize_elevenlabs_tts
from tts_engine.placeholder_tts import synthesize_placeholder_tts

def synthesize_text(text: str, output_path: str, provider: str | None = None) -> dict:
    provider = provider or os.getenv("TTS_PROVIDER", "placeholder")
    out = Path(output_path)

    if provider == "openai":
        return synthesize_openai_tts(
            text=text,
            output_path=str(out),
            model=os.getenv("TTS_MODEL", "gpt-4o-mini-tts"),
            voice=os.getenv("TTS_VOICE", "alloy"),
            api_key=os.getenv("OPENAI_API_KEY", "")
        )
    if provider == "elevenlabs":
        return synthesize_elevenlabs_tts(
            text=text,
            output_path=str(out),
            voice_id=os.getenv("ELEVENLABS_VOICE_ID", ""),
            api_key=os.getenv("ELEVENLABS_API_KEY", "")
        )

    return synthesize_placeholder_tts(text=text, output_path=str(out))
