# Mythology Engine v36 – Thumbnail Generator

Adds automated thumbnail image generation.

New subsystem:

thumbnail_engine/

Supports:

- OpenAI image generation
- placeholder mode for development

Tools:

python tools/generate_thumbnail.py "<prompt>" thumb.png

Goal:

Turn thumbnail concepts into real visual assets for YouTube publishing.
