import os
from thumbnail_engine.openai_thumbnail import generate_openai_thumbnail
from thumbnail_engine.placeholder_thumbnail import generate_placeholder_thumbnail

def generate_thumbnail(prompt: str, output_path: str, provider: str | None = None):
    provider = provider or os.getenv("THUMB_PROVIDER", "placeholder")

    if provider == "openai":
        return generate_openai_thumbnail(
            prompt=prompt,
            output_path=output_path,
            api_key=os.getenv("OPENAI_API_KEY",""),
            model=os.getenv("THUMB_MODEL","gpt-image-1")
        )

    return generate_placeholder_thumbnail(prompt, output_path)
