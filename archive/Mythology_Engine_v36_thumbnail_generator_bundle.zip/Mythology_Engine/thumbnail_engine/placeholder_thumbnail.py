from pathlib import Path

def generate_placeholder_thumbnail(prompt: str, output_path: str):
    p = Path(output_path)
    p.write_text(
        "PLACEHOLDER THUMBNAIL\n\nPROMPT:\n" + prompt,
        encoding="utf-8"
    )
    return {
        "status":"placeholder",
        "output_path":str(p)
    }
