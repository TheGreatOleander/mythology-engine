import requests
from pathlib import Path

def generate_openai_thumbnail(prompt: str, output_path: str, api_key: str, model: str):
    p = Path(output_path)

    if not api_key:
        p.write_text("missing_api_key", encoding="utf-8")
        return {"status":"missing_api_key","output_path":str(p)}

    url = "https://api.openai.com/v1/images/generations"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": model,
        "prompt": prompt,
        "size": "1024x1024"
    }

    try:
        r = requests.post(url, headers=headers, json=payload, timeout=120)
        if r.status_code != 200:
            p.write_text(r.text[:4000], encoding="utf-8")
            return {"status":"api_error","output_path":str(p)}

        data = r.json()
        img_url = data["data"][0]["url"]

        img = requests.get(img_url, timeout=120)
        p.write_bytes(img.content)

        return {
            "status":"ok",
            "provider":"openai",
            "output_path":str(p)
        }

    except Exception as e:
        p.write_text(str(e), encoding="utf-8")
        return {"status":"exception","output_path":str(p)}
