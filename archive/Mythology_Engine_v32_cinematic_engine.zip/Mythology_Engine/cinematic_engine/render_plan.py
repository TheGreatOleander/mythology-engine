import json
from pathlib import Path
from cinematic_engine.scene_timeline import build_timeline
from cinematic_engine.ffmpeg_builder import build_scene_commands, build_concat_command

def build_render_plan(episode_dir: str) -> dict:
    ep = Path(episode_dir)
    timeline = build_timeline(str(ep / "scene_plan.json"))
    scene_cmds = build_scene_commands(timeline, str(ep / "render_scenes"))

    scene_outputs = [item["output"] for item in scene_cmds]
    concat_cmd = build_concat_command(
        scene_outputs=scene_outputs,
        audio_path=str(ep / "narration.wav"),
        subtitles_path=str(ep / "subtitles.srt"),
        output_video=str(ep / "final_video.mp4")
    )

    plan = {
        "episode_dir": str(ep),
        "timeline": timeline,
        "scene_commands": scene_cmds,
        "concat_command": concat_cmd,
        "output_video": str(ep / "final_video.mp4")
    }
    return plan

def write_render_plan(episode_dir: str) -> str:
    ep = Path(episode_dir)
    plan = build_render_plan(episode_dir)
    path = ep / "render_plan.json"
    path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return str(path)
