from cinematic_engine.render_plan import write_render_plan
import sys

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tools/generate_render_plan.py <episode_dir>")
    else:
        path = write_render_plan(sys.argv[1])
        print("Render plan written to:", path)
