# Cinematic Engine

This module turns a scene plan into a **render plan** for documentary-style video.

## Goal

Take:

- `scene_plan.json`
- `narration.wav`
- `subtitles.srt`

and produce:

- per-scene FFmpeg commands
- final concat command
- `render_plan.json`

## Visual style

The engine uses restrained documentary motion:

- slow zoom in
- slow zoom out
- slow pan left
- slow pan right
- gentle parallax

The target is not spectacle.
The target is watchable, atmospheric motion.

## Workflow

Generate a render plan:

`python tools/generate_render_plan.py <episode_dir>`

Inspect commands:

`python tools/show_render_commands.py <render_plan.json>`
