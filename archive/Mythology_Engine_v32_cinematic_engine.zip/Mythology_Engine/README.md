# Mythology Engine v32 – Cinematic Engine

This version adds the cinematic execution bridge.

## What it adds

- scene timeline builder
- asset mapper
- FFmpeg command builder
- render plan generator
- render workflow docs

## Why it matters

This is the step that starts turning:
- scripts
- scene plans
- subtitles
- narration

into a real documentary-style video pipeline.
