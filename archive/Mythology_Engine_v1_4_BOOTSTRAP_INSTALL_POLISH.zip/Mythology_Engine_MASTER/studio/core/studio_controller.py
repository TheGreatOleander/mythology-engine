from studio.config.loader import load_profile, load_secrets
from studio.providers.provider_registry import ProviderRegistry
from studio.modes.mode_runner import run_mode
from core.orchestrator.master_orchestrator import MasterOrchestrator

class StudioController:
    def __init__(self, profile_path="configs/studio_profile.json", secrets_path="configs/secrets.json"):
        self.profile = load_profile(profile_path)
        self.secrets = load_secrets(secrets_path)
        self.providers = ProviderRegistry(self.profile, self.secrets)
        self.orchestrator = MasterOrchestrator()

    def run(self, mode="manual", action="full-cycle", publish=False) -> dict:
        run_policy = run_mode(mode, action, publish)

        if action == "status":
            return {
                "studio_profile": self.profile,
                "provider_status": self.providers.status(),
                "run_policy": run_policy,
                "next_step": "Inspect configuration, provider readiness, and selected execution mode."
            }

        if action == "providers":
            return {
                "studio_profile": self.profile,
                "provider_status": self.providers.status(),
                "run_policy": run_policy,
                "next_step": "Wire missing providers or proceed in manual-first mode."
            }

        if action == "release-package":
            cycle = self.orchestrator.run_cycle()
            return {
                "studio_profile": self.profile,
                "provider_status": self.providers.status(),
                "run_policy": run_policy,
                "release_package": cycle["release_package"],
                "next_step": "Review release package artifacts before publishing."
            }

        cycle = self.orchestrator.run_cycle()
        return {
            "studio_profile": self.profile,
            "provider_status": self.providers.status(),
            "run_policy": run_policy,
            "cycle_result": cycle,
            "next_step": self._next_step(publish)
        }

    def _next_step(self, publish: bool) -> str:
        if publish:
            return "Attempt publish using wired providers."
        return "Review outputs in examples/releases/ before publishing."
