import shutil
from pathlib import Path

class FFmpegProvider:
    name = "ffmpeg"

    def status(self):
        return {
            "provider": self.name,
            "ready": shutil.which("ffmpeg") is not None,
            "binary": shutil.which("ffmpeg"),
            "capabilities": ["assemble_video", "transcode", "subtitle_burnin", "audio_mux"]
        }

    def assemble_stub(self, output_path="examples/releases/output/assembled_video.txt"):
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("FFMPEG ASSEMBLY PLACEHOLDER", encoding="utf-8")
        return str(out)
