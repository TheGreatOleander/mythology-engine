from mythology_governor.engines.governor_engine import MythologyGovernor
import json

engine = MythologyGovernor()

result = engine.evaluate()

print(json.dumps({
    "evaluated_state": result,
    "persisted_state": engine.current_state()
}, indent=2))
