# Mythology Engine v120 – Mythology Governor

Adds the central narrative governance layer.

## Run

python runtime/tools/demo_governor.py

## Output

- evaluated mythology state
- persisted governor state

## Role

This is the top-level decision brain for:

campaign
→ era
→ season
→ arc
→ next priority
