class GovernorState:
    def __init__(self, active_campaign=None, active_era=None, active_season=None, active_arc=None, next_priority=None):
        self.active_campaign = active_campaign
        self.active_era = active_era
        self.active_season = active_season
        self.active_arc = active_arc
        self.next_priority = next_priority

    def to_dict(self):
        return {
            "active_campaign": self.active_campaign,
            "active_era": self.active_era,
            "active_season": self.active_season,
            "active_arc": self.active_arc,
            "next_priority": self.next_priority
        }
