from pathlib import Path
import json

class GovernorStore:
    def __init__(self, path="examples/governor/governor_state.json"):
        self.path = Path(path)
        if not self.path.exists():
            self.path.write_text("{}", encoding="utf-8")

    def load(self):
        text = self.path.read_text(encoding="utf-8").strip()
        return json.loads(text) if text else {}

    def save(self, state):
        self.path.write_text(json.dumps(state, indent=2), encoding="utf-8")
