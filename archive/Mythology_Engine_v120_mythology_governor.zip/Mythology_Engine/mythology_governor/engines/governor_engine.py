from mythology_governor.models.governor_state import GovernorState
from mythology_governor.storage.governor_store import GovernorStore

class MythologyGovernor:
    def __init__(self):
        self.store = GovernorStore()

    def evaluate(self):
        state = GovernorState(
            active_campaign="Campaign Alpha – The Archive Revelation",
            active_era="Era I – The Archive Awakens",
            active_season="Season I – The Hidden Archive",
            active_arc="The Archive Cycle",
            next_priority="Advance the mystery thread: The Origin of the Impossible Map"
        )
        self.store.save(state.to_dict())
        return state.to_dict()

    def current_state(self):
        return self.store.load()
