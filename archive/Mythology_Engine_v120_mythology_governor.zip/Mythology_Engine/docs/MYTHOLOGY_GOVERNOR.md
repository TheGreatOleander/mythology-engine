# Mythology Governor

The Mythology Governor is the central narrative decision layer.

## Purpose

It decides:

- which campaign is active
- which era is in focus
- which season is currently progressing
- which arc should drive the next episode
- which mystery or payoff should be prioritized next

## Why it matters

This is the conductor of the mythology orchestra.
Without it, the system has structure.
With it, the system has direction.
