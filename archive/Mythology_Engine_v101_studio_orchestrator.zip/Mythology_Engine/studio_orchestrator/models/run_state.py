class RunState:

    def __init__(self):
        self.topic = None
        self.script = None
        self.video = None
        self.thumbnail = None
        self.title = None
        self.published = False

    def to_dict(self):
        return {
            "topic": self.topic,
            "script": bool(self.script),
            "video": bool(self.video),
            "thumbnail": bool(self.thumbnail),
            "title": self.title,
            "published": self.published
        }
