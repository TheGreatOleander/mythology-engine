from studio_orchestrator.models.run_state import RunState

class StudioOrchestrator:

    def __init__(self):
        self.state = RunState()

    def run_cycle(self, topic):

        self.state.topic = topic

        print("1. Generating story script…")
        self.state.script = "script placeholder"

        print("2. Rendering video…")
        self.state.video = "episode.mp4"

        print("3. Generating thumbnail…")
        self.state.thumbnail = "thumbnail.png"

        print("4. Optimizing title…")
        self.state.title = f"{topic} — Historians Can't Explain This"

        print("5. Publishing…")
        self.state.published = True

        return self.state
