# Studio Orchestrator

The Studio Orchestrator runs the full Mythology Engine pipeline.

Pipeline:

topic
→ story generation
→ video production
→ thumbnail creation
→ title optimization
→ publishing

Future versions will wire all subsystem engines together.
