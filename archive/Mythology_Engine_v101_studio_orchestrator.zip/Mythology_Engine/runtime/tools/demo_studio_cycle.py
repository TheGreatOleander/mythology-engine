from studio_orchestrator.engines.studio_orchestrator import StudioOrchestrator
import json

engine = StudioOrchestrator()

state = engine.run_cycle("The Map That Shouldn't Exist")

print(json.dumps(state.to_dict(), indent=2))
