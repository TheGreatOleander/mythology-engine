from season_engine.models.season import Season
from season_engine.engines.season_engine import SeasonEngine
import json

engine = SeasonEngine()

season = Season(
    name="Season I – The Hidden Archive",
    theme="sealed knowledge, forbidden maps, and the first stirrings of the Order of Ash",
    arcs=[
        "The Archive Cycle",
        "The Order of Ash",
        "The Impossible Map"
    ],
    status="planned",
    description="The opening season that establishes the archive, the map, the sigils, and the hidden order behind the sealed vault."
)

engine.create_season(season)

print(json.dumps({
    "all_seasons": engine.list_seasons(),
    "suggested_current_season": engine.suggest_current_season()
}, indent=2))
