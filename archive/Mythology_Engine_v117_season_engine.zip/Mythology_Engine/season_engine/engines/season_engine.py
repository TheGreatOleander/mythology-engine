from season_engine.storage.season_store import SeasonStore

class SeasonEngine:
    def __init__(self):
        self.store = SeasonStore()

    def create_season(self, season):
        self.store.add(season.to_dict())
        return season.to_dict()

    def list_seasons(self):
        return self.store.load()

    def get_active_seasons(self):
        return [s for s in self.store.load() if s.get("status") in ("planned", "active")]

    def suggest_current_season(self):
        active = self.get_active_seasons()
        if active:
            return active[0]
        return None
