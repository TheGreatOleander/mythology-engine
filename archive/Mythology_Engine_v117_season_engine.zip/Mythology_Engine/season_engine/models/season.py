class Season:
    def __init__(self, name, theme, arcs, status="planned", description=""):
        self.name = name
        self.theme = theme
        self.arcs = arcs
        self.status = status
        self.description = description

    def to_dict(self):
        return {
            "name": self.name,
            "theme": self.theme,
            "arcs": self.arcs,
            "status": self.status,
            "description": self.description
        }
