# Mythology Engine v117 – Season Engine

Adds multi-arc season management to the mythology system.

## Run

python runtime/tools/demo_season_engine.py

## Output

- stored seasons
- active season list
- suggested current season
