# Season Engine

Groups multiple mythology arcs into larger thematic seasons.

## Purpose

Provide a narrative layer above arcs so the channel can evolve through:

- seasons
- eras
- thematic campaigns
- larger myth phases

## Why it matters

This is how a channel stops feeling like a list of stories and starts feeling like it moves through ages.
