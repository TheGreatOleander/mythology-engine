# Mythology Engine – Action Loop Bundle

This version activates the first automated reactions to operator decisions.

## New capability

The engine can now:

read decision JSON → determine operator intent → execute action handlers

## Current handlers

approved_for_publish
    publishing stub

rejected
    move episode to rejected archive

regenerate_requested
    trigger regeneration placeholder

## Engine cycle

Run:

python tools/run_engine_cycle.py

The engine will:

scan decision_inbox/
archive processed decisions
execute actions
