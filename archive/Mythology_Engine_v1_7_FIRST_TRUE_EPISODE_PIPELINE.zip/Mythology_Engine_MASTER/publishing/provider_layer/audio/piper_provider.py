import shutil
from pathlib import Path

class PiperProvider:
    name = "piper"

    def status(self):
        return {
            "provider": self.name,
            "ready": shutil.which("piper") is not None,
            "binary": shutil.which("piper"),
            "capabilities": ["tts_narration", "voice_render"]
        }

    def synthesize(self, text, output_path="examples/releases/output/narration.wav"):
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        # Scaffold behavior: write placeholder artifact even if Piper isn't installed.
        # This keeps the pipeline alive while preserving the integration point.
        if not out.exists():
            out.write_text("PIPER PLACEHOLDER\n\n" + text, encoding="utf-8")
        else:
            out.write_text("PIPER PLACEHOLDER\n\n" + text, encoding="utf-8")

        return {
            "executed": shutil.which("piper") is not None,
            "output_path": str(out),
            "mode": "placeholder" if shutil.which("piper") is None else "provider_scaffold"
        }
