from studio.config.loader import load_profile, load_secrets
from studio.providers.provider_registry import ProviderRegistry
from studio.modes.mode_runner import run_mode
from core.orchestrator.master_orchestrator import MasterOrchestrator
from publishing.provider_layer.video.ffmpeg_provider import FFmpegProvider
from publishing.provider_layer.image.sdxl_provider import SDXLProvider
from publishing.provider_layer.audio.piper_provider import PiperProvider
from production.episode_pipeline import EpisodePipeline

class StudioController:

    def __init__(self, profile_path="configs/studio_profile.json", secrets_path="configs/secrets.json"):
        self.profile = load_profile(profile_path)
        self.secrets = load_secrets(secrets_path)
        self.providers = ProviderRegistry(self.profile, self.secrets)
        self.orchestrator = MasterOrchestrator()

        self.ffmpeg = FFmpegProvider()
        self.sdxl = SDXLProvider(
            api_url=self.secrets.get("image_provider_url"),
            api_key=self.secrets.get("image_provider_key")
        )
        self.piper = PiperProvider()
        self.episode_pipeline = EpisodePipeline(
            image_provider=self.sdxl,
            audio_provider=self.piper,
            video_provider=self.ffmpeg
        )

    def run(self, mode="manual", action="full-cycle", publish=False):

        run_policy = run_mode(mode, action, publish)

        if action == "image-test":
            result = self.sdxl.generate_image(
                prompt="ancient hidden archive vault cinematic lighting",
                output_path="examples/releases/output/test_image.png"
            )
            return {
                "provider": "sdxl",
                "result": result,
                "provider_status": self.providers.status(),
                "run_policy": run_policy
            }

        if action == "provider-test":
            test = self.ffmpeg.render_still_video(
                image_path="examples/releases/output/sample_frame.txt",
                output_path="examples/releases/output/assembled_video.mp4",
                duration=3
            )
            return {
                "provider": "ffmpeg",
                "result": test,
                "provider_status": self.providers.status(),
                "run_policy": run_policy
            }

        if action == "episode-test":
            result = self.episode_pipeline.run(
                topic="The Origin of the Impossible Map"
            )
            return {
                "provider_status": self.providers.status(),
                "run_policy": run_policy,
                "episode_pipeline": result,
                "next_step": "Inspect generated artifacts in examples/releases/output and examples/releases/."
            }

        cycle = self.orchestrator.run_cycle()

        return {
            "cycle_result": cycle,
            "provider_status": self.providers.status(),
            "run_policy": run_policy
        }
