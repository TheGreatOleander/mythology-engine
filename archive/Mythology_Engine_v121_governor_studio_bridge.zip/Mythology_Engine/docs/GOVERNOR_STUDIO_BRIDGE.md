# Governor → Studio Bridge

This module connects the Mythology Governor to the Studio Orchestrator.

## Purpose

Turn the narrative brain into an active production driver.

## Flow

Governor decides:
- campaign
- era
- season
- arc
- next priority

Studio receives that state and builds the next episode around it.

## Why it matters

This is the final integration step that makes the Mythology Engine self-coherent.
