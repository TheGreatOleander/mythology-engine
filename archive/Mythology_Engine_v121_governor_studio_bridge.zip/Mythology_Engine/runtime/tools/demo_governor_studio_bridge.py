from governor_bridge.engines.governor_studio_bridge import GovernorStudioBridge
import json

bridge = GovernorStudioBridge()
print(json.dumps(bridge.run(), indent=2))
