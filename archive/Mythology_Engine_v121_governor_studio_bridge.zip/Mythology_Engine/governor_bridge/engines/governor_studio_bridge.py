from mythology_governor.engines.governor_engine import MythologyGovernor
from studio_orchestrator.engines.studio_orchestrator import StudioOrchestrator

class GovernorStudioBridge:
    def __init__(self):
        self.governor = MythologyGovernor()
        self.studio = StudioOrchestrator()

    def run(self):
        state = self.governor.evaluate()
        production = self.studio.run_cycle(state)
        return {
            "governor_state": state,
            "studio_output": production
        }
