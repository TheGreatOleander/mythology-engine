class StudioOrchestrator:
    def run_cycle(self, governor_state):
        topic = governor_state.get("next_priority") or governor_state.get("active_arc") or "Untitled Myth Episode"

        script = (
            f"Campaign: {governor_state.get('active_campaign')}\n"
            f"Era: {governor_state.get('active_era')}\n"
            f"Season: {governor_state.get('active_season')}\n"
            f"Arc: {governor_state.get('active_arc')}\n\n"
            f"Episode Focus: {topic}\n"
            "The Archivist follows the next thread in the mythology."
        )

        return {
            "topic": topic,
            "script": script,
            "video": "episode.mp4",
            "thumbnail": "thumbnail.png",
            "title": f"{topic} — Historians Can't Explain This",
            "published": True
        }
