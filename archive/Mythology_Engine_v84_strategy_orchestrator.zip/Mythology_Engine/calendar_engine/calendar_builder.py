import datetime

def build_calendar(arc, cadence_days):

    start = datetime.date.today()

    schedule = []

    for ep in arc["episodes"]:
        publish_date = start + datetime.timedelta(days=(ep["episode_number"]-1)*cadence_days)

        schedule.append({
            "episode_number": ep["episode_number"],
            "title": ep["title"],
            "publish_date": publish_date.isoformat(),
            "status": "planned"
        })

    return schedule
