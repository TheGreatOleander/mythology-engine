from orchestrator.engines.channel_orchestrator import run_orchestrator

def orchestrator_service():
    return run_orchestrator()
