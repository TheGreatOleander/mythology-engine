# Mythology Engine v84 – Studio Orchestrator

Adds a unified orchestration layer.

Flow:

Strategy Engine
→ Story Arc Generator
→ Content Calendar Builder

Endpoint:

GET /studio-orchestrator
