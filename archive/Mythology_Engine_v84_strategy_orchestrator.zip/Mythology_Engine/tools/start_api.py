from api_bridge.routes.http_server import run
run()
