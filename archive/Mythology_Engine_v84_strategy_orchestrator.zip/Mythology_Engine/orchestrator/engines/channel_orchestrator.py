from strategy_engine.strategy_provider import get_strategy
from story_engine.arc_generator import generate_arc
from calendar_engine.calendar_builder import build_calendar

def run_orchestrator():

    strategy = get_strategy()

    arc = generate_arc(
        topic=strategy["recommended_topic"],
        episodes=strategy["episodes"]
    )

    calendar = build_calendar(
        arc,
        cadence_days=strategy["cadence_days"]
    )

    return {
        "strategy": strategy,
        "arc": arc,
        "calendar": calendar
    }
