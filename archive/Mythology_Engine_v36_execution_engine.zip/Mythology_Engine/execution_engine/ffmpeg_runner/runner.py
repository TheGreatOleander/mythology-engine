import json
import subprocess
from pathlib import Path

def run_render_plan(plan_file):
    plan = json.loads(Path(plan_file).read_text())

    results = []
    for scene in plan.get("scene_commands", []):
        cmd = scene["command"]
        print("Executing:", cmd)
        try:
            subprocess.run(cmd, shell=True, check=True)
            results.append({"scene": scene["scene_index"], "status": "ok"})
        except Exception as e:
            results.append({"scene": scene["scene_index"], "status": "failed", "error": str(e)})

    return results
