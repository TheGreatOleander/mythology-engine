# Mythology Engine v36 – Execution Engine

Adds the first real execution layer.

New modules:

execution_engine/
    ffmpeg_runner/
    tts_runner/
    youtube_oauth/

Tools:

python tools/run_ffmpeg_render.py render_plan.json
python tools/run_tts.py script.txt narration.wav

This version begins turning the system from a planning engine
into an actual production engine.
