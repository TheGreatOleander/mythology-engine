import sys
from execution_engine.ffmpeg_runner.runner import run_render_plan

if len(sys.argv) < 2:
    print("Usage: python tools/run_ffmpeg_render.py <render_plan.json>")
else:
    results = run_render_plan(sys.argv[1])
    print(results)
