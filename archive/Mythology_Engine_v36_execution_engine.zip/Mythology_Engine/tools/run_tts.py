import sys
from execution_engine.tts_runner.tts_runner import generate_tts

if len(sys.argv) < 3:
    print("Usage: python tools/run_tts.py <script_file> <output_audio>")
else:
    print(generate_tts(sys.argv[1], sys.argv[2]))
