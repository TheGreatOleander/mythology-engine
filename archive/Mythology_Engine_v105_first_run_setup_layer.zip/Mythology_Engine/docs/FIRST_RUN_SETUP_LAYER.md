# First-Run Setup Layer

This module makes Mythology Engine easier to install and configure cleanly.

## Purpose

Create the initial configuration boundary between:
- code
- provider choices
- platform choices
- secrets

## Generated files

- studio_config.json
- secrets.example.json
- SETUP_NOTES.txt

## Why it matters

This is the layer that makes the studio feel installable instead of improvised.
It also helps keep project boundaries clean when Mythology Engine eventually hands off
to the future Media PR Engine.
