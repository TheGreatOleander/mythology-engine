# Mythology Engine v105 – First-Run Setup Layer

This version adds the first-run setup and configuration generation layer.

## Run

python runtime/tools/demo_first_run_setup.py

## Output

examples/config/
- studio_config.json
- secrets.example.json
- SETUP_NOTES.txt

## Goal

Make Mythology Engine easier to install, configure, and run in a repeatable way
on Termux, desktop Linux, or other Python-friendly environments.
