def default_setup():
    return {
        "channel_name": "The Hidden Archive",
        "base_dir": "~/MythologyStudio",
        "output_dir": "~/MythologyStudio/output",
        "publish_mode": "manual_first",
        "video_provider": "ffmpeg",
        "audio_provider": "piper",
        "image_provider": "sdxl",
        "primary_platforms": [
            "youtube",
            "youtube_shorts",
            "tiktok",
            "instagram_reels",
            "podcast"
        ]
    }
