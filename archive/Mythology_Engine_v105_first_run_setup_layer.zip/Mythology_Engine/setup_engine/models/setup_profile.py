class SetupProfile:
    def __init__(
        self,
        channel_name,
        base_dir,
        output_dir,
        publish_mode,
        video_provider,
        audio_provider,
        image_provider,
        primary_platforms
    ):
        self.channel_name = channel_name
        self.base_dir = base_dir
        self.output_dir = output_dir
        self.publish_mode = publish_mode
        self.video_provider = video_provider
        self.audio_provider = audio_provider
        self.image_provider = image_provider
        self.primary_platforms = primary_platforms

    def to_dict(self):
        return {
            "channel_name": self.channel_name,
            "base_dir": self.base_dir,
            "output_dir": self.output_dir,
            "publish_mode": self.publish_mode,
            "video_provider": self.video_provider,
            "audio_provider": self.audio_provider,
            "image_provider": self.image_provider,
            "primary_platforms": self.primary_platforms
        }
