from pathlib import Path
import json
from setup_engine.models.setup_profile import SetupProfile
from setup_engine.templates.default_setup_template import default_setup

def build_first_run_config(output_dir="examples/config"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    cfg = default_setup()

    profile = SetupProfile(
        channel_name=cfg["channel_name"],
        base_dir=cfg["base_dir"],
        output_dir=cfg["output_dir"],
        publish_mode=cfg["publish_mode"],
        video_provider=cfg["video_provider"],
        audio_provider=cfg["audio_provider"],
        image_provider=cfg["image_provider"],
        primary_platforms=cfg["primary_platforms"]
    )

    config_path = out / "studio_config.json"
    secrets_path = out / "secrets.example.json"
    readme_path = out / "SETUP_NOTES.txt"

    config_path.write_text(json.dumps(profile.to_dict(), indent=2), encoding="utf-8")
    secrets_path.write_text(json.dumps({
        "youtube_client_id": "YOUR_CLIENT_ID",
        "youtube_client_secret": "YOUR_CLIENT_SECRET",
        "tiktok_api_key": "YOUR_TIKTOK_KEY",
        "image_provider_key": "YOUR_IMAGE_PROVIDER_KEY",
        "audio_provider_key": "YOUR_AUDIO_PROVIDER_KEY"
    }, indent=2), encoding="utf-8")
    readme_path.write_text(
        "FIRST RUN SETUP\n\n"
        "1. Copy secrets.example.json to a real secrets file outside version control.\n"
        "2. Adjust studio_config.json to match your environment.\n"
        "3. Set publish_mode to manual_first until providers are wired.\n"
        "4. Keep Mythology Engine and the future Media PR Engine separate.\n",
        encoding="utf-8"
    )

    return {
        "config_file": str(config_path),
        "secrets_example": str(secrets_path),
        "notes_file": str(readme_path),
        "config": profile.to_dict()
    }
