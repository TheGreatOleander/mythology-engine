This folder is the sample output target for first-run setup generation.
