from setup_engine.engines.setup_builder import build_first_run_config
import json

print(json.dumps(build_first_run_config(), indent=2))
