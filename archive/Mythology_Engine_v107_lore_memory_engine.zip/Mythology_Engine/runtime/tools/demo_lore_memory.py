from lore_memory.models.lore_item import LoreItem
from lore_memory.engines.lore_engine import LoreEngine
import json

engine = LoreEngine()

item = LoreItem(
    name="The Impossible Map",
    category="artifact",
    description="A parchment map discovered beneath a forgotten archive.",
    episode_ref="Episode_001"
)

engine.record_lore(item)

results = engine.search("map")

print(json.dumps(results, indent=2))
