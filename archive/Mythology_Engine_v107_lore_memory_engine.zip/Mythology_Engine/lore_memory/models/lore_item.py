class LoreItem:
    def __init__(self, name, category, description, episode_ref=None):
        self.name = name
        self.category = category
        self.description = description
        self.episode_ref = episode_ref

    def to_dict(self):
        return {
            "name": self.name,
            "category": self.category,
            "description": self.description,
            "episode_ref": self.episode_ref
        }
