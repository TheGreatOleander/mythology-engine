from lore_memory.storage.lore_store import LoreStore

class LoreEngine:

    def __init__(self):
        self.store = LoreStore()

    def record_lore(self, lore_item):
        self.store.add(lore_item.to_dict())

    def search(self, keyword):
        items = self.store.load()
        return [i for i in items if keyword.lower() in i["description"].lower()]
