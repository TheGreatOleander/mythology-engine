# Mythology Engine v107 – Lore Memory Engine

Adds persistent memory for mythological artifacts, mysteries, and story elements.

## Run

python runtime/tools/demo_lore_memory.py

## Output

Stored lore items searchable across episodes.
