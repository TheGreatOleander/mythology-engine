# Lore Memory Engine

This module provides persistent memory for the Mythology Engine universe.

## Purpose

Maintain continuity across episodes by storing:

- artifacts
- locations
- mysteries
- characters
- historical fragments

## Why it matters

Instead of isolated episodes, the channel becomes a growing mythology.
