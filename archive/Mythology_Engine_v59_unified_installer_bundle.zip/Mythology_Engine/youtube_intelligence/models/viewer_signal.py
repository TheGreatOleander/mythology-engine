class ViewerSignal:
    def __init__(self, topic, source="comment", weight=1, note=""):
        self.topic = topic
        self.source = source
        self.weight = weight
        self.note = note
