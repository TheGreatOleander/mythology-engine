from youtube_intelligence.providers.youtube.youtube_signal_provider import YouTubeSignalProvider

def collect_all_signals():
    provider = YouTubeSignalProvider()
    return {
        "comment_signals": provider.fetch_comment_signals(),
        "behavior_signals": provider.fetch_behavior_signals()
    }
