class YouTubeSignalProvider:
    def fetch_comment_signals(self):
        return [
            {"topic": "Oak Island treasure mystery", "source": "comment", "weight": 5},
            {"topic": "Atlantis evidence", "source": "comment", "weight": 3},
            {"topic": "Ark of the Covenant location", "source": "comment", "weight": 4}
        ]

    def fetch_behavior_signals(self):
        return [
            {"topic": "Oak Island treasure mystery", "source": "watch_pattern", "weight": 4},
            {"topic": "Lost Roman map discovery", "source": "watch_pattern", "weight": 2}
        ]
