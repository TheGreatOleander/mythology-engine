SETUP_QUESTIONS = [
    {"key": "channel_name", "prompt": "Channel name", "default": "The Hidden Archive"},
    {"key": "contact_email", "prompt": "Contact email", "default": ""},
    {"key": "output_dir", "prompt": "Output directory for episodes", "default": "episodes"},
    {"key": "writing_provider", "prompt": "Writing provider", "default": "openai"},
    {"key": "tts_provider", "prompt": "TTS provider", "default": "piper"},
    {"key": "image_provider", "prompt": "Image provider", "default": "sdxl"},
    {"key": "publish_provider", "prompt": "Publish provider", "default": "manual"},
    {"key": "primary_platform", "prompt": "Primary platform target", "default": "youtube"},
    {"key": "youtube_client_secret_path", "prompt": "Path to YouTube OAuth client secret", "default": "secrets/client_secret.json"},
    {"key": "youtube_token_path", "prompt": "Path to YouTube OAuth token", "default": "secrets/oauth_token.json"},
    {"key": "openai_api_key", "prompt": "OpenAI API key (blank if unused)", "default": ""},
    {"key": "elevenlabs_api_key", "prompt": "ElevenLabs API key (blank if unused)", "default": ""}
]
