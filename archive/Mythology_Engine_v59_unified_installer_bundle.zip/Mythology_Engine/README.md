# Mythology Engine v59 – Unified Installer Bundle

This bundle keeps the studio architecture together while adding the first-run installer.

## Includes

- Mission Control
- Episode Factory
- Provider Layer
- Channel Brain
- Learning Loop
- Optimization Engine
- Pipeline Manager
- YouTube Intelligence
- First-Run Installer

## Start here

Run:

`python tools/first_run_install.py`

Then:

`python tools/demo_full_system.py`

and

`python tools/run_youtube_intelligence.py`
