# Unified Installation

This unified bundle includes a first-run installer.

## Run

`python tools/first_run_install.py`

## It creates

- `secrets/local_secrets.json`
- `config/runtime_config.json`
- `.gitignore`

## Then test the system

- `python tools/demo_full_system.py`
- `python tools/run_youtube_intelligence.py`
