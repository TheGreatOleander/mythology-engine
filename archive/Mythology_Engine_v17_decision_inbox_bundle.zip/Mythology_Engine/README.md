# Mythology Engine – Decision Inbox Bundle

This version closes the control loop.

The Android app produces decision JSON.
The engine now reads those decisions automatically.

## Loop

engine
→ episode package
→ phone review
→ decision JSON
→ decision inbox
→ engine reacts

## Decision directory

decision_inbox/

Drop JSON decision files here to simulate operator output.
