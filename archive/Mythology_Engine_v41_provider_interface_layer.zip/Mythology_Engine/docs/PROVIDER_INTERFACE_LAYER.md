# Provider Interface Layer

This module makes Mythology Engine provider-agnostic.

## Goal

The rest of the system should not care whether a capability is supplied by:
- a local engine
- a cloud API
- a manual fallback

## Supported provider groups

- writing
- tts
- image
- publish

## Why this matters

Without a provider layer, the codebase gets tangled quickly.

With a provider layer, operators can choose setups like:

### Local Studio
- local LLM
- Piper TTS
- SDXL
- manual publishing

### Cloud Studio
- OpenAI writing
- ElevenLabs
- DALL-E
- YouTube upload

### Hybrid Studio
- OpenAI writing
- Piper TTS
- SDXL
- manual publishing

## Registry

The provider registry reads local settings and returns the correct provider objects.
