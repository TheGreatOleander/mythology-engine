# Mythology Engine v41 – Provider Interface Layer

This version adds the provider layer.

## New capability

Core engine modules can now select providers for:

- writing
- narration / TTS
- image generation
- publishing

based on local configuration.

## Main files

- `providers/registry.py`
- `providers/config/settings_loader.py`
- `providers/writing/*`
- `providers/tts/*`
- `providers/image/*`
- `providers/publish/*`

## Test it

`python tools/test_provider_layer.py`

## Why it matters

This makes the system modular, swappable, and much more product-ready.
