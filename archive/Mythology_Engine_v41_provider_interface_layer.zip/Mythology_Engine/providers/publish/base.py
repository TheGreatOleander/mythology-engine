class BasePublishProvider:
    name = "base"

    def upload(self, video_path: str, title: str, description: str, thumbnail_path: str | None = None) -> dict:
        raise NotImplementedError
