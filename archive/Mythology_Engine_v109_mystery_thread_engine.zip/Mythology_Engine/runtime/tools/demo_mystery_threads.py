from mystery_threads.models.mystery_thread import MysteryThread
from mystery_threads.engines.thread_engine import MysteryThreadEngine
import json

engine = MysteryThreadEngine()

thread = MysteryThread(
    name="The Origin of the Impossible Map",
    description="Where did the map discovered in Episode_001 actually come from?",
    last_episode="Episode_001"
)

engine.open_thread(thread)

suggestion = engine.suggest_revisit()

print(json.dumps(suggestion, indent=2))
