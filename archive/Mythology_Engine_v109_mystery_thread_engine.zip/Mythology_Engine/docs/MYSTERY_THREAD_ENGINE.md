# Mystery Thread Engine

Tracks unresolved mysteries across episodes.

## Purpose

Maintain long-term narrative tension by remembering open questions.

Examples:

- Where did the map originate?
- Who created the sigil?
- Why was the archive sealed?

These threads can be revisited in future episodes.
