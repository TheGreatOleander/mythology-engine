from mystery_threads.storage.thread_store import ThreadStore

class MysteryThreadEngine:

    def __init__(self):
        self.store = ThreadStore()

    def open_thread(self, thread):
        self.store.add(thread.to_dict())

    def get_open_threads(self):
        items = self.store.load()
        return [i for i in items if i.get("status") == "open"]

    def suggest_revisit(self):
        open_threads = self.get_open_threads()
        if not open_threads:
            return None
        return open_threads[0]
