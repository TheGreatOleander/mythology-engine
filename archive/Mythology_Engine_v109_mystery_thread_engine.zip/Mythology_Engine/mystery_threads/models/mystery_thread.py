class MysteryThread:

    def __init__(self, name, description, status="open", last_episode=None):
        self.name = name
        self.description = description
        self.status = status
        self.last_episode = last_episode

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "last_episode": self.last_episode
        }
