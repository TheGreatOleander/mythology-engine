# FFmpeg Render Pipeline

This bundle introduces the first real video assembly pipeline.

Flow:

script
→ generate narration placeholder
→ combine image + audio
→ output MP4 using FFmpeg

Replace the audio stub with a real TTS provider to produce
fully automated narrated videos.
