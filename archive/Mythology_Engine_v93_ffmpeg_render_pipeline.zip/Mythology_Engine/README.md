# Mythology Engine v93 – FFmpeg Render Pipeline

This version introduces the first real media assembly step.

## Features

- FFmpeg video renderer
- runtime render engine
- demo render script

## Run

python runtime/tools/demo_render.py

## Result

Produces:

examples/output/final_video.mp4

(using a still image + narration placeholder)
