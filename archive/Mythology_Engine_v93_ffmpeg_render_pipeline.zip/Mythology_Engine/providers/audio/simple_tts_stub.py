from pathlib import Path

class SimpleTTSStub:

    def generate_audio(self, script, output_path):

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        Path(output_path).write_text(
            "AUDIO PLACEHOLDER\n\n" + script,
            encoding="utf-8"
        )

        return output_path
