from providers.video.ffmpeg_renderer import FFmpegRenderer
from providers.audio.simple_tts_stub import SimpleTTSStub
from pathlib import Path

class RenderEngine:

    def __init__(self):
        self.video = FFmpegRenderer()
        self.audio = SimpleTTSStub()

    def render(self, image, script, output_dir):

        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        audio_file = self.audio.generate_audio(
            script,
            str(out / "narration.txt")
        )

        video_file = self.video.assemble_video(
            image,
            audio_file,
            str(out / "final_video.mp4")
        )

        return {
            "audio": audio_file,
            "video": video_file
        }
