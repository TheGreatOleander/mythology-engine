from runtime.engine.render_engine import RenderEngine
import json

script = '''
TITLE: The Map That Shouldn't Exist

This map may not be possible.

Historians believed the route was lost forever...
'''

image = "examples/input/test_image.png"

engine = RenderEngine()

result = engine.render(
    image=image,
    script=script,
    output_dir="examples/output"
)

print(json.dumps(result, indent=2))
