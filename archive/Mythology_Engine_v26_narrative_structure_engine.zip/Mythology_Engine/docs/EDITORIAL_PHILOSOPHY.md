# Editorial Philosophy

The human stays in the loop because judgment matters.

The machine helps with:
- structure
- iteration
- recall
- packaging
- production logistics

The human remains responsible for:
- taste
- tone
- truthfulness
- restraint
- brand identity

The Narrative Structure Engine exists to keep the writing compelling without turning it into noise.
