# Channel Voice Guide

## Desired voice

- calm
- intelligent
- slightly ominous
- restrained
- investigative

## Avoid

- shouting
- meme energy
- fake certainty
- empty grandeur
- mechanical repetition

## Model sentence

"Some discoveries refuse to stay buried, and this one may be stranger than most."
