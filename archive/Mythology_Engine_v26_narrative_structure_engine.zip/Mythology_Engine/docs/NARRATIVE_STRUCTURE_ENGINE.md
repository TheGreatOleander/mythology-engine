# Narrative Structure Engine

This module prevents scripts from collapsing into shapeless AI rambling.

## Core principle

Every episode should follow a deliberate storytelling arc.

Default arc:

- HOOK
- THE MYSTERY
- HISTORICAL CONTEXT
- THE STRANGE DETAILS
- THEORIES
- THE TWIST
- THE BIG QUESTION

## Why this matters

Documentary mystery channels succeed when they control:
- pacing
- curiosity
- escalation
- payoff
- unresolved tension

A weak script meanders.
A strong script advances.

## Tools

Generate script:
`python tools/generate_structured_script.py`

Generate outline JSON:
`python tools/generate_outline_json.py`
