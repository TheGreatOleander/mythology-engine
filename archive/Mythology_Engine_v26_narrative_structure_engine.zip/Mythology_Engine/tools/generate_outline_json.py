import json
from narrative_engine.story_arc_engine import build_story_outline

if __name__ == "__main__":
    topic = input("Topic: ").strip()
    raw = input("Optional fragment seeds (separate with |): ").strip()
    fragments = [x.strip() for x in raw.split("|") if x.strip()] if raw else []
    outline = build_story_outline(topic, fragments)

    print("\n--- OUTLINE JSON ---\n")
    print(json.dumps(outline, indent=2))
