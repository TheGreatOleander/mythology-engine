from narrative_engine.script_builder import build_script

if __name__ == "__main__":
    topic = input("Topic: ").strip()
    raw = input("Optional fragment seeds (separate with |): ").strip()
    fragments = [x.strip() for x in raw.split("|") if x.strip()] if raw else []
    script = build_script(topic, fragments)

    print("\n--- STRUCTURED SCRIPT ---\n")
    print(script)
