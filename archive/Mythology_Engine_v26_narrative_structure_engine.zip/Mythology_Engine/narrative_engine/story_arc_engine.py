import random

DEFAULT_ARC = [
    "HOOK",
    "THE MYSTERY",
    "HISTORICAL CONTEXT",
    "THE STRANGE DETAILS",
    "THEORIES",
    "THE TWIST",
    "THE BIG QUESTION"
]

def build_story_outline(topic, fragments=None):
    fragments = fragments or []

    outline = {
        "topic": topic,
        "sections": []
    }

    for section in DEFAULT_ARC:
        entry = {
            "section": section,
            "notes": random.choice(fragments) if fragments else ""
        }
        outline["sections"].append(entry)

    return outline
