CHANNEL_STYLE = {
    "tone": "calm documentary mystery",
    "pace": "deliberate",
    "voice": "curious, restrained, atmospheric",
    "avoid": [
        "hyperactive clickbait narration",
        "comedy undercutting tension",
        "overwritten purple prose",
        "AI rambling without structure"
    ]
}
