from narrative_engine.story_arc_engine import build_story_outline

SECTION_GUIDANCE = {
    "HOOK": "Open immediately with tension, anomaly, or contradiction.",
    "THE MYSTERY": "Define the core unresolved question clearly.",
    "HISTORICAL CONTEXT": "Ground the story in time, place, and known facts or lore.",
    "THE STRANGE DETAILS": "Surface the most compelling anomalies and inconsistencies.",
    "THEORIES": "Present competing explanations without flattening the mystery.",
    "THE TWIST": "Reveal the deeper pattern, connection, or implication.",
    "THE BIG QUESTION": "End on an unresolved but irresistible question."
}

def build_script(topic, fragments=None):
    outline = build_story_outline(topic, fragments)

    script_lines = []
    script_lines.append(f"TITLE: {topic}")
    script_lines.append("")

    for s in outline["sections"]:
        section = s["section"]
        script_lines.append(f"## {section}")
        script_lines.append(SECTION_GUIDANCE.get(section, ""))

        if s["notes"]:
            script_lines.append(f"Fragment seed: {s['notes']}")

        if section == "HOOK":
            script_lines.append(
                f"Some discoveries refuse to stay buried, and {topic} is one of them."
            )
        elif section == "THE MYSTERY":
            script_lines.append(
                f"At the center of {topic} is a question that has never settled cleanly."
            )
        elif section == "HISTORICAL CONTEXT":
            script_lines.append(
                f"To understand why {topic} still matters, we have to trace where the story began."
            )
        elif section == "THE STRANGE DETAILS":
            script_lines.append(
                "The deeper investigators looked, the more the ordinary explanation began to crack."
            )
        elif section == "THEORIES":
            script_lines.append(
                "Several theories compete here, and each explains something while failing to explain something else."
            )
        elif section == "THE TWIST":
            script_lines.append(
                "The case becomes more powerful when viewed not as an isolated event, but as part of a larger pattern."
            )
        elif section == "THE BIG QUESTION":
            script_lines.append(
                f"If {topic} is only one piece of a larger hidden structure, what are the other pieces?"
            )

        script_lines.append("")

    return "\n".join(script_lines)
