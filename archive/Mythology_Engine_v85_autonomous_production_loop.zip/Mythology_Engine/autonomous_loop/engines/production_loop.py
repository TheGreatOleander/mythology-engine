from strategy_engine.strategy_provider import get_strategy
from story_engine.arc_generator import generate_arc
from production.render.video_renderer import render_video
from production.publish.publisher import publish

def run_production_loop():

    strategy = get_strategy()

    episodes = generate_arc(
        topic=strategy["topic"],
        episodes=strategy["episodes"]
    )

    results = []

    for ep in episodes:

        video = render_video(ep)

        result = publish(video)

        results.append({
            "episode": ep,
            "video": video,
            "publish_result": result
        })

    return {
        "strategy": strategy,
        "episodes_processed": len(results),
        "results": results
    }
