from autonomous_loop.engines.production_loop import run_production_loop

def autonomous_service():
    return run_production_loop()
