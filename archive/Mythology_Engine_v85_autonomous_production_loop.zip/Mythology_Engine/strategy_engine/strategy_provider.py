def get_strategy():
    return {
        "topic": "oak island treasure mystery",
        "episodes": 5,
        "cadence_days": 2
    }
