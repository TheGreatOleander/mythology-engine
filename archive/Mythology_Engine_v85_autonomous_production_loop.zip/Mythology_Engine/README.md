# Mythology Engine v85 – Autonomous Production Loop

This module executes the full content studio pipeline.

Endpoint:

POST /run-production-loop

Pipeline:

strategy → arc → render → publish
