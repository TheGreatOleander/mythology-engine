def publish(video):

    return {
        "title": video["title"],
        "status": "published_simulated"
    }
