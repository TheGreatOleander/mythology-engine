# Autonomous Production Loop

Runs the full studio pipeline automatically.

Flow:

strategy
→ arc generation
→ video render
→ publish

Endpoint:

POST /run-production-loop
