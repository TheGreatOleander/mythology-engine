from api_bridge.routes.http_server import run_server

if __name__ == "__main__":
    run_server()
