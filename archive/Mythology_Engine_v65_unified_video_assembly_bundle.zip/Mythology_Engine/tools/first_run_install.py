from installer.engines.first_run import run_first_run_installer
import json

if __name__ == "__main__":
    print(json.dumps(run_first_run_installer(), indent=2))
