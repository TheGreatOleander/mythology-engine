import json, urllib.request

base = "http://127.0.0.1:8765"

def get(path, method="GET"):
    req = urllib.request.Request(base + path, method=method)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode("utf-8"))

print("Health")
print(json.dumps(get("/health"), indent=2))

print("\nGenerate episode")
print(json.dumps(get("/generate-episode", method="POST"), indent=2))

print("\nPipeline status")
print(json.dumps(get("/pipeline-status"), indent=2))

print("\nYouTube intelligence")
print(json.dumps(get("/youtube-intelligence"), indent=2))

print("\nAssemble demo video job")
print(json.dumps(get("/assemble-demo", method="POST"), indent=2))
