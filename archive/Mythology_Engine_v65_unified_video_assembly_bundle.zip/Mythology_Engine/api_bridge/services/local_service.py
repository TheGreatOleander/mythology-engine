from episode_factory.factory import run_factory
from youtube_intelligence.engines.intelligence_report import build_report
from pipeline_manager.engines.pipeline_store import load_records, summarize, add_record
from video_assembly.engines.assembly_pipeline import run_assembly

def generate_episode_service():
    result = run_factory()
    add_record({
        "episode_id": result["manifest"]["episode_id"],
        "topic": result["manifest"]["topic"],
        "state": "SCRIPTED"
    })
    return result

def youtube_intelligence_service():
    return build_report()

def pipeline_status_service():
    records = load_records()
    return {
        "records": records,
        "summary": summarize(records)
    }

def assemble_demo_service():
    return run_assembly(
        "examples/episode_pack",
        "examples/episode_pack/narration.wav",
        "examples/episode_pack/scenes/scene_manifest.json"
    )

def health_service():
    return {
        "status": "ok",
        "service": "mythology_unified_video_assembly"
    }
