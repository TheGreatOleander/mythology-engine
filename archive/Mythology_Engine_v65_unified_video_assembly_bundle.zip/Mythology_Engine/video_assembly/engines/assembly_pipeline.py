from pathlib import Path
from video_assembly.engines.manifest_loader import load_scene_manifest
from video_assembly.engines.concat_builder import build_concat_file
from video_assembly.engines.ffmpeg_assembler import assemble_video

def run_assembly(episode_dir, audio_file, scene_manifest_file, output_name="final_video.mp4"):
    ep = Path(episode_dir)
    manifest = load_scene_manifest(scene_manifest_file)
    concat_path = ep / "scene_concat.txt"
    concat_file = build_concat_file(manifest, concat_path)
    output_file = str(ep / output_name)
    result = assemble_video(concat_file, audio_file, output_file)
    return {
        "episode_dir": str(ep),
        "scene_count": len(manifest),
        "concat_file": concat_file,
        "output_file": output_file,
        "ffmpeg_command": result["command"]
    }
