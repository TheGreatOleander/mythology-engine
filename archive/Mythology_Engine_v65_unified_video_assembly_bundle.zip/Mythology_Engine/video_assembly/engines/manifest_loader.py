import json
from pathlib import Path

def load_scene_manifest(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
