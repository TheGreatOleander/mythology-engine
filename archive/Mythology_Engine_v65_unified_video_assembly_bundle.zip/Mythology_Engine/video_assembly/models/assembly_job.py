class AssemblyJob:
    def __init__(self, episode_dir, audio_file, scene_manifest, output_file):
        self.episode_dir = episode_dir
        self.audio_file = audio_file
        self.scene_manifest = scene_manifest
        self.output_file = output_file
