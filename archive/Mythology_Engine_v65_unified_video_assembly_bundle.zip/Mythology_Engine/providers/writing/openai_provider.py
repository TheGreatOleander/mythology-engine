class OpenAIWritingProvider:
    name = "openai"
    def generate_script(self, topic: str) -> str:
        return f"""TITLE: {topic}

## HOOK
Some discoveries refuse to stay buried, and {topic} is one of them.

## STORY
Researchers uncovered symbols pointing to a forgotten route.

## MYSTERY
The deeper they looked, the stranger the evidence became.
"""
