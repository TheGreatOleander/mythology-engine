import json
from pathlib import Path

DEFAULTS = {
    "channel_name": "The Hidden Archive",
    "primary_platform": "youtube",
    "output_dir": "episodes",
    "writing_provider": "openai",
    "tts_provider": "piper",
    "image_provider": "sdxl",
    "publish_provider": "manual"
}

def load_settings():
    path = Path("secrets/local_secrets.json")
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        merged = DEFAULTS.copy()
        merged.update(data)
        return merged
    return DEFAULTS.copy()
