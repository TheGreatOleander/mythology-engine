import json, datetime
from pathlib import Path
from providers.registry import get_writing_provider, get_tts_provider, get_image_provider
from providers.config.settings_loader import load_settings

def run_factory():
    settings = load_settings()
    outdir = Path(settings.get("output_dir", "episodes"))
    outdir.mkdir(exist_ok=True)

    writing = get_writing_provider()
    tts = get_tts_provider()
    image = get_image_provider()

    topic = "Ancient Map Discovery"
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    ep = outdir / f"EP_{stamp}"
    ep.mkdir(parents=True, exist_ok=True)

    script = writing.generate_script(topic)
    (ep / "script.txt").write_text(script, encoding="utf-8")
    audio = tts.generate_audio(script, str(ep / "narration.wav"))

    scenes_dir = ep / "scenes"
    scenes_dir.mkdir(exist_ok=True)
    manifest = []
    prompts = [
        "cinematic documentary still of ancient map under torchlight",
        "forgotten route etched into parchment",
        "scholars examining impossible symbols"
    ]
    for i, prompt in enumerate(prompts, start=1):
        scene_file = scenes_dir / f"scene_{i:03}.mp4"
        image.generate_image(prompt, str(scene_file))
        manifest.append({"scene_index": i, "file": str(scene_file)})

    (scenes_dir / "scene_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    result = {
        "episode_id": ep.name,
        "topic": topic,
        "script_file": str(ep / "script.txt"),
        "audio_file": audio,
        "scene_manifest": str(scenes_dir / "scene_manifest.json")
    }
    (ep / "manifest.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return {"episode_dir": str(ep), "manifest": result}
