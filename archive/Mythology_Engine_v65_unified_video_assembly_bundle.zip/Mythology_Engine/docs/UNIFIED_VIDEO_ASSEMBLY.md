# Unified Video Assembly Bundle

This version folds the Video Assembly Engine back into the unified studio.

## New endpoint

POST /assemble-demo

Returns a finished assembly job description using:

- scene manifest
- narration audio
- FFmpeg concat plan

## Existing endpoints

- GET /health
- GET /youtube-intelligence
- GET /pipeline-status
- POST /generate-episode

## Why this matters

The unified studio can now:
- generate episodes
- track them in the pipeline
- inspect audience intelligence
- assemble finished video jobs

That is a major step toward a real automated studio.
