# Mythology Engine v65 – Unified Video Assembly Bundle

This bundle folds the finished-video assembly layer back into the unified studio.

## Includes

- Mission Control
- Local API bridge
- Episode Factory
- Provider Layer
- Pipeline status
- YouTube intelligence
- Video Assembly Engine
- First-run installer

## Endpoints

- GET /health
- GET /youtube-intelligence
- GET /pipeline-status
- POST /generate-episode
- POST /assemble-demo

## Start

Run installer:

`python tools/first_run_install.py`

Start API:

`python tools/start_api.py`

Then test:

`python tools/demo_full_system.py`
