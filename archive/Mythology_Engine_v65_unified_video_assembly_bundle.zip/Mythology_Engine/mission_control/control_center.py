from episode_factory.factory import run_factory
from youtube_intelligence.engines.intelligence_report import build_report
from video_assembly.engines.assembly_pipeline import run_assembly

class MissionControl:
    def generate_episode(self):
        return run_factory()

    def get_youtube_intelligence(self):
        return build_report()

    def assemble_episode(self, episode_dir, audio_file, scene_manifest):
        return run_assembly(episode_dir, audio_file, scene_manifest)
