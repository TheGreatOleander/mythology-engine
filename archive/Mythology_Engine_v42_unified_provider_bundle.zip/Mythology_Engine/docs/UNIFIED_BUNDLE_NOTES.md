# Unified Bundle Notes

This version folds the Cinematic Engine back into the main repository so the project
stays as one coherent system instead of splintering into side branches.

## What this means

- render planning now lives inside the main repo
- story generation and video planning exist in the same codebase
- operator tooling and cinematic tooling can evolve together
