# Setup Wizard

This module gives the project a simple first-run setup flow.

## Goal

If the repo is made public, each user should be able to wire in their own:
- YouTube OAuth credentials
- API keys
- provider preferences
- channel metadata

without editing source files manually.

## Run

`python tools/run_setup_wizard.py`

## Output

The wizard writes:

`secrets/local_secrets.json`

That file is local-only and should never be committed.
