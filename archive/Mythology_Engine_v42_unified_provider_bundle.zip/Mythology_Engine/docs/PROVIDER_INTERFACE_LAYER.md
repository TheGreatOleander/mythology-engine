# Provider Interface Layer

This module makes Mythology Engine provider-agnostic.

## Goal

The rest of the system should not care whether a capability is supplied by:
- a local engine
- a cloud API
- a manual fallback

## Supported provider groups

- writing
- tts
- image
- publish
