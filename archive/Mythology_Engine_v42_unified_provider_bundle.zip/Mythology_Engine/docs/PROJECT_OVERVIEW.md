# Project Overview

Mythology Engine is a human-guided AI documentary production pipeline.

## Unified pipeline

Trend Radar
→ Story Library
→ Story Forge
→ Lore Graph
→ Narrative Engine
→ Title & Thumbnail Lab
→ Episode Package
→ Cinematic Engine
→ Publish Queue
→ YouTube Upload
→ Performance Feedback
→ Mission Control
