import random
from story_library.fragment_store import save_fragment

TREND_SOURCES = [
    "strange archaeological discovery",
    "unexplained radio signal",
    "ancient map mystery",
    "lost civilization rumor",
    "odd satellite anomaly",
    "historical document controversy"
]

def scan_trends():
    topic = random.choice(TREND_SOURCES)
    fragment = f"Trend signal detected: {topic}. Investigate whether deeper historical or unexplained patterns exist."
    entry = save_fragment(fragment, tags=["trend", "signal"], source="trend_radar")
    return {"trend_topic": topic, "fragment_saved": entry["id"]}
