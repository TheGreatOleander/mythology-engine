SETUP_FIELDS = [
    {
        "key": "youtube_client_secret_path",
        "prompt": "Path to YouTube OAuth client_secret.json",
        "default": "secrets/client_secret.json"
    },
    {
        "key": "youtube_token_path",
        "prompt": "Path to YouTube OAuth token file",
        "default": "secrets/oauth_token.json"
    },
    {
        "key": "openai_api_key",
        "prompt": "OpenAI API key (leave blank if not using OpenAI)",
        "default": ""
    },
    {
        "key": "elevenlabs_api_key",
        "prompt": "ElevenLabs API key (leave blank if not using ElevenLabs)",
        "default": ""
    },
    {
        "key": "default_tts_provider",
        "prompt": "Default TTS provider",
        "default": "elevenlabs"
    },
    {
        "key": "default_image_provider",
        "prompt": "Default image provider",
        "default": "sdxl"
    },
    {
        "key": "channel_name",
        "prompt": "Channel name",
        "default": "The Hidden Archive"
    },
    {
        "key": "contact_email",
        "prompt": "Business / licensing contact email",
        "default": ""
    }
]
