import json
from pathlib import Path

SECRETS_DIR = Path("secrets")
SECRETS_FILE = SECRETS_DIR / "local_secrets.json"

SECRETS_DIR.mkdir(parents=True, exist_ok=True)

def load_secrets() -> dict:
    if SECRETS_FILE.exists():
        return json.loads(SECRETS_FILE.read_text(encoding="utf-8"))
    return {}

def save_secrets(data: dict) -> str:
    SECRETS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(SECRETS_FILE)

def merge_and_save(new_values: dict) -> str:
    current = load_secrets()
    current.update(new_values)
    return save_secrets(current)
