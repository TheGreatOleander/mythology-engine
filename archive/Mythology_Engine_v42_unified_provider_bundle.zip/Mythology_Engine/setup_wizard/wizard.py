from setup_wizard.prompts import SETUP_FIELDS
from setup_wizard.secret_store import merge_and_save

def run_setup_wizard() -> dict:
    collected = {}

    print("\n==============================")
    print("MYTHOLOGY ENGINE – SETUP WIZARD")
    print("==============================\n")
    print("This wizard collects local secrets and configuration values.")
    print("They will be stored in secrets/local_secrets.json")
    print("Do not commit that file to a public repo.\n")

    for field in SETUP_FIELDS:
        default = field.get("default", "")
        label = field["prompt"]
        raw = input(f"{label} [{default}]: ").strip()
        if raw == "":
            raw = default
        collected[field["key"]] = raw

    path = merge_and_save(collected)

    print("\nSaved configuration to:")
    print(path)
    print("\nSetup complete.\n")

    return collected
