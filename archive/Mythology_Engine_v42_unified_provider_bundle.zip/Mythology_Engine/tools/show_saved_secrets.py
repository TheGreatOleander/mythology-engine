import json
from pathlib import Path

path = Path("secrets/local_secrets.json")

if not path.exists():
    print("No local secrets file found.")
else:
    data = json.loads(path.read_text(encoding="utf-8"))
    print(json.dumps(data, indent=2))
