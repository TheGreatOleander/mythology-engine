import json
from performance_feedback.feedback_engine import analyze_metrics
from performance_feedback.insight_engine import generate_insights

file = input("Metrics JSON file: ").strip()
data = json.loads(open(file, encoding="utf-8").read())

report = analyze_metrics(data)
insights = generate_insights(report)

print("\n--- PERFORMANCE REPORT ---\n")
print(json.dumps(report, indent=2))

print("\n--- INSIGHTS ---\n")
for i in insights:
    print("-", i)
