import json
import sys
from pathlib import Path

if len(sys.argv) < 2:
    print("Usage: python tools/show_render_commands.py <render_plan.json>")
else:
    plan = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    print("\n--- SCENE COMMANDS ---\n")
    for item in plan.get("scene_commands", []):
        print(f'Scene {item["scene_index"]}:')
        print(item["command"])
        print()
    print("--- CONCAT COMMAND ---\n")
    print(plan.get("concat_command", ""))
