from narrative_engine.script_builder import build_script

topic = input("Topic: ").strip()
print(build_script(topic))
