from lore_graph.lore_engine import connections
print(connections())
