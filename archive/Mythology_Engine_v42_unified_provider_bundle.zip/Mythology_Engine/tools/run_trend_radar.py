from trend_radar.radar_engine import scan_trends
print(scan_trends())
