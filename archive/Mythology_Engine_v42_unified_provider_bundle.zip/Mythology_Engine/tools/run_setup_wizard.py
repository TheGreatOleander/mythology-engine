from setup_wizard.wizard import run_setup_wizard

if __name__ == "__main__":
    run_setup_wizard()
