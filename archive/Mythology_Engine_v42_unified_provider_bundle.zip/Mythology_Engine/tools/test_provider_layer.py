from pathlib import Path
from providers.registry import (
    get_writing_provider,
    get_tts_provider,
    get_image_provider,
    get_publish_provider,
)

topic = "The Map That Shouldn't Exist"

writing = get_writing_provider()
tts = get_tts_provider()
image = get_image_provider()
publish = get_publish_provider()

script = writing.generate_script(topic)
Path("examples/provider_test_script.txt").write_text(script, encoding="utf-8")

audio = tts.generate_audio(script, "examples/provider_test_audio.wav")
img = image.generate_image("ancient map cinematic mystery still", "examples/provider_test_image.png")
upload_result = publish.upload("examples/final_video.mp4", topic, "Provider-layer test upload", img)

print({
    "writing_provider": writing.name,
    "tts_provider": tts.name,
    "image_provider": image.name,
    "publish_provider": publish.name,
    "script_file": "examples/provider_test_script.txt",
    "audio_file": audio,
    "image_file": img,
    "upload_result": upload_result
})
