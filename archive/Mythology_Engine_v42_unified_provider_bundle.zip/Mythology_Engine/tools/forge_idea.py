from story_forge.forge_engine import build_episode_idea
print(build_episode_idea())
