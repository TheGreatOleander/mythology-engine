from mission_control.dashboard import show_dashboard
show_dashboard()
