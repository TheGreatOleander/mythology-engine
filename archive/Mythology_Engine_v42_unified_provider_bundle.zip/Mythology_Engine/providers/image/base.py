class BaseImageProvider:
    name = "base"

    def generate_image(self, prompt: str, output_path: str) -> str:
        raise NotImplementedError
