from pathlib import Path
from providers.image.base import BaseImageProvider

class SDXLImageProvider(BaseImageProvider):
    name = "sdxl"

    def generate_image(self, prompt: str, output_path: str) -> str:
        Path(output_path).write_text("[SDXL stub]\n\nPrompt:\n" + prompt, encoding="utf-8")
        return output_path
