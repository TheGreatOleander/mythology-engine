class BaseTTSProvider:
    name = "base"

    def generate_audio(self, script_text: str, output_path: str) -> str:
        raise NotImplementedError
