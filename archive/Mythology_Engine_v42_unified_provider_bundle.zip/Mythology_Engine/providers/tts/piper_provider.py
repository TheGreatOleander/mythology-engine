from pathlib import Path
from providers.tts.base import BaseTTSProvider

class PiperTTSProvider(BaseTTSProvider):
    name = "piper"

    def generate_audio(self, script_text: str, output_path: str) -> str:
        Path(output_path).write_text("[Piper stub]\n\n" + script_text, encoding="utf-8")
        return output_path
