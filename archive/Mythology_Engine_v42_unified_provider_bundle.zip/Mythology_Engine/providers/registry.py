from providers.config.settings_loader import load_settings

from providers.writing.openai_provider import OpenAIWritingProvider
from providers.writing.local_llm_provider import LocalLLMWritingProvider
from providers.tts.elevenlabs_provider import ElevenLabsTTSProvider
from providers.tts.piper_provider import PiperTTSProvider
from providers.image.dalle_provider import DalleImageProvider
from providers.image.sdxl_provider import SDXLImageProvider
from providers.publish.youtube_provider import YouTubePublishProvider
from providers.publish.manual_provider import ManualPublishProvider

WRITING_PROVIDERS = {
    "openai": OpenAIWritingProvider,
    "local_llm": LocalLLMWritingProvider,
}

TTS_PROVIDERS = {
    "elevenlabs": ElevenLabsTTSProvider,
    "piper": PiperTTSProvider,
}

IMAGE_PROVIDERS = {
    "dalle": DalleImageProvider,
    "sdxl": SDXLImageProvider,
}

PUBLISH_PROVIDERS = {
    "youtube": YouTubePublishProvider,
    "manual": ManualPublishProvider,
}

def _build(provider_map, key, fallback):
    settings = load_settings()
    name = settings.get(key, fallback)
    cls = provider_map.get(name) or provider_map[fallback]
    return cls()

def get_writing_provider():
    return _build(WRITING_PROVIDERS, "writing_provider", "openai")

def get_tts_provider():
    return _build(TTS_PROVIDERS, "tts_provider", "elevenlabs")

def get_image_provider():
    return _build(IMAGE_PROVIDERS, "image_provider", "sdxl")

def get_publish_provider():
    return _build(PUBLISH_PROVIDERS, "publish_provider", "manual")
