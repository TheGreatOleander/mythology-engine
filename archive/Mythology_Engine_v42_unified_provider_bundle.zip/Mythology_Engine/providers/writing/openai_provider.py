from providers.writing.base import BaseWritingProvider

class OpenAIWritingProvider(BaseWritingProvider):
    name = "openai"

    def generate_script(self, topic: str) -> str:
        return f"[OpenAI provider stub] Script for: {topic}"
