from providers.writing.base import BaseWritingProvider

class LocalLLMWritingProvider(BaseWritingProvider):
    name = "local_llm"

    def generate_script(self, topic: str) -> str:
        return f"[Local LLM provider stub] Script for: {topic}"
