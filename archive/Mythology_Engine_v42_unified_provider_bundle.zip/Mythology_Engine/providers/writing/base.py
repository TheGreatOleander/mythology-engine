class BaseWritingProvider:
    name = "base"

    def generate_script(self, topic: str) -> str:
        raise NotImplementedError
