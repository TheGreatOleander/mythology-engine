from providers.publish.base import BasePublishProvider

class YouTubePublishProvider(BasePublishProvider):
    name = "youtube"

    def upload(self, video_path: str, title: str, description: str, thumbnail_path=None) -> dict:
        return {
            "status": "youtube_stub",
            "video_path": video_path,
            "title": title,
            "description": description,
            "thumbnail_path": thumbnail_path
        }
