from providers.publish.base import BasePublishProvider

class ManualPublishProvider(BasePublishProvider):
    name = "manual"

    def upload(self, video_path: str, title: str, description: str, thumbnail_path=None) -> dict:
        return {
            "status": "manual_review_required",
            "video_path": video_path,
            "title": title
        }
