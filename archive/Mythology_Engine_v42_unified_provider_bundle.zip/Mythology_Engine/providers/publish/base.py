class BasePublishProvider:
    name = "base"

    def upload(self, video_path: str, title: str, description: str, thumbnail_path=None) -> dict:
        raise NotImplementedError
