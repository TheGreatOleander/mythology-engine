import json
from pathlib import Path

DEFAULTS = {
    "writing_provider": "openai",
    "tts_provider": "elevenlabs",
    "image_provider": "sdxl",
    "publish_provider": "youtube",
    "channel_name": "The Hidden Archive"
}

def load_settings() -> dict:
    path = Path("secrets/local_secrets.json")
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        merged = DEFAULTS.copy()
        merged.update(data)
        return merged
    return DEFAULTS.copy()
