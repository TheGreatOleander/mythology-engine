import random, json
from pathlib import Path

INDEX = Path("story_library/storage/index.json")

def build_episode_idea():
    if not INDEX.exists():
        return "No fragments yet."

    data = json.loads(INDEX.read_text(encoding="utf-8"))
    picks = random.sample(data, min(3, len(data)))

    lines = ["EPISODE IDEA", ""]
    for p in picks:
        lines.append(f'- {p["id"]}')
    lines.append("")
    lines.append("Narrative Direction:")
    lines.append("Find the hidden pattern connecting these fragments.")
    return "\n".join(lines)
