import random

TITLE_PATTERNS = [
    "The Mystery Historians Still Cannot Explain About {topic}",
    "What They Discovered About {topic} Changed Everything",
    "The Strange Truth Behind {topic}",
    "Why {topic} Still Doesn't Make Sense",
    "The Unsolved Story of {topic}"
]

def generate_titles(topic, count=5):
    titles = []
    for _ in range(count):
        titles.append(random.choice(TITLE_PATTERNS).format(topic=topic))
    return list(dict.fromkeys(titles))
