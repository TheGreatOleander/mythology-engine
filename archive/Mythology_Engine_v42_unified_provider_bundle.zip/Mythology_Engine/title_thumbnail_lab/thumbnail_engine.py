import random

THUMBNAIL_PATTERNS = [
    {"text": "THEY HID THIS", "style": "dark mystery"},
    {"text": "UNEXPLAINED", "style": "ancient artifact close-up"},
    {"text": "WHY?", "style": "question over artifact"},
    {"text": "THE SECRET MAP", "style": "dramatic lighting"},
]

def generate_thumbnail_concepts(topic, count=4):
    out = []
    for _ in range(count):
        p = random.choice(THUMBNAIL_PATTERNS)
        out.append({
            "topic": topic,
            "text": p["text"],
            "style": p["style"]
        })
    return out
