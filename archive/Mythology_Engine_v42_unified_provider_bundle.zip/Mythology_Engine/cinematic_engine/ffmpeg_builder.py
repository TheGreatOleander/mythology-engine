from cinematic_engine.asset_mapper import select_asset

def build_scene_commands(timeline: list, output_dir: str) -> list:
    commands = []

    for item in timeline:
        bg = select_asset(item["visual_type"])
        out = f'{output_dir}/scene_{item["scene_index"]:03d}.mp4'
        duration = item["duration_seconds"]
        motion = item["motion"]

        vf = 'scale=1920:1080,format=yuv420p'
        if motion == "slow_zoom_in":
            vf = "zoompan=z='min(zoom+0.0008,1.12)':d=240:s=1920x1080"
        elif motion == "slow_zoom_out":
            vf = "zoompan=z='if(lte(on,1),1.12,max(1.0,zoom-0.0005))':d=240:s=1920x1080"
        elif motion == "slow_pan_left":
            vf = "crop=iw*0.92:ih*0.92:x='(iw-iw*0.92)*(1-on/240)':y=0,scale=1920:1080"
        elif motion == "slow_pan_right":
            vf = "crop=iw*0.92:ih*0.92:x='(iw-iw*0.92)*(on/240)':y=0,scale=1920:1080"
        elif motion == "gentle_parallax":
            vf = "scale=2100:1180,crop=1920:1080:x='20*sin(on/30)':y='10*cos(on/45)'"

        cmd = (
            f'ffmpeg -y -loop 1 -i "{bg}" -t {duration} '
            f'-vf "{vf}" -r 30 -c:v libx264 -pix_fmt yuv420p "{out}"'
        )
        commands.append({
            "scene_index": item["scene_index"],
            "command": cmd,
            "output": out
        })

    return commands

def build_concat_command(scene_outputs: list, audio_path: str, subtitles_path: str, output_video: str) -> str:
    return (
        "Write concat.txt with scene files, then run: "
        f'ffmpeg -y -f concat -safe 0 -i concat.txt -i "{audio_path}" '
        f'-vf "subtitles={subtitles_path}" -c:v libx264 -c:a aac -shortest "{output_video}"'
    )
