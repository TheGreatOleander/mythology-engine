import json
from pathlib import Path

def build_timeline(scene_plan_path: str) -> list:
    scene_plan = json.loads(Path(scene_plan_path).read_text(encoding="utf-8"))
    cursor = 0.0
    timeline = []

    for scene in scene_plan:
        duration = float(scene.get("duration_seconds", 8))
        timeline.append({
            "scene_index": scene.get("scene_index"),
            "visual_type": scene.get("visual_type", "artifact"),
            "motion": scene.get("motion", "slow_zoom_in"),
            "text": scene.get("text", ""),
            "start": round(cursor, 2),
            "end": round(cursor + duration, 2),
            "duration_seconds": duration
        })
        cursor += duration

    return timeline
