BACKGROUND_MAP = {
    "artifact": "examples/assets/backgrounds/artifact_bg.jpg",
    "map": "examples/assets/backgrounds/map_bg.jpg",
    "document": "examples/assets/backgrounds/document_bg.jpg",
    "text_card": "examples/assets/backgrounds/dark_bg.jpg",
}

def select_asset(visual_type: str) -> str:
    return BACKGROUND_MAP.get(visual_type, "examples/assets/backgrounds/dark_bg.jpg")
