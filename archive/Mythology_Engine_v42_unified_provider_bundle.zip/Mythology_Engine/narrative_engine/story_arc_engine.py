ARC = [
    "HOOK",
    "THE MYSTERY",
    "HISTORICAL CONTEXT",
    "STRANGE DETAILS",
    "THEORIES",
    "THE TWIST",
    "THE BIG QUESTION"
]

def build_outline(topic):
    return [{"section": s, "topic": topic} for s in ARC]
