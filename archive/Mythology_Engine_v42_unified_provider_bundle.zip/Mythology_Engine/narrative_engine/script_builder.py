from narrative_engine.story_arc_engine import build_outline

def build_script(topic):
    outline = build_outline(topic)
    out = [f"TITLE: {topic}", ""]

    for item in outline:
        s = item["section"]
        out.append("## " + s)
        if s == "HOOK":
            out.append(f"Some discoveries refuse to stay buried, and {topic} is one of them.")
        elif s == "THE MYSTERY":
            out.append(f"At the center of {topic} is a question that has never settled cleanly.")
        elif s == "HISTORICAL CONTEXT":
            out.append(f"To understand why {topic} still matters, we have to trace where the story began.")
        elif s == "STRANGE DETAILS":
            out.append("The deeper investigators looked, the more the ordinary explanation began to crack.")
        elif s == "THEORIES":
            out.append("Several explanations compete here, and each leaves something unresolved.")
        elif s == "THE TWIST":
            out.append("The case becomes more powerful when viewed as part of a larger hidden pattern.")
        elif s == "THE BIG QUESTION":
            out.append(f"If {topic} is only one piece of a larger structure, what are the other pieces?")
        out.append("")

    return "\n".join(out)
