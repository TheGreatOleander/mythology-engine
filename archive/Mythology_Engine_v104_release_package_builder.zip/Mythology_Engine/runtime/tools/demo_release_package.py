from release_package.engines.package_builder import build_release_package
import json

print(json.dumps(build_release_package(), indent=2))
