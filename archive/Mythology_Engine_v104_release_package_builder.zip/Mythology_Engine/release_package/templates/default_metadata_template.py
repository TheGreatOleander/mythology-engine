def build_metadata():
    return {
        "platform_targets": [
            "youtube",
            "youtube_shorts",
            "tiktok",
            "instagram_reels",
            "podcast"
        ],
        "publish_mode": "manual_first",
        "campaign_ready": True
    }
