from pathlib import Path
import json
from release_package.models.release_manifest import ReleaseManifest
from release_package.templates.default_metadata_template import build_metadata

def build_release_package(output_dir="examples/release_package"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "teaser_clips").mkdir(parents=True, exist_ok=True)
    (out / "social_images").mkdir(parents=True, exist_ok=True)

    title = "The Map That Shouldn't Exist"
    description = (
        "A mysterious parchment map may predate known exploration routes and point "
        "toward a forgotten civilization."
    )

    video = out / "episode.mp4"
    thumbnail = out / "thumbnail.png"
    captions = out / "captions.srt"
    transcript = out / "transcript.txt"
    title_file = out / "title.txt"
    description_file = out / "description.txt"

    video.write_text("EPISODE PLACEHOLDER", encoding="utf-8")
    thumbnail.write_text("THUMBNAIL PLACEHOLDER", encoding="utf-8")
    captions.write_text(
        "1\n00:00:00,000 --> 00:00:03,000\nThis map may not be possible.\n",
        encoding="utf-8"
    )
    transcript.write_text(
        "This map may not be possible. It was discovered beneath a forgotten archive.",
        encoding="utf-8"
    )
    title_file.write_text(title, encoding="utf-8")
    description_file.write_text(description, encoding="utf-8")

    teaser_files = []
    for i in range(1, 4):
        f = out / "teaser_clips" / f"teaser_clip_{i:02}.mp4"
        f.write_text(f"TEASER CLIP {i} PLACEHOLDER", encoding="utf-8")
        teaser_files.append(str(f))

    social_files = []
    for i in range(1, 4):
        f = out / "social_images" / f"social_card_{i:02}.png"
        f.write_text(f"SOCIAL CARD {i} PLACEHOLDER", encoding="utf-8")
        social_files.append(str(f))

    metadata = build_metadata()
    metadata["teaser_clips"] = teaser_files
    metadata["social_images"] = social_files
    metadata["release_package_version"] = "v104"

    manifest = ReleaseManifest(
        title=title,
        description=description,
        video=str(video),
        thumbnail=str(thumbnail),
        captions=str(captions),
        transcript=str(transcript),
        metadata=metadata
    )

    manifest_path = out / "metadata.json"
    manifest_path.write_text(json.dumps(manifest.to_dict(), indent=2), encoding="utf-8")

    return {
        "package_dir": str(out),
        "manifest": manifest.to_dict(),
        "manifest_file": str(manifest_path)
    }
