class ReleaseManifest:
    def __init__(self, title, description, video, thumbnail, captions, transcript, metadata):
        self.title = title
        self.description = description
        self.video = video
        self.thumbnail = thumbnail
        self.captions = captions
        self.transcript = transcript
        self.metadata = metadata

    def to_dict(self):
        return {
            "title": self.title,
            "description": self.description,
            "video": self.video,
            "thumbnail": self.thumbnail,
            "captions": self.captions,
            "transcript": self.transcript,
            "metadata": self.metadata
        }
