# Mythology Engine v104 – Release Package Builder

This version adds the canonical release package handoff layer.

## Run

python runtime/tools/demo_release_package.py

## Output

examples/release_package/

- episode.mp4
- thumbnail.png
- title.txt
- description.txt
- captions.srt
- transcript.txt
- teaser_clips/
- social_images/
- metadata.json

## Why this matters

This is the clean handoff point between:

- Mythology Engine
- future Media PR Engine
- future platform publishing tools
