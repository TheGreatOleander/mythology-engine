# Release Package Builder

This module creates the canonical handoff bundle for the wider studio ecosystem.

## Purpose

Turn finished episode assets into one clean release package that can be used by:

- manual publishing workflows
- platform adapters
- the future Media PR Engine
- archive / backup flows

## Package contents

- episode.mp4
- thumbnail.png
- title.txt
- description.txt
- captions.srt
- transcript.txt
- teaser_clips/
- social_images/
- metadata.json

## Why it matters

This keeps project boundaries clean.

Mythology Engine creates the release package.
Media PR Engine will consume the release package later.
