from core.episode_runner import run_episode

if __name__=="__main__":
    m=run_episode()
    print("Episode package created:",m["episode_id"])
