from tools.ffmpeg_tools import render_command

def render_video(audio,out):
    cmd=render_command(audio,out)
    return out
