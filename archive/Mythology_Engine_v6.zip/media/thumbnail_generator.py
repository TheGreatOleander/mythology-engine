def thumbnail_prompt(topic,title):
    return f"{topic}, cinematic mystery thumbnail, dark archive mood"
