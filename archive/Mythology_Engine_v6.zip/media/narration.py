from pathlib import Path

def synthesize(script:str,out:Path)->str:
    out.write_text("placeholder narration")
    return str(out)
