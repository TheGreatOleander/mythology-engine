def render_command(audio,out):
    return f'ffmpeg -loop 1 -i assets/images/bg.png -i {audio} -shortest -c:v libx264 -c:a aac {out}'
