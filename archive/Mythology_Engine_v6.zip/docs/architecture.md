Architecture

Discovery → Story → Media → Review → Upload → Analytics → Universe memory
