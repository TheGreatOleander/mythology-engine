v6 Goals Achieved

• render pipeline hook
• subtitle generator
• episode manifest
• review system
• uploader stub

Next

• real TTS
• image generation
• YouTube draft upload
• analytics learning loop
