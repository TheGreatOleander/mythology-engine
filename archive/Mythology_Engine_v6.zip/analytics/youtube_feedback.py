def fetch_metrics(video_id):
    return {"ctr":None,"watch_time":None}
