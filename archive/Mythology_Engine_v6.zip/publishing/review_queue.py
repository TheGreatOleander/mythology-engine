from pathlib import Path
def write_review(epdir,manifest):
    txt=f"Review Episode\nTitle: {manifest['title']}\nTopic: {manifest['topic']}"
    (Path(epdir)/"REVIEW.txt").write_text(txt)
