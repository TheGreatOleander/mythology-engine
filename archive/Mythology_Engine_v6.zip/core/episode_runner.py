from pathlib import Path
import json, datetime
from discovery.topic_discovery import get_topic
from story.title_optimizer import optimize_title
from story.script_builder import build_script
from media.narration import synthesize
from media.thumbnail_generator import thumbnail_prompt
from media.video_assembler import render_video
from media.subtitle_generator import generate_subtitles
from publishing.review_queue import write_review

def run_episode():
    topic=get_topic()
    title=optimize_title(topic)
    script=build_script(topic)

    eid=datetime.datetime.utcnow().strftime("EP%Y%m%d_%H%M%S")
    epdir=Path("episodes")/eid
    epdir.mkdir(parents=True,exist_ok=True)

    script_path=epdir/"script.txt"
    script_path.write_text(script)

    audio=synthesize(script,epdir/"narration.wav")
    video=render_video(audio,epdir/"video.mp4")
    generate_subtitles(script,epdir/"subtitles.srt")

    manifest={
        "episode_id":eid,
        "topic":topic,
        "title":title,
        "script":str(script_path),
        "audio":str(audio),
        "video":str(video)
    }

    (epdir/"manifest.json").write_text(json.dumps(manifest,indent=2))

    write_review(epdir,manifest)

    return manifest
