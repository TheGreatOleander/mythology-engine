from dataclasses import dataclass
from typing import Dict

@dataclass
class EpisodeManifest:
    episode_id:str
    topic:str
    title:str
    script_path:str
    narration_path:str
    video_path:str
    metadata:Dict
    status:str="draft"
