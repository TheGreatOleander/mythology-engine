# Mythology Engine v6

A production‑ready foundation for an automated documentary‑style YouTube channel.

v6 focuses on turning the earlier scaffolds into a **working production spine**.

Pipeline

topic discovery
→ episode planning
→ script generation
→ narration synthesis
→ thumbnail prompt + image generation hook
→ FFmpeg render pipeline
→ subtitle generation
→ review package
→ optional YouTube draft upload
→ analytics ingestion
→ mythology update

This repo still enforces **human review before publish**.
