from pathlib import Path
import json

def build_ffmpeg_plan(scene_plan_path, audio_path, output_path):
    scene_plan = json.loads(Path(scene_plan_path).read_text())

    plan = {
        "scene_count": len(scene_plan),
        "audio": str(audio_path),
        "strategy": "ken_burns_slideshow",
        "output": str(output_path)
    }

    return plan

def render_stub(plan):
    print("[RENDER] Would render video with plan:")
    print(plan)
    return plan["output"]
