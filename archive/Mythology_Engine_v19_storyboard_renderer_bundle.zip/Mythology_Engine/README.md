# Mythology Engine – Storyboard Renderer Bundle

This version introduces the first video rendering layer.

scene_plan.json
+ narration.wav
→ storyboard render plan
→ FFmpeg slideshow style render

Run:

python tools/render_episode_storyboard.py <episode_folder>
