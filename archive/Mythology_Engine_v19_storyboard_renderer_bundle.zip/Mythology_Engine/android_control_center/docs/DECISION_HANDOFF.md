# Decision Handoff

The Android app produces decision JSON.

Future integration can:

- save JSON locally
- send to a server
- drop into `decision_inbox/`
- hand off to Tasker / Termux

This connects the mobile review interface to the engine runtime.
