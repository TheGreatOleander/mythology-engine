# Package Inspector

This version upgrades the Android app from manifest-only import to package inspection.

## Supported imports

- `manifest.json`
- `scene_plan.json`
- `thumbnail_variants.json`

## Why it matters

The control center can now inspect the identity and cinematic treatment of an episode package.

That means the app is becoming a real review tool instead of a decorative shell.
