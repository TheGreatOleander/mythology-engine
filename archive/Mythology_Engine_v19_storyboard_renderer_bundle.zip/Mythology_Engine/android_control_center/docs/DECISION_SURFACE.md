# Decision Surface

This version adds a dedicated decision surface to the Android app.

## Purpose
Turn operator intent into structured JSON.

## Screen features
- notes field
- approve action
- reject action
- regenerate action
- latest decision JSON viewer

## Why this matters
This is the missing bridge between:
- package review
- downstream action
