# Decision Export

This version lets the Android app generate decision JSON artifacts.

## Supported actions
- Approve
- Reject
- Regenerate

## What happens
The app builds a JSON decision record using the selected episode id and optional operator notes.

In this scaffold version, the JSON is displayed and stored in app state.
A later version should allow:
- saving to file
- sharing the JSON
- posting to a local endpoint
- handing off to Tasker / Termux
