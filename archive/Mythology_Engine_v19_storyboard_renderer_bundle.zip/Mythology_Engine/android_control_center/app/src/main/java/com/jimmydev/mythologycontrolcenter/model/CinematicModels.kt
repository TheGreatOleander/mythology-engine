package com.jimmydev.mythologycontrolcenter.model

data class SceneItem(
    val sceneIndex: Int,
    val text: String,
    val visualType: String,
    val motion: String,
    val durationSeconds: Int,
    val overlayStyle: String
)

data class ThumbnailVariantItem(
    val titleText: String,
    val prompt: String
)
