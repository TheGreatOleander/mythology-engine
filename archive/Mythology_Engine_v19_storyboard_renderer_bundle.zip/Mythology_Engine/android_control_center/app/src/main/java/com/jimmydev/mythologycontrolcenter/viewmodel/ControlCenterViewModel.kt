package com.jimmydev.mythologycontrolcenter.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jimmydev.mythologycontrolcenter.data.CinematicParsers
import com.jimmydev.mythologycontrolcenter.data.DecisionExporter
import com.jimmydev.mythologycontrolcenter.data.FakeRepository
import com.jimmydev.mythologycontrolcenter.model.DashboardStats
import com.jimmydev.mythologycontrolcenter.model.Episode
import com.jimmydev.mythologycontrolcenter.model.PipelineLog
import com.jimmydev.mythologycontrolcenter.model.ReviewDecision
import com.jimmydev.mythologycontrolcenter.model.SceneItem
import com.jimmydev.mythologycontrolcenter.model.SettingsState
import com.jimmydev.mythologycontrolcenter.model.ThumbnailVariantItem
import com.jimmydev.mythologycontrolcenter.model.VariantPack
import kotlinx.coroutines.launch

class ControlCenterViewModel : ViewModel() {

    private val repo = FakeRepository()

    var settings by mutableStateOf(SettingsState())
        private set

    var stats by mutableStateOf(DashboardStats(0, 0, 0.0, "Review only"))
        private set

    var episodes by mutableStateOf<List<Episode>>(emptyList())
        private set

    var logs by mutableStateOf<List<PipelineLog>>(emptyList())
        private set

    var selectedEpisodeId by mutableStateOf<String?>(null)
        private set

    var selectedVariantPack by mutableStateOf(VariantPack(emptyList(), emptyList(), emptyList()))
        private set

    var scenePlan by mutableStateOf<List<SceneItem>>(emptyList())
        private set

    var thumbnailPackages by mutableStateOf<List<ThumbnailVariantItem>>(emptyList())
        private set

    var isBusy by mutableStateOf(false)
        private set

    var infoMessage by mutableStateOf("Ready.")
        private set

    var decisionNotes by mutableStateOf("")
        private set

    var latestDecision by mutableStateOf<ReviewDecision?>(null)
        private set

    var latestDecisionJson by mutableStateOf("")
        private set

    init {
        refreshAll()
    }

    fun refreshAll() {
        viewModelScope.launch {
            isBusy = true
            stats = repo.getDashboardStats(settings)
            episodes = repo.getEpisodes()
            logs = repo.getLogs()
            if (selectedEpisodeId == null && episodes.isNotEmpty()) {
                selectEpisode(episodes.first().id)
            } else if (selectedEpisodeId != null) {
                selectedVariantPack = repo.getVariantPackFor(selectedEpisodeId!!)
            }
            isBusy = false
        }
    }

    fun selectEpisode(episodeId: String) {
        selectedEpisodeId = episodeId
        viewModelScope.launch {
            selectedVariantPack = repo.getVariantPackFor(episodeId)
        }
    }

    fun toggleUploadEnabled() {
        settings = settings.copy(uploadEnabled = !settings.uploadEnabled)
        refreshAll()
    }

    fun updateChannelName(name: String) {
        settings = settings.copy(channelName = name)
    }

    fun updateDecisionNotes(notes: String) {
        decisionNotes = notes
    }

    fun runEpisodeNow() {
        viewModelScope.launch {
            isBusy = true
            repo.runEpisodeNow()
            infoMessage = "Fresh episode package generated."
            refreshAll()
            isBusy = false
        }
    }

    fun importManifestJson(json: String) {
        viewModelScope.launch {
            isBusy = true
            val imported = repo.importManifestJson(json)
            selectedEpisodeId = imported.id
            selectedVariantPack = repo.getVariantPackFor(imported.id)
            infoMessage = "Imported ${imported.id} from manifest.json"
            refreshAll()
            isBusy = false
        }
    }

    fun importScenePlanJson(json: String) {
        scenePlan = CinematicParsers.parseScenePlan(json)
        infoMessage = "Scene plan imported: ${scenePlan.size} scenes."
    }

    fun importThumbnailVariantsJson(json: String) {
        thumbnailPackages = CinematicParsers.parseThumbnailVariants(json)
        infoMessage = "Thumbnail package imported: ${thumbnailPackages.size} variants."
    }

    fun approveEpisode() {
        emitDecision("approved_for_publish")
    }

    fun rejectEpisode() {
        emitDecision("rejected")
    }

    fun regenerateEpisode() {
        emitDecision("regenerate_requested")
    }

    private fun emitDecision(kind: String) {
        val id = selectedEpisodeId ?: return
        val decision = DecisionExporter.buildDecision(
            episodeId = id,
            operatorDecision = kind,
            notes = decisionNotes.ifBlank { "No operator notes provided." }
        )
        latestDecision = decision
        latestDecisionJson = DecisionExporter.toJson(decision)
        infoMessage = "Decision recorded for $id: $kind"
    }
}
