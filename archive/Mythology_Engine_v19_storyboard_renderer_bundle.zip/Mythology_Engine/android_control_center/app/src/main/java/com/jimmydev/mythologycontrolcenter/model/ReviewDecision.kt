package com.jimmydev.mythologycontrolcenter.model

data class ReviewDecision(
    val episodeId: String,
    val operatorDecision: String,
    val notes: String,
    val timestampUtc: String
)
