package com.jimmydev.mythologycontrolcenter.data

import com.jimmydev.mythologycontrolcenter.model.ReviewDecision
import org.json.JSONObject
import java.time.Instant

object DecisionExporter {

    fun buildDecision(
        episodeId: String,
        operatorDecision: String,
        notes: String
    ): ReviewDecision {
        return ReviewDecision(
            episodeId = episodeId,
            operatorDecision = operatorDecision,
            notes = notes,
            timestampUtc = Instant.now().toString()
        )
    }

    fun toJson(decision: ReviewDecision): String {
        return JSONObject(
            mapOf(
                "episode_id" to decision.episodeId,
                "operator_decision" to decision.operatorDecision,
                "notes" to decision.notes,
                "timestamp_utc" to decision.timestampUtc
            )
        ).toString(2)
    }
}
