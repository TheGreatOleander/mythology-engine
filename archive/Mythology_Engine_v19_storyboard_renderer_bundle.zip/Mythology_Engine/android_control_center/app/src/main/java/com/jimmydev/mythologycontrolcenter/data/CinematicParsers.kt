package com.jimmydev.mythologycontrolcenter.data

import com.jimmydev.mythologycontrolcenter.model.SceneItem
import com.jimmydev.mythologycontrolcenter.model.ThumbnailVariantItem
import org.json.JSONArray

object CinematicParsers {

    fun parseScenePlan(json: String): List<SceneItem> {
        val arr = JSONArray(json)
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(
                    SceneItem(
                        sceneIndex = obj.optInt("scene_index", i),
                        text = obj.optString("text", ""),
                        visualType = obj.optString("visual_type", "artifact"),
                        motion = obj.optString("motion", "slow_zoom_in"),
                        durationSeconds = obj.optInt("duration_seconds", 8),
                        overlayStyle = obj.optString("overlay_style", "subtitle_bottom")
                    )
                )
            }
        }
    }

    fun parseThumbnailVariants(json: String): List<ThumbnailVariantItem> {
        val arr = JSONArray(json)
        return buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(
                    ThumbnailVariantItem(
                        titleText = obj.optString("title_text", "UNTITLED"),
                        prompt = obj.optString("prompt", "")
                    )
                )
            }
        }
    }
}
