# Android Control Center

This Android app is the mobile cockpit for Mythology Engine.

## What it does now
- dashboard overview
- draft episode queue
- variant pack review
- package inspection
- decision surface
- import `manifest.json`
- import `scene_plan.json`
- import `thumbnail_variants.json`

## Key upgrade in this version
The app now emits structured decision JSON for:
- approve
- reject
- regenerate

That makes it a real control surface.
