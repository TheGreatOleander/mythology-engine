# Decision Actions

This version introduces actual reactions to operator decisions.

After the engine reads decisions from `decision_inbox/`, it can trigger actions.

Supported actions:

approved_for_publish
    → send episode to publishing module

rejected
    → move episode to rejected archive

regenerate_requested
    → rerun generation for the topic

## Philosophy

The engine should never guess operator intent.

All downstream behavior originates from an explicit decision JSON.
