# Video Render Pipeline

This version introduces a storyboard renderer scaffold.

Goal:
Turn the episode cinematic plan into a simple video using FFmpeg.

Inputs:

scene_plan.json
narration.wav
subtitles.srt
music_bed.txt (optional)

Strategy:

1. Convert scenes into a timed storyboard
2. Use still background assets
3. Apply slow zoom/pan motion
4. Overlay subtitles
5. Mix narration + music bed
6. Export video.mp4

This scaffold relies on FFmpeg slideshow techniques.
