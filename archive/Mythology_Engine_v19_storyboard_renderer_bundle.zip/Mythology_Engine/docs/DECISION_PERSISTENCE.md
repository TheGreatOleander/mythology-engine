# Decision Persistence

This version introduces a concrete operator output model.

The Android Control Center is no longer limited to displaying packages.
It can now generate **decision artifacts** representing operator intent.

## Decision outputs

An operator decision should be represented as a JSON object with:

- `episode_id`
- `operator_decision`
- `notes`
- `timestamp_utc`

## Expected decisions

- `approved_for_publish`
- `rejected`
- `regenerate_requested`

## Why this matters

The pipeline now has a review endpoint that produces machine-readable outputs.

That means future automations can safely react to:
- approval
- rejection
- regeneration requests

without guessing what the operator meant.
