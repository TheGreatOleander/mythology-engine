# Control Surface Model

The Android Control Center is now moving from inspection toward control.

## Previous role
- import package files
- inspect episode identity
- inspect cinematic package

## New role
- produce decision records
- export machine-readable operator intent

## Shape of the loop

engine
→ episode package
→ phone review
→ decision JSON
→ downstream action

That is the beginning of a real command loop.
