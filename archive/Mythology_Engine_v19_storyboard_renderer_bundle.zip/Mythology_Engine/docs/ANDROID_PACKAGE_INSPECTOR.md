# Android Package Inspector

The Android Control Center is evolving from a queue viewer into a package inspector.

## Current role

- import `manifest.json`
- show episode identity
- show operator variants
- allow approve / reject / regenerate decisions

## New role in this direction

- import `scene_plan.json`
- import `thumbnail_variants.json`
- display cinematic package details on-device

## Product intent

The phone is not just a dashboard.
It is meant to become the review station for the entire episode package.
