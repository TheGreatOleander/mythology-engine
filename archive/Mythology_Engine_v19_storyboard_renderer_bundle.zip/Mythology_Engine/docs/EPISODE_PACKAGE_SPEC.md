# Episode Package Spec

Each generated episode package is expected to contain the following core files.

## Required

- `manifest.json`
- `script.txt`
- `subtitles.srt`
- `REVIEW.txt`
- `metadata_package.json`

## Cinematic package files

- `scene_plan.json`
- `thumbnail_variants.json`
- `music_bed.txt`

## Meaning

### `manifest.json`
The episode identity and selected package direction.

### `metadata_package.json`
The review-facing metadata and packaging bundle.

### `scene_plan.json`
The ordered visual treatment plan for the episode.

### `thumbnail_variants.json`
Thumbnail concepts for operator review.

### `music_bed.txt`
A stub reference to the intended music bed style.

## Why this matters

The package must remain inspectable.

If a future version creates more media, it should still preserve a package
that a human can understand at a glance.
