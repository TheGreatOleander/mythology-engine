# Decision Inbox

The engine can now read operator decisions produced by the Android Control Center.

A directory called `decision_inbox/` acts as a drop location for decision JSON files.

Example:

decision_inbox/
    decision_EP_20260309_123000.json

The engine periodically scans this folder and reacts accordingly.

## Supported decisions

approved_for_publish
rejected
regenerate_requested

## Purpose

This creates the full loop:

engine → episode package → phone review → decision JSON → engine reaction
