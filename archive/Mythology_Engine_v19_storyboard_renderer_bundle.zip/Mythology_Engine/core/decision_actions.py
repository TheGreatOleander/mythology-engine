from pathlib import Path
import shutil

EPISODES_DIR = Path("episodes")
REJECTED_DIR = Path("rejected_episodes")

REJECTED_DIR.mkdir(exist_ok=True)

def handle_approved(eid):
    print(f"[ACTION] Approved for publish: {eid}")
    # placeholder – would call publishing pipeline
    return {"publish": eid}

def handle_rejected(eid):
    src = EPISODES_DIR / eid
    dst = REJECTED_DIR / eid
    if src.exists():
        shutil.move(str(src), str(dst))
    return {"rejected": eid}

def handle_regenerate(eid):
    print(f"[ACTION] Regeneration requested for {eid}")
    return {"regenerate": eid}

def dispatch(actions):
    results = []
    for eid in actions.get("approved_for_publish", []):
        results.append(handle_approved(eid))
    for eid in actions.get("rejected", []):
        results.append(handle_rejected(eid))
    for eid in actions.get("regenerate_requested", []):
        results.append(handle_regenerate(eid))
    return results
