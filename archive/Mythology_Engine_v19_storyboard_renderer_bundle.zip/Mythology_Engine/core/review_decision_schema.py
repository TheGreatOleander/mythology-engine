from datetime import datetime

VALID_DECISIONS = {
    "approved_for_publish",
    "rejected",
    "regenerate_requested",
}

def make_decision_record(episode_id: str, operator_decision: str, notes: str) -> dict:
    if operator_decision not in VALID_DECISIONS:
        raise ValueError(f"Invalid operator decision: {operator_decision}")

    return {
        "episode_id": episode_id,
        "operator_decision": operator_decision,
        "notes": notes,
        "timestamp_utc": datetime.utcnow().isoformat() + "Z",
    }
