from core.decision_processor import apply_decisions
from core.decision_actions import dispatch

def run_cycle():
    actions = apply_decisions()
    results = dispatch(actions)
    return {
        "actions_detected": actions,
        "actions_executed": results
    }
