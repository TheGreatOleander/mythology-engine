from pathlib import Path
import json

INBOX_DIR = Path("decision_inbox")
PROCESSED_DIR = Path("decision_archive")

INBOX_DIR.mkdir(exist_ok=True)
PROCESSED_DIR.mkdir(exist_ok=True)

def read_decisions():
    decisions = []
    for file in INBOX_DIR.glob("*.json"):
        try:
            data = json.loads(file.read_text(encoding="utf-8"))
            decisions.append((file, data))
        except Exception:
            continue
    return decisions

def archive(file):
    target = PROCESSED_DIR / file.name
    file.rename(target)

def process_decisions():
    results = []
    for file, decision in read_decisions():
        results.append(decision)
        archive(file)
    return results
