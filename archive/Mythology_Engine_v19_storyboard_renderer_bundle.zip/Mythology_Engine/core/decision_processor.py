from core.decision_inbox import process_decisions

def apply_decisions():
    results = process_decisions()

    actions = {
        "approved_for_publish": [],
        "rejected": [],
        "regenerate_requested": []
    }

    for decision in results:
        kind = decision.get("operator_decision")
        eid = decision.get("episode_id")

        if kind in actions:
            actions[kind].append(eid)

    return actions
