from core.engine_cycle import run_cycle

if __name__ == "__main__":
    result = run_cycle()
    print("Engine cycle results:")
    print(result)
