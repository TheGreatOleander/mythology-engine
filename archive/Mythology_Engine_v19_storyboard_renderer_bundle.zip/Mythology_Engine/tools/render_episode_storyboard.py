import json
from pathlib import Path
from media.ffmpeg_storyboard import build_ffmpeg_plan, render_stub

def render_episode(epdir):

    ep = Path(epdir)

    scene_plan = ep / "scene_plan.json"
    audio = ep / "narration.wav"
    output = ep / "video_render.mp4"

    plan = build_ffmpeg_plan(scene_plan, audio, output)

    render_stub(plan)

    print("Storyboard render complete.")

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python render_episode_storyboard.py <episode_dir>")
    else:
        render_episode(sys.argv[1])
