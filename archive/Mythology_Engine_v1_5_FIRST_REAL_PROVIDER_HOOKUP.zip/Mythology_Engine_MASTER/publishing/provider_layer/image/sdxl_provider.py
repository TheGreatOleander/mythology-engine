from pathlib import Path

class SDXLProvider:
    name = "sdxl"

    def status(self):
        return {
            "provider": self.name,
            "ready": False,
            "binary": None,
            "capabilities": ["thumbnail_generation", "scene_generation", "social_card_generation"],
            "note": "Wire to local SDXL or hosted API."
        }

    def generate_stub(self, prompt, output_path="examples/releases/output/image_prompt.txt"):
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("SDXL PLACEHOLDER\n\nprompt=" + prompt, encoding="utf-8")
        return str(out)
