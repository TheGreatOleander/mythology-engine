# Mythology Engine MASTER REPO

A consolidated standalone repo for the Mythology Engine core.

## Demo
```bash
python runtime/demo_cycle.py
```

## Repo boundary
This repo is the content studio core.

Future separate repos:
- Media PR Engine
- GestureFX Engine


## Studio Layer (v1.1)

The operator layer now lives **inside the same repo**.

Use it to run the engine in different modes:

```bash
python runtime/run_studio.py --mode manual --action full-cycle
python runtime/run_studio.py --mode assisted --action release-package
python runtime/run_studio.py --mode auto --action full-cycle --publish
```

### Run modes

- `manual` — AI prepares assets; human reviews and publishes
- `assisted` — AI prepares assets; human approves major steps
- `auto` — AI attempts end-to-end execution with wired providers

### Actions

- `full-cycle` — run the full production cycle
- `release-package` — build or inspect the release package
- `status` — inspect configuration and provider readiness


## CLI Command Layer (v1.2)

Mythology Engine now includes an installable command-line entrypoint.

### Install locally

```bash
python -m pip install -e .
```

### Use the command

```bash
mythology --mode manual --action full-cycle
mythology --mode manual --action status
mythology --mode assisted --action release-package
mythology --mode auto --action full-cycle --publish
```

### Shortcuts

A `Makefile` is included for convenience:

```bash
make install
make run
make status
make release
make demo
```


## Provider Wiring Layer (v1.3)

Mythology Engine now includes a more explicit provider wiring layer inside the same repo.

### Check provider status

```bash
mythology --mode manual --action providers
```

### Included provider scaffolds

- `ffmpeg` for video assembly
- `piper` for narration / TTS
- `sdxl` for image generation

### Why this matters

This is the step where the system starts moving from a pure framework toward a usable studio runtime.
It gives you a clean place to wire real providers without turning the repo into spaghetti.


## Bootstrap / Install Polish (v1.4)

Mythology Engine now includes a practical bootstrap layer for first-run setup.

### Bootstrap the environment

```bash
python bootstrap/tools/run_bootstrap.py
```

### Termux helper

```bash
bash bootstrap/scripts/setup_termux.sh
```

### What bootstrap does

- checks the environment
- creates runtime folders
- checks base provider readiness
- writes an initial config bundle

This is the step that makes the repo feel much more like a tool you can bring up intentionally instead of a box of sharp parts.\n

## First Real Provider Hookup (v1.5)

Mythology Engine now includes its first more concrete provider execution path.

### Test the FFmpeg provider

```bash
mythology --mode manual --action provider-test
```

This action:

- builds a real FFmpeg command
- attempts execution if FFmpeg is installed
- records command details and output
- falls back to a placeholder artifact if the environment is not ready

This is the first step from provider scaffolding into actual execution.
