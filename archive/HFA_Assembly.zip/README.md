# Human-First Assembly (HFA) - Full Assembly Version

**Purpose:** Complete educational assembly language package for early CPU concepts.

**Audience:** Anyone familiar with binary analysis or early assembly programming, e.g., authors of Learning Linux Binary Analysis.

**Design Goals:**
- Human-readable assembly
- Full instruction set
- Registers and memory model
- Sample programs with conceptual binary output
