# Error Handling

- Undefined labels -> compile-time error
- Invalid instructions -> compile-time error
- Register overflow -> runtime warning/error
