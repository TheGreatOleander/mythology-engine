# Simple I/O
READ -> R0
PRINT R0
