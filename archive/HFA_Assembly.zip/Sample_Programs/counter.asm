# Counter from 1 to 5
LOAD 1 -> R1
LABEL loop_start
CMP R1, 5
JGT loop_end
PRINT R1
ADD R1, R1, 1
JMP loop_start
LABEL loop_end
