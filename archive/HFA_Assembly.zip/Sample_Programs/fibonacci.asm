# Fibonacci first N numbers
LOAD 0 -> R0
LOAD 1 -> R1
LOAD 10 -> R2   # N
LABEL fib_loop
PRINT R0
ADD R3, R0, R1
MOV R0, R1
MOV R1, R3
SUB R2, R2, 1
JNZ fib_loop
