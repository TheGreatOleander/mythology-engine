# HFA Instruction Set (ISA)

## Arithmetic
ADD dest, src1, src2    # dest = src1 + src2
SUB dest, src1, src2    # dest = src1 - src2
MUL dest, src1, src2    # dest = src1 * src2
DIV dest, src1, src2    # dest = src1 / src2

## Logic
AND dest, src1, src2
OR dest, src1, src2
NOT dest, src

## Data Movement
LOAD value -> Rn       # Load immediate into register
STORE Rn -> addr       # Store register to memory

## Branching
CMP R1, R2             # Compare
JMP label
JZ label               # Jump if zero flag set
JNZ label              # Jump if zero flag not set

## I/O
READ -> Rn
PRINT Rn
