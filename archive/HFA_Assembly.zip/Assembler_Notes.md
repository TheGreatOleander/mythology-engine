# Assembler Notes

- Map each human-readable instruction to a binary opcode
- Track labels for jumps
- Allocate registers for variables
- Resolve memory addresses
- Optimize redundant operations
