# Registers and Memory Model

## Registers
R0-R7    General-purpose
PC       Program Counter
SP       Stack Pointer
FLAGS    Zero, Sign, Overflow

## Memory
- Byte-addressable
- Direct, indirect, immediate addressing supported
