import json
import urllib.request

def fetch(url, method="GET"):
    req = urllib.request.Request(url, method=method)
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))

base = "http://127.0.0.1:8765"

print("Health:")
print(json.dumps(fetch(base + "/health"), indent=2))

print("\nYouTube intelligence:")
print(json.dumps(fetch(base + "/youtube-intelligence"), indent=2))

print("\nGenerate episode:")
print(json.dumps(fetch(base + "/generate-episode", method="POST"), indent=2))
