from installer.engines.first_run import run_first_run_installer
import json

if __name__ == "__main__":
    result = run_first_run_installer()
    print(json.dumps(result, indent=2))
