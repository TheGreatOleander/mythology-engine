from episode_factory.factory import run_factory
from youtube_intelligence.engines.intelligence_report import build_report

def generate_episode_service(queue=False):
    return run_factory(queue_for_publish=queue)

def youtube_intelligence_service():
    return build_report()

def health_service():
    return {
        "status": "ok",
        "service": "mythology_local_api_bridge",
        "mode": "local_only"
    }
