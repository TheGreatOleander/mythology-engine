from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from api_bridge.services.local_service import (
    generate_episode_service,
    youtube_intelligence_service,
    health_service
)

class MythologyHandler(BaseHTTPRequestHandler):
    def _send(self, payload, code=200):
        data = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/health":
            self._send(health_service())
        elif self.path == "/youtube-intelligence":
            self._send(youtube_intelligence_service())
        else:
            self._send({"error": "not_found", "path": self.path}, code=404)

    def do_POST(self):
        if self.path == "/generate-episode":
            self._send(generate_episode_service(queue=False))
        elif self.path == "/generate-and-queue":
            self._send(generate_episode_service(queue=True))
        else:
            self._send({"error": "not_found", "path": self.path}, code=404)

def run_server(host="127.0.0.1", port=8765):
    server = HTTPServer((host, port), MythologyHandler)
    print(f"Mythology local API bridge running on http://{host}:{port}")
    server.serve_forever()

if __name__ == "__main__":
    run_server()
