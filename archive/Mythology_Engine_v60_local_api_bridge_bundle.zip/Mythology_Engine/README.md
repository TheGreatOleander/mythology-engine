# Mythology Engine v60 – Local API Bridge Bundle

This version adds a lightweight local HTTP bridge for Mission Control.

## Why this matters

The Android app now has a clear integration target.

## Start here

Run installer:

`python tools/first_run_install.py`

Start the local API bridge:

`python tools/start_local_api_bridge.py`

Test requests:

`python tools/demo_local_api_requests.py`

## Endpoints

- `GET /health`
- `GET /youtube-intelligence`
- `POST /generate-episode`
- `POST /generate-and-queue`
