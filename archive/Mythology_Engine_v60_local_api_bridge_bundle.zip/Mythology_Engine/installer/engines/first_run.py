import json
from pathlib import Path

QUESTIONS = [
    ("channel_name", "Channel name", "The Hidden Archive"),
    ("output_dir", "Output directory", "episodes"),
    ("primary_platform", "Primary platform", "youtube"),
    ("writing_provider", "Writing provider", "openai"),
    ("tts_provider", "TTS provider", "piper"),
    ("image_provider", "Image provider", "sdxl"),
    ("publish_provider", "Publish provider", "manual"),
]

def run_first_run_installer():
    answers = {}
    print("MYTHOLOGY ENGINE – FIRST RUN INSTALLER\n")
    for key, label, default in QUESTIONS:
        raw = input(f"{label} [{default}]: ").strip()
        answers[key] = raw or default

    secrets = Path("secrets/local_secrets.json")
    secrets.parent.mkdir(parents=True, exist_ok=True)
    secrets.write_text(json.dumps(answers, indent=2), encoding="utf-8")

    config = Path("config/runtime_config.json")
    config.parent.mkdir(parents=True, exist_ok=True)
    config.write_text(json.dumps(answers, indent=2), encoding="utf-8")

    gitignore = Path(".gitignore")
    existing = gitignore.read_text(encoding="utf-8").splitlines() if gitignore.exists() else []
    for line in ["secrets/local_secrets.json", "__pycache__/", "*.pyc", "episodes/"]:
        if line not in existing:
            existing.append(line)
    gitignore.write_text("\n".join(existing).strip() + "\n", encoding="utf-8")

    return {
        "secrets_path": str(secrets),
        "config_path": str(config),
        "answers": answers
    }
