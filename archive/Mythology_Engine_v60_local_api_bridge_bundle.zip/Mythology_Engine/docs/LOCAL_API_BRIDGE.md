# Local API Bridge

This bundle adds a small local HTTP bridge so the Android Mission Control app
can talk to Mythology Engine without a heavyweight always-on backend.

## Why this was the right pick

A tiny local bridge is better than a giant service because it:

- keeps RAM use low
- is easier to debug
- is easy to start and stop
- fits Android / Tasker / Termux workflows well

## Endpoints

### GET /health
Check whether the bridge is running.

### GET /youtube-intelligence
Return the current YouTube intelligence report.

### POST /generate-episode
Trigger Episode Factory without queueing.

### POST /generate-and-queue
Trigger Episode Factory and return publish preview data.

## Run

`python tools/start_local_api_bridge.py`

Then from another terminal:

`python tools/demo_local_api_requests.py`

## Android direction

The Mission Control app can call these local endpoints:
- on a desktop LAN host
- through localhost in a Termux or embedded runtime scenario
- through a small relay later if needed

This is the cleanest bridge between UI and engine so far.
