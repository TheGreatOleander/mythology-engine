# Why Local API Now

This was chosen over real YouTube API wiring first because the product needs a
clean control surface before it needs perfect cloud connectors.

With a local API bridge, the system now has:

- engine
- installer
- intelligence
- control interface entry point

That makes the Android app much more meaningful immediately.
