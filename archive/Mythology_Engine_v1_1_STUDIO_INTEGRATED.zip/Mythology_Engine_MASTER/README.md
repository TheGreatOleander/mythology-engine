# Mythology Engine MASTER REPO

A consolidated standalone repo for the Mythology Engine core.

## Demo
```bash
python runtime/demo_cycle.py
```

## Repo boundary
This repo is the content studio core.

Future separate repos:
- Media PR Engine
- GestureFX Engine


## Studio Layer (v1.1)

The operator layer now lives **inside the same repo**.

Use it to run the engine in different modes:

```bash
python runtime/run_studio.py --mode manual --action full-cycle
python runtime/run_studio.py --mode assisted --action release-package
python runtime/run_studio.py --mode auto --action full-cycle --publish
```

### Run modes

- `manual` — AI prepares assets; human reviews and publishes
- `assisted` — AI prepares assets; human approves major steps
- `auto` — AI attempts end-to-end execution with wired providers

### Actions

- `full-cycle` — run the full production cycle
- `release-package` — build or inspect the release package
- `status` — inspect configuration and provider readiness
