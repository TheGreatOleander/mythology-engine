import json
from pipeline_manager.engines.pipeline_engine import list_pipeline, summarize_pipeline

print(json.dumps({
    "summary": summarize_pipeline(),
    "episodes": list_pipeline()
}, indent=2))
