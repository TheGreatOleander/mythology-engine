import sys
import json
from pipeline_manager.engines.pipeline_engine import move_state

if len(sys.argv) < 3:
    print("Usage: python tools/pipeline_move_state.py <episode_id> <new_state>")
else:
    rec = move_state(sys.argv[1], sys.argv[2])
    print(json.dumps(rec, indent=2))
