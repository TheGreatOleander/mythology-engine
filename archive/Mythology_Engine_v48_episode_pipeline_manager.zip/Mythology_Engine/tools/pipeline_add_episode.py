import sys
import json
from pipeline_manager.engines.pipeline_engine import add_episode

if len(sys.argv) < 3:
    print("Usage: python tools/pipeline_add_episode.py <episode_id> <topic> [title]")
else:
    episode_id = sys.argv[1]
    topic = sys.argv[2]
    title = sys.argv[3] if len(sys.argv) > 3 else ""
    rec = add_episode(episode_id, topic, title=title)
    print(json.dumps(rec, indent=2))
