# Episode Pipeline Manager

This module turns Mythology Engine into a production assembly line.

## States

- IDEA
- SCRIPTED
- ASSETS_GENERATED
- RENDERED
- READY_TO_PUBLISH
- PUBLISHED
- ANALYZED

## Why it matters

Instead of scattered files and ad-hoc workflow, the system now tracks where
each episode lives in the production process.

That makes Mission Control much more useful, because it can show:

- what is only an idea
- what is ready to render
- what is waiting to publish
- what has already been analyzed

## Tools

Add episode:
`python tools/pipeline_add_episode.py <episode_id> <topic> [title]`

Move state:
`python tools/pipeline_move_state.py <episode_id> <new_state>`

Show status:
`python tools/pipeline_status.py`
