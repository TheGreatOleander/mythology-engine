# Mythology Engine v48 – Episode Pipeline Manager

This version adds a production-state manager for episodes.

## What it does

Track every episode through a defined lifecycle:

IDEA
→ SCRIPTED
→ ASSETS_GENERATED
→ RENDERED
→ READY_TO_PUBLISH
→ PUBLISHED
→ ANALYZED

## Why it matters

This turns the project from a loose collection of creative tools into a real
production assembly line.

## Commands

Add episode:
`python tools/pipeline_add_episode.py <episode_id> <topic> [title]`

Move state:
`python tools/pipeline_move_state.py <episode_id> <new_state>`

Show status:
`python tools/pipeline_status.py`
