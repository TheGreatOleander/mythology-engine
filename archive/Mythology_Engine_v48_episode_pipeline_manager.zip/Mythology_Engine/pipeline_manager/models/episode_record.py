from dataclasses import dataclass, asdict

@dataclass
class EpisodeRecord:
    episode_id: str
    topic: str
    state: str
    title: str = ""
    notes: str = ""

    def to_dict(self):
        return asdict(self)
