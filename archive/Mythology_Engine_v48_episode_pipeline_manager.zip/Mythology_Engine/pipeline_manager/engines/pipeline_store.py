import json
from pathlib import Path

STORE = Path("examples/pipeline_records.json")

def load_records():
    if STORE.exists():
        return json.loads(STORE.read_text(encoding="utf-8"))
    return []

def save_records(records):
    STORE.write_text(json.dumps(records, indent=2), encoding="utf-8")
    return str(STORE)
