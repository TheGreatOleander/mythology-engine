from pipeline_manager.models.pipeline_state import PIPELINE_STATES
from pipeline_manager.models.episode_record import EpisodeRecord
from pipeline_manager.engines.pipeline_store import load_records, save_records

def add_episode(episode_id, topic, title="", notes=""):
    records = load_records()
    rec = EpisodeRecord(
        episode_id=episode_id,
        topic=topic,
        state="IDEA",
        title=title,
        notes=notes
    )
    records.append(rec.to_dict())
    save_records(records)
    return rec.to_dict()

def move_state(episode_id, new_state):
    if new_state not in PIPELINE_STATES:
        raise ValueError(f"Invalid state: {new_state}")

    records = load_records()
    updated = None

    for r in records:
        if r["episode_id"] == episode_id:
            r["state"] = new_state
            updated = r
            break

    save_records(records)
    return updated

def list_pipeline():
    return load_records()

def summarize_pipeline():
    records = load_records()
    summary = {state: 0 for state in PIPELINE_STATES}
    for r in records:
        state = r.get("state")
        if state in summary:
            summary[state] += 1
    return summary
