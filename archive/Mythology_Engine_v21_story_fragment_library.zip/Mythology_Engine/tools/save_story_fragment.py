from story_library.fragment_store import save_fragment

if __name__ == "__main__":
    text = input("Paste story fragment:\n")
    tags = input("Tags (comma separated): ").split(",")
    entry = save_fragment(text, [t.strip() for t in tags if t.strip()])
    print("Saved fragment:", entry["id"])
