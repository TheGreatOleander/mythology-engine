from story_library.fragment_store import search

if __name__ == "__main__":
    q = input("Search keyword: ")
    results = search(q)

    print("\nResults:")
    for r in results:
        print(r["id"], "-", r["tags"], "-", r["file"])
