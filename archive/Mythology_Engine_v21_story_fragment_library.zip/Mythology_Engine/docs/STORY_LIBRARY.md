# Story Fragment Library

Stores story fragments as markdown files so ideas are never lost.

Save fragment:
python tools/save_story_fragment.py

Search fragments:
python tools/search_story_library.py
