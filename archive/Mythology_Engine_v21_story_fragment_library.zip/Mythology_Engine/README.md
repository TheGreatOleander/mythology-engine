# Mythology Engine – Story Fragment Library

Adds a searchable archive for story fragments.

Features:
- Markdown fragment storage
- Tagging
- Searchable index
