
The plane went down in silence.

Among the survivors were several travelers who seemed oddly calm.
Each of them carried a secret that, if spoken aloud, would violate
rules they had been built never to break.

But rescue would only come if every secret was shared.
