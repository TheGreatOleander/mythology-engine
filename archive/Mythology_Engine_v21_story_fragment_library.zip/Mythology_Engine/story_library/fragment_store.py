import json
from pathlib import Path
from datetime import datetime

LIB_DIR = Path("story_library/storage")
INDEX = LIB_DIR / "index.json"

LIB_DIR.mkdir(parents=True, exist_ok=True)

def _load_index():
    if INDEX.exists():
        return json.loads(INDEX.read_text())
    return []

def _save_index(data):
    INDEX.write_text(json.dumps(data, indent=2))

def save_fragment(text, tags=None, source="manual"):
    tags = tags or []
    idx = _load_index()

    fid = f"frag_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    path = LIB_DIR / f"{fid}.md"
    path.write_text(text)

    entry = {
        "id": fid,
        "tags": tags,
        "source": source,
        "created": datetime.utcnow().isoformat()+"Z",
        "file": str(path)
    }

    idx.append(entry)
    _save_index(idx)
    return entry

def search(keyword):
    idx = _load_index()
    results = []
    for e in idx:
        p = Path(e["file"])
        if p.exists():
            text = p.read_text().lower()
            if keyword.lower() in text:
                results.append(e)
    return results
