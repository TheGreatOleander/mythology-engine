# Mythology Engine v110 – Audience Interaction Engine

This version introduces an engine that turns audience comments into structured creative signals.

## Run

python runtime/tools/demo_audience_interaction.py

## Output

- categorized comment signals
- extracted questions
- extracted theories
- extracted episode requests
- recommended focus for future content
