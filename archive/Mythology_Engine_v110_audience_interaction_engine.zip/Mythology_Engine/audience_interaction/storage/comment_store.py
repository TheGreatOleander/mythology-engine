from pathlib import Path
import json

class CommentStore:
    def __init__(self, path="examples/comments/comments.json"):
        self.path = Path(path)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def load(self):
        return json.loads(self.path.read_text(encoding="utf-8"))
