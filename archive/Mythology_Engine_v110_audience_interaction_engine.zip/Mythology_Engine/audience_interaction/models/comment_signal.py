class CommentSignal:
    def __init__(self, author, text, category, weight=1):
        self.author = author
        self.text = text
        self.category = category
        self.weight = weight

    def to_dict(self):
        return {
            "author": self.author,
            "text": self.text,
            "category": self.category,
            "weight": self.weight
        }
