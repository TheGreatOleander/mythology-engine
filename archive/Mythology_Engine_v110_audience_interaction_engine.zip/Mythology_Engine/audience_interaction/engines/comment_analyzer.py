from audience_interaction.models.comment_signal import CommentSignal

QUESTION_WORDS = ["who", "what", "when", "where", "why", "how"]
THEORY_WORDS = ["i think", "maybe", "perhaps", "theory", "could be", "might be"]
REQUEST_WORDS = ["cover", "do an episode", "please do", "talk about", "next video"]

def analyze_comment(comment):
    text = comment.get("text", "")
    lowered = text.lower()

    if any(w in lowered for w in REQUEST_WORDS):
        return CommentSignal(comment.get("author","unknown"), text, "episode_request", 3)

    if any(w in lowered for w in THEORY_WORDS):
        return CommentSignal(comment.get("author","unknown"), text, "audience_theory", 2)

    if "?" in lowered or any(lowered.startswith(w) for w in QUESTION_WORDS):
        return CommentSignal(comment.get("author","unknown"), text, "question", 2)

    return CommentSignal(comment.get("author","unknown"), text, "general_discussion", 1)
