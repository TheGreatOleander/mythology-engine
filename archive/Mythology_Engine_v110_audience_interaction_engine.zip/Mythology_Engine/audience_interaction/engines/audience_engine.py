from audience_interaction.storage.comment_store import CommentStore
from audience_interaction.engines.comment_analyzer import analyze_comment
from audience_interaction.engines.lead_extractor import extract_leads

class AudienceInteractionEngine:
    def __init__(self):
        self.store = CommentStore()

    def run(self):
        comments = self.store.load()
        signals = [analyze_comment(c).to_dict() for c in comments]
        leads = extract_leads(signals)

        return {
            "comments_processed": len(comments),
            "signals": signals,
            "leads": leads,
            "recommended_focus": self._recommend_focus(leads)
        }

    def _recommend_focus(self, leads):
        if leads["episode_requests"]:
            return "Build next episode around strongest audience request."
        if leads["questions"]:
            return "Use top audience questions as continuity fuel."
        if leads["theories"]:
            return "Fold audience theories into future mystery threads."
        return "No strong external lead detected."
