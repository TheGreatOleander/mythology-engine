def extract_leads(signals):
    leads = {
        "questions": [],
        "theories": [],
        "episode_requests": []
    }

    for s in signals:
        if s["category"] == "question":
            leads["questions"].append(s)
        elif s["category"] == "audience_theory":
            leads["theories"].append(s)
        elif s["category"] == "episode_request":
            leads["episode_requests"].append(s)

    return leads
