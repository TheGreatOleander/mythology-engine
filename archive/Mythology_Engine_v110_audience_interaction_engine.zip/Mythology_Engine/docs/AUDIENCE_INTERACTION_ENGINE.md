# Audience Interaction Engine

This module lets audience response feed back into the mythology.

## Purpose

- read comments
- classify signals
- extract questions
- extract theories
- extract episode requests

## Why it matters

This is how the audience starts shaping the channel universe instead of merely watching it.
