from audience_interaction.engines.audience_engine import AudienceInteractionEngine
import json

engine = AudienceInteractionEngine()
print(json.dumps(engine.run(), indent=2))
