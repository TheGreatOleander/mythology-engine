# Mythology Engine v34 – Render Executor Bundle

This version adds the first real execution layer for the cinematic engine.

## What it adds

- render executor
- concat file writer
- live/dry-run FFmpeg execution
- render reports

## Workflow

1. Generate a render plan
2. Review the plan
3. Execute as dry run
4. Execute live when assets are ready
