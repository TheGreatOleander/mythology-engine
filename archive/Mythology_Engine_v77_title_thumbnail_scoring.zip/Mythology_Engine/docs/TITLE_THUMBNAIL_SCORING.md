# Title + Thumbnail Scoring Engine

Purpose:

Select the strongest combination of:

- video title
- thumbnail prompt

before publishing.

API:

GET /optimize

Returns ranked candidates and best pair.
