# Mythology Engine v77 – Title + Thumbnail Scoring

Adds a scoring engine to select the strongest title and thumbnail before publishing.

Endpoint:

GET /optimize

Start:

python tools/start_api.py
