from studio.engines.optimization_engine import optimize

def optimize_service(topic="ancient map discovery"):
    return optimize(topic)
