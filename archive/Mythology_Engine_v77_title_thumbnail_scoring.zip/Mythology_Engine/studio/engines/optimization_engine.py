from optimization.title_engine.title_generator import generate_titles
from optimization.thumbnail_engine.thumbnail_prompts import generate_thumbnail_prompts
from optimization.scoring_engine.scorer import select_best

def optimize(topic):

    titles = generate_titles(topic)
    thumbs = generate_thumbnail_prompts(topic)

    return select_best(titles, thumbs)
