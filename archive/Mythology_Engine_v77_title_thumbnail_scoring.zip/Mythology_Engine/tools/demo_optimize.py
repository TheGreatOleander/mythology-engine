import urllib.request,json

BASE="http://127.0.0.1:8765"

with urllib.request.urlopen(BASE+"/optimize") as r:
    print(json.dumps(json.loads(r.read().decode()), indent=2))
