import random

def score_title(title):

    score = 0

    if "Secret" in title:
        score += 2
    if "Truth" in title:
        score += 2
    if "Shouldn't Exist" in title:
        score += 3

    score += random.randint(0,4)

    return score


def score_thumbnail(prompt):

    score = random.randint(5,10)

    if "cinematic" in prompt:
        score += 2
    if "dramatic" in prompt:
        score += 2

    return score


def select_best(titles, thumbnails):

    scored_titles = [(t, score_title(t)) for t in titles]
    scored_thumbs = [(p, score_thumbnail(p)) for p in thumbnails]

    best_title = sorted(scored_titles, key=lambda x: x[1], reverse=True)[0]
    best_thumb = sorted(scored_thumbs, key=lambda x: x[1], reverse=True)[0]

    return {
        "best_title": best_title,
        "best_thumbnail_prompt": best_thumb,
        "title_candidates": scored_titles,
        "thumbnail_candidates": scored_thumbs
    }
