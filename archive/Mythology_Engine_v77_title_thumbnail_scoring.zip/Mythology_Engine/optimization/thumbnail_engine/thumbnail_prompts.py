def generate_thumbnail_prompts(topic):

    return [
        f"ancient {topic} glowing under torchlight cinematic",
        f"mysterious {topic} discovery dramatic lighting",
        f"{topic} map artifact documentary style",
        f"lost {topic} revealed dusty archive cinematic"
    ]
