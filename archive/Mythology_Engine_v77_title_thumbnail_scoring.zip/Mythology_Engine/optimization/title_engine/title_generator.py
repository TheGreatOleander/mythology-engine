def generate_titles(topic):

    return [
        f"The {topic} That Shouldn't Exist",
        f"Scientists Finally Decoded the {topic}",
        f"The Shocking Truth About the {topic}",
        f"This {topic} Changes Everything",
        f"The Hidden Secret of the {topic}"
    ]
