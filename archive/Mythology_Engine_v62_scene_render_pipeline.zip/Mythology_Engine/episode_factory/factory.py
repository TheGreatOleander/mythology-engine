from pathlib import Path
import datetime

def generate_script():
    return """TITLE: Ancient Map Discovery

## HOOK
A map found beneath centuries of dust may change history.

## STORY
Researchers uncovered symbols pointing to a forgotten trade route.

## MYSTERY
The route may lead to a lost city never recorded in history.
"""

def create_episode_folder():
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    ep = Path("examples") / f"EP_{stamp}"
    ep.mkdir(parents=True, exist_ok=True)
    return ep
