# Scene Render Pipeline

This version introduces a simple scene pipeline.

Flow:

script -> scene list -> rendered scene files

POST /render-episode

Returns:

{
  "episode_dir": "...",
  "scene_count": 5,
  "manifest": "scene_manifest.json"
}

Each scene includes:

- narration
- visual prompt
