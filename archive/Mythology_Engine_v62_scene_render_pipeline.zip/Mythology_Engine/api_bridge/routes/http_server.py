from http.server import BaseHTTPRequestHandler, HTTPServer
import json

from api_bridge.services.local_service import render_episode_service, health_service

class Handler(BaseHTTPRequestHandler):

    def send(self,data,code=200):
        body=json.dumps(data,indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path=="/health":
            self.send(health_service())
        else:
            self.send({"error":"not_found","path":self.path},404)

    def do_POST(self):
        if self.path=="/render-episode":
            self.send(render_episode_service())
        else:
            self.send({"error":"not_found","path":self.path},404)

def run_server(host="127.0.0.1",port=8765):
    s=HTTPServer((host,port),Handler)
    print(f"Mythology Render API running http://{host}:{port}")
    s.serve_forever()

if __name__=="__main__":
    run_server()
