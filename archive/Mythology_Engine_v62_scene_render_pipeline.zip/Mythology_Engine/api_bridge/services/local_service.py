from render_pipeline.tools.render_episode import run_render

def render_episode_service():
    return run_render()

def health_service():
    return {"status": "ok", "service": "mythology_render_pipeline"}
