class Scene:
    def __init__(self, index, narration, visual_prompt):
        self.index = index
        self.narration = narration
        self.visual_prompt = visual_prompt

    def to_dict(self):
        return {
            "index": self.index,
            "narration": self.narration,
            "visual_prompt": self.visual_prompt
        }
