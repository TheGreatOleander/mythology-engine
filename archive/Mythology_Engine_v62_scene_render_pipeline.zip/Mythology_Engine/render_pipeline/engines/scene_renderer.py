import json
from pathlib import Path

def render_scenes(scenes, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    manifest = []

    for scene in scenes:
        scene_file = output / f"scene_{scene.index:03}.json"
        scene_file.write_text(json.dumps(scene.to_dict(), indent=2))

        manifest.append({
            "scene_index": scene.index,
            "file": str(scene_file)
        })

    manifest_file = output / "scene_manifest.json"
    manifest_file.write_text(json.dumps(manifest, indent=2))

    return {
        "scene_count": len(scenes),
        "manifest": str(manifest_file)
    }
