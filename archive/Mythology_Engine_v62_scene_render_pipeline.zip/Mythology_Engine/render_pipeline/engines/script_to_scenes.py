from render_pipeline.models.scene import Scene

def convert_script_to_scenes(script_text):
    lines = [l.strip() for l in script_text.split("\n") if l.strip()]
    scenes = []

    idx = 1
    for line in lines:
        if line.startswith("##"):
            continue
        scenes.append(
            Scene(
                index=idx,
                narration=line,
                visual_prompt=f"cinematic documentary still of {line}"
            )
        )
        idx += 1

    return scenes
