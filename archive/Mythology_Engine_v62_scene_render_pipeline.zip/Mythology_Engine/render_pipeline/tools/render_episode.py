from episode_factory.factory import generate_script, create_episode_folder
from render_pipeline.engines.script_to_scenes import convert_script_to_scenes
from render_pipeline.engines.scene_renderer import render_scenes

def run_render():
    script = generate_script()
    episode_dir = create_episode_folder()

    script_file = episode_dir / "script.txt"
    script_file.write_text(script)

    scenes = convert_script_to_scenes(script)
    result = render_scenes(scenes, episode_dir / "scenes")

    return {
        "episode_dir": str(episode_dir),
        "scene_count": result["scene_count"],
        "manifest": result["manifest"]
    }

if __name__ == "__main__":
    print(run_render())
