# Mythology Engine v62 – Scene Render Pipeline

This version adds the first cinematic layer.

Pipeline:

script -> scenes -> scene manifest

Endpoint:

POST /render-episode

Run:

python render_pipeline/tools/render_episode.py
