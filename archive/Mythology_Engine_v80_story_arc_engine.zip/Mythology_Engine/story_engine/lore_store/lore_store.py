import json
from pathlib import Path

STORE = Path("examples/story_arcs/lore.json")

def load():
    if STORE.exists():
        return json.loads(STORE.read_text())
    return {"arcs":[]}

def save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(data, indent=2))

def add_arc(arc):
    data = load()
    data["arcs"].append(arc)
    save(data)
    return arc
