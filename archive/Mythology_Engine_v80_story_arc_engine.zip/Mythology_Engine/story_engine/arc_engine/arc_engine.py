import datetime
from story_engine.episode_planner.planner import plan_episode_titles
from story_engine.lore_store.lore_store import add_arc

def create_arc(topic="Ancient Map Discovery", episodes=5):

    titles = plan_episode_titles(topic, episodes)

    arc = {
        "arc_id": datetime.datetime.utcnow().strftime("ARC_%Y%m%d_%H%M%S"),
        "topic": topic,
        "episodes": [
            {"episode_number": i+1, "title": titles[i]}
            for i in range(len(titles))
        ]
    }

    add_arc(arc)

    return arc
