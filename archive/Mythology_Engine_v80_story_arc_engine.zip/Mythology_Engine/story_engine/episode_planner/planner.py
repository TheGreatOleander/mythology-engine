def plan_episode_titles(topic, episodes=5):

    titles = []

    for i in range(episodes):
        titles.append(
            f"{topic} – Part {i+1}: "
            + [
                "The Discovery",
                "The Hidden Evidence",
                "The Forbidden Map",
                "The Lost Expedition",
                "The Final Secret"
            ][i % 5]
        )

    return titles
