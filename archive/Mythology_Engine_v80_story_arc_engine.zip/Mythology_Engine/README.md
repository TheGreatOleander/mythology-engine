# Mythology Engine v80 – Story Arc Engine

Adds multi‑episode narrative planning to the system.

Endpoint:

POST /story-arc

This allows the channel to publish binge‑worthy series rather than isolated episodes.
