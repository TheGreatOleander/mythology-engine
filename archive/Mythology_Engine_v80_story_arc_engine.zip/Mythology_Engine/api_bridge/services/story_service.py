from story_engine.arc_engine.arc_engine import create_arc

def create_arc_service():
    return create_arc()
