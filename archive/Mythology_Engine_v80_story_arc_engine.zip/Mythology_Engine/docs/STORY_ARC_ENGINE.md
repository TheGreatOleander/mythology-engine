# Story Arc Engine

Creates multi‑episode narrative arcs so the channel can publish series instead of isolated videos.

Endpoint:

POST /story-arc

Returns:

- arc_id
- topic
- episode list
