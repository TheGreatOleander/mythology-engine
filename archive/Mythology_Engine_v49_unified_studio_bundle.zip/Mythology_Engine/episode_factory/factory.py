from providers.registry import get_writing_provider,get_tts_provider,get_image_provider
import pathlib,datetime,json

EPDIR=pathlib.Path("episodes")
EPDIR.mkdir(exist_ok=True)

def run_factory(queue_for_publish=False):

    writing=get_writing_provider()
    tts=get_tts_provider()
    img=get_image_provider()

    topic="Ancient Map Discovery"

    stamp=datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    ep=EPDIR/f"EP_{stamp}"
    ep.mkdir()

    script=writing.generate_script(topic)
    (ep/"script.txt").write_text(script)

    audio=tts.generate_audio(script,str(ep/"narration.wav"))

    img.generate_image("ancient mysterious map",str(ep/"scene.png"))

    manifest={
        "topic":topic,
        "script":str(ep/"script.txt"),
        "audio":audio
    }

    (ep/"manifest.json").write_text(json.dumps(manifest,indent=2))

    return manifest
