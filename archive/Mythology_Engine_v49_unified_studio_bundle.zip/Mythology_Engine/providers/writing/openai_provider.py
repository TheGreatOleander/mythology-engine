from providers.writing.base import BaseWritingProvider
class OpenAIWritingProvider(BaseWritingProvider):
    name="openai"
    def generate_script(self, topic:str)->str:
        return f"Documentary narration about {topic}. Ancient clues emerge..."
