from providers.writing.openai_provider import OpenAIWritingProvider
from providers.tts.piper_provider import PiperTTSProvider
from providers.image.sdxl_provider import SDXLImageProvider
from providers.publish.manual_provider import ManualPublishProvider

def get_writing_provider(): return OpenAIWritingProvider()
def get_tts_provider(): return PiperTTSProvider()
def get_image_provider(): return SDXLImageProvider()
def get_publish_provider(): return ManualPublishProvider()
