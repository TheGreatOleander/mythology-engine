class BaseTTSProvider:
    name="base"
    def generate_audio(self, text:str, path:str):
        open(path,"w").write(text)
        return path
