from providers.tts.base import BaseTTSProvider
class PiperTTSProvider(BaseTTSProvider):
    name="piper"
