class ManualPublishProvider:
    name="manual"
    def upload(self,video,title,desc):
        return {"status":"manual","video":video,"title":title}
