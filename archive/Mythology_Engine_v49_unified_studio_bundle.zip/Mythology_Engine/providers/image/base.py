class BaseImageProvider:
    name="base"
    def generate_image(self,prompt,path):
        open(path,"w").write(prompt)
        return path
