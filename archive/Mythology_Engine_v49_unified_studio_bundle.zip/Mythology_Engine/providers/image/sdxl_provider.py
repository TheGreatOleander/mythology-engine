from providers.image.base import BaseImageProvider
class SDXLImageProvider(BaseImageProvider):
    name="sdxl"
