import random

def optimize(titles,thumbs):
    results=[]
    for t in titles:
        for th in thumbs:
            score=random.randint(1,10)
            results.append((t,th,score))
    return sorted(results,key=lambda x:x[2],reverse=True)
