class PerformanceRecord:
    def __init__(self,topic,views,likes,comments,watch):
        self.topic=topic
        self.views=views
        self.likes=likes
        self.comments=comments
        self.watch=watch

    def score(self):
        return self.views*0.4+self.likes*0.2+self.comments*0.2+self.watch*0.2
