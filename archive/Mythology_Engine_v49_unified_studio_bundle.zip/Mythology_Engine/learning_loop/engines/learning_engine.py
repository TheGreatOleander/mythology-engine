def rank_topics(records):
    scores={}
    for r in records:
        scores.setdefault(r.topic,0)
        scores[r.topic]+=r.score()
    return sorted(scores.items(),key=lambda x:x[1],reverse=True)
