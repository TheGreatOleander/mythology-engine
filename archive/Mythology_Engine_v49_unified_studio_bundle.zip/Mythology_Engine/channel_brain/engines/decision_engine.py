from channel_brain.models.topic_signal import TopicSignal

def choose_next_topic(trends,audience):

    signals={}

    for t in trends:
        signals.setdefault(t,TopicSignal(t,trend=5))

    for a in audience:
        if a in signals:
            signals[a].audience+=5
        else:
            signals[a]=TopicSignal(a,audience=5)

    ranked=sorted(signals.values(),key=lambda s:s.score(),reverse=True)

    return ranked[0].topic if ranked else None
