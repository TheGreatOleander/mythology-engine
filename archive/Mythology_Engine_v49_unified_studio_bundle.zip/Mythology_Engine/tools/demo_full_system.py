from mission_control.control_center import MissionControl
from channel_brain.engines.decision_engine import choose_next_topic

mc=MissionControl()

print("Generating episode")
ep=mc.generate_episode()
print(ep)

print("Brain selecting topic")
print(choose_next_topic(
    ["Oak Island","Lost Roman Map"],
    ["Oak Island","Atlantis"]
))
