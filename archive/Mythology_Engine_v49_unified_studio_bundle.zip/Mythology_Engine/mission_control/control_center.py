from episode_factory.factory import run_factory

class MissionControl:

    def generate_episode(self):
        return run_factory(queue_for_publish=False)

    def generate_and_queue(self):
        return run_factory(queue_for_publish=True)
