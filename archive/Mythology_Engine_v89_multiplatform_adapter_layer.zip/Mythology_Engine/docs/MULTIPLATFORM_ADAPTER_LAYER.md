# Multi-Platform Adapter Layer

This module converts one story object into platform-specific publish packages.

## Platforms included

- YouTube
- TikTok
- Instagram Reels
- YouTube Shorts
- Podcast

## Purpose

Keep the studio core platform-agnostic while letting adapters define:

- aspect ratio
- target duration
- title style
- description style
- required assets

## Why it matters

This is the layer that lets one myth flow through multiple channels while staying coherent.
