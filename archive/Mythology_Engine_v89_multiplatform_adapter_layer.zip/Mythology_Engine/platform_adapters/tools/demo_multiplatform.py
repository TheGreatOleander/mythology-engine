from platform_adapters.core.adapter_registry import build_all_packages
import json

story = {
    "title": "The Map That Shouldn't Exist",
    "hook": "This map may not be possible.",
    "summary": "An ancient document may point to a forgotten civilization and a lost route beneath history."
}

packages = build_all_packages(story)
print(json.dumps(packages, indent=2))
