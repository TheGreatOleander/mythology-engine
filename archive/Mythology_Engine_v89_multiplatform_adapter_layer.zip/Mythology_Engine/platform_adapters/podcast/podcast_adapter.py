from platform_adapters.core.platform_package import PlatformPackage

def build_podcast_package(story):
    return PlatformPackage(
        platform="podcast",
        aspect_ratio="audio_only",
        duration_target="10-20 min",
        title=story["title"],
        description=f"Audio episode: {story['summary']}",
        assets={
            "audio": "output/podcast_episode.mp3",
            "show_notes": "output/podcast_notes.md",
            "cover_art": "output/podcast_cover.png"
        }
    ).to_dict()
