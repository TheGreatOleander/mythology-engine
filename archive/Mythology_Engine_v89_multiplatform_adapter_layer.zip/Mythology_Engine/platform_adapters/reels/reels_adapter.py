from platform_adapters.core.platform_package import PlatformPackage

def build_reels_package(story):
    return PlatformPackage(
        platform="instagram_reels",
        aspect_ratio="9:16",
        duration_target="30-60 sec",
        title=story["hook"],
        description="Visual teaser cut for Reels.",
        assets={
            "video": "output/reels_vertical.mp4",
            "cover_frame": "output/reels_cover.png"
        }
    ).to_dict()
