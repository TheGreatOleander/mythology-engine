from platform_adapters.core.platform_package import PlatformPackage

def build_youtube_package(story):
    return PlatformPackage(
        platform="youtube",
        aspect_ratio="16:9",
        duration_target="8-15 min",
        title=story["title"],
        description=f"Full documentary episode: {story['summary']}",
        assets={
            "video": "output/youtube_longform.mp4",
            "thumbnail": "output/youtube_thumbnail.png",
            "captions": "output/youtube_captions.srt"
        }
    ).to_dict()
