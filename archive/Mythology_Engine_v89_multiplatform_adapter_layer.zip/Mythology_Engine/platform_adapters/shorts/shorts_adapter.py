from platform_adapters.core.platform_package import PlatformPackage

def build_shorts_package(story):
    return PlatformPackage(
        platform="youtube_shorts",
        aspect_ratio="9:16",
        duration_target="15-60 sec",
        title=f"{story['hook']} | Shorts",
        description="Short-form funnel clip for the main episode.",
        assets={
            "video": "output/shorts_vertical.mp4",
            "captions": "output/shorts_captions.srt"
        }
    ).to_dict()
