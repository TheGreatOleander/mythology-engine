from platform_adapters.youtube.youtube_adapter import build_youtube_package
from platform_adapters.tiktok.tiktok_adapter import build_tiktok_package
from platform_adapters.reels.reels_adapter import build_reels_package
from platform_adapters.shorts.shorts_adapter import build_shorts_package
from platform_adapters.podcast.podcast_adapter import build_podcast_package

def build_all_packages(story):
    return {
        "youtube": build_youtube_package(story),
        "tiktok": build_tiktok_package(story),
        "reels": build_reels_package(story),
        "shorts": build_shorts_package(story),
        "podcast": build_podcast_package(story)
    }
