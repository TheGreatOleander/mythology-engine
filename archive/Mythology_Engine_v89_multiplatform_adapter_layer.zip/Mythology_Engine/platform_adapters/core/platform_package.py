class PlatformPackage:
    def __init__(self, platform, aspect_ratio, duration_target, title, description, assets):
        self.platform = platform
        self.aspect_ratio = aspect_ratio
        self.duration_target = duration_target
        self.title = title
        self.description = description
        self.assets = assets

    def to_dict(self):
        return {
            "platform": self.platform,
            "aspect_ratio": self.aspect_ratio,
            "duration_target": self.duration_target,
            "title": self.title,
            "description": self.description,
            "assets": self.assets
        }
