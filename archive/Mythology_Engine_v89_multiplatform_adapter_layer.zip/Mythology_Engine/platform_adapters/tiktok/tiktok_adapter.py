from platform_adapters.core.platform_package import PlatformPackage

def build_tiktok_package(story):
    return PlatformPackage(
        platform="tiktok",
        aspect_ratio="9:16",
        duration_target="30-90 sec",
        title=f"{story['hook']} #mystery #history",
        description="Vertical micro-story cut from the main arc.",
        assets={
            "video": "output/tiktok_vertical.mp4",
            "cover_frame": "output/tiktok_cover.png",
            "captions": "output/tiktok_captions.srt"
        }
    ).to_dict()
