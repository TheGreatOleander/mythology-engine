# Mythology Engine v89 – Multi-Platform Adapter Layer

This version adds platform adapters so one story can be prepared for multiple destinations.

## Platforms

- YouTube
- TikTok
- Instagram Reels
- YouTube Shorts
- Podcast

## Run demo

python platform_adapters/tools/demo_multiplatform.py

## What it does

Takes one story object and generates platform-specific publish packages.
