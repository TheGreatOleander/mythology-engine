# Mythology Engine – Decision Surface Bundle

A documentary content production engine with an Android control center.

## What this version adds

This version turns the Android app into a stronger control surface.

The mobile control center can now:
- inspect episode package files
- capture operator notes
- emit decision JSON for approve / reject / regenerate

## Core loop

engine
→ episode package
→ phone review
→ decision JSON
→ downstream action
