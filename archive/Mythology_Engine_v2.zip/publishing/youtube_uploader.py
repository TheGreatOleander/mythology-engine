
def upload_video(file_path, title, description):
    print("Uploading video to YouTube...")
