
def generate_thumbnail_prompt(topic):
    return f"dark mysterious scene related to {topic}, cinematic lighting"
