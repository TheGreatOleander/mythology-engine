
def assemble_video(script, audio):
    print("Assembling video...")
