
def build_story(topic):
    return f"""Hook:
A mysterious event related to {topic}.

Background:
Historical records suggest something unusual occurred.

Discovery:
Investigators uncover fragments of evidence.

Twist:
The discovery connects to something older.

Ending:
The truth remains hidden… for now.
"""
