
import random

HOOKS = [
    "In 1924, researchers discovered something they were never meant to find.",
    "The archive file was sealed for nearly a century.",
    "What historians uncovered beneath the ruins changed everything."
]

def generate_hook():
    return random.choice(HOOKS)
