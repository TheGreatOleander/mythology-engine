
import random

FORESHADOW_LINES = [
    "The symbol would appear again decades later.",
    "This was not the first time the tower had been mentioned.",
    "What they found hinted at something much larger."
]

def generate_foreshadow():
    return random.choice(FORESHADOW_LINES)
