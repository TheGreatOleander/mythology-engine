
import random

class SeasonPlanner:

    ARCHETYPES = [
        "artifact discovery",
        "lost expedition",
        "forbidden archive",
        "ancient signal",
        "secret experiment"
    ]

    def generate_episode_plan(self):
        return random.choice(self.ARCHETYPES)
