
class ThreadManager:
    def __init__(self):
        self.threads = {}

    def increase_pressure(self, name):
        self.threads.setdefault(name, 0)
        self.threads[name] += 1

    def release_thread(self, name):
        self.threads[name] = 0
