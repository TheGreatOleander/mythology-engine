
import json

class UniverseEngine:
    def __init__(self, path="bible/universe_graph.json"):
        with open(path) as f:
            self.data = json.load(f)

    def add_entity(self, category, entity):
        self.data.setdefault(category, []).append(entity)

    def save(self, path="bible/universe_graph.json"):
        with open(path, "w") as f:
            json.dump(self.data, f, indent=2)
