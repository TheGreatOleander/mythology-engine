
# Architecture Overview

Mythology Engine v2 is composed of modular systems:

1. Topic Discovery
2. Story Generation
3. Media Production
4. Publishing
5. Universe Tracking
