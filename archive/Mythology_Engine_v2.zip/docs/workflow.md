
# Workflow

1. Select topic
2. Generate hook
3. Build narrative
4. Generate narration
5. Assemble video
6. Upload
7. Update universe graph
