from providers.core.provider_base import ProviderBase

class SDXLProvider(ProviderBase):
    provider_name = "sdxl"
    provider_type = "image"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "thumbnail_generation",
                "scene_concept_art",
                "cover_art"
            ],
            "note": "Wire to local SDXL or hosted image API."
        }
