from providers.core.provider_registry import ProviderRegistry
from providers.video.ffmpeg_provider import FFmpegProvider
from providers.image.sdxl_provider import SDXLProvider
from providers.audio.piper_provider import PiperProvider
from providers.publish.youtube_provider import YouTubePublishProvider
from providers.publish.tiktok_provider import TikTokPublishProvider
from providers.publish.reels_provider import ReelsPublishProvider
from providers.publish.podcast_provider import PodcastPublishProvider
from providers.analytics.youtube_analytics_provider import YouTubeAnalyticsProvider
from providers.analytics.tiktok_analytics_provider import TikTokAnalyticsProvider

def build_registry():
    registry = ProviderRegistry()
    registry.register("ffmpeg", FFmpegProvider())
    registry.register("sdxl", SDXLProvider())
    registry.register("piper", PiperProvider())
    registry.register("youtube", YouTubePublishProvider())
    registry.register("tiktok", TikTokPublishProvider())
    registry.register("instagram_reels", ReelsPublishProvider())
    registry.register("podcast", PodcastPublishProvider())
    registry.register("youtube_analytics", YouTubeAnalyticsProvider())
    registry.register("tiktok_analytics", TikTokAnalyticsProvider())
    return registry
