from providers.tools.provider_bootstrap import build_registry
import json

registry = build_registry()
print(json.dumps(registry.list_status(), indent=2))
