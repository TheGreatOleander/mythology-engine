from providers.core.provider_base import ProviderBase

class PodcastPublishProvider(ProviderBase):
    provider_name = "podcast"
    provider_type = "publish"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "upload_audio_episode",
                "publish_show_notes",
                "set_cover_art"
            ],
            "note": "Wire to podcast host or RSS publishing pipeline."
        }
