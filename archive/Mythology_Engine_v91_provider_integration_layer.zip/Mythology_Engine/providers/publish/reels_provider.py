from providers.core.provider_base import ProviderBase

class ReelsPublishProvider(ProviderBase):
    provider_name = "instagram_reels"
    provider_type = "publish"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "upload_reel",
                "set_cover_frame"
            ],
            "note": "Meta platform integration pending."
        }
