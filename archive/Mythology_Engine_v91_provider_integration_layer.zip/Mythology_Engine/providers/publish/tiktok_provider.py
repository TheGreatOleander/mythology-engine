from providers.core.provider_base import ProviderBase

class TikTokPublishProvider(ProviderBase):
    provider_name = "tiktok"
    provider_type = "publish"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "upload_vertical_video",
                "set_caption"
            ],
            "note": "API wiring and auth flow still needed."
        }
