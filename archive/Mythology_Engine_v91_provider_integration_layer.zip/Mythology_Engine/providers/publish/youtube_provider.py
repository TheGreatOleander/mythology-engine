from providers.core.provider_base import ProviderBase

class YouTubePublishProvider(ProviderBase):
    provider_name = "youtube"
    provider_type = "publish"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "upload_video",
                "set_thumbnail",
                "set_metadata",
                "publish_shorts"
            ],
            "note": "Requires OAuth and YouTube Data API integration."
        }
