from providers.core.provider_base import ProviderBase

class FFmpegProvider(ProviderBase):
    provider_name = "ffmpeg"
    provider_type = "video"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": True,
            "capabilities": [
                "assemble_video",
                "transcode",
                "vertical_reformat",
                "caption_burn_in"
            ]
        }
