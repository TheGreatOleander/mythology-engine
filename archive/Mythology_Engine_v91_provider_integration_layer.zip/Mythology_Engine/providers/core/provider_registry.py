class ProviderRegistry:
    def __init__(self):
        self._providers = {}

    def register(self, name, provider):
        self._providers[name] = provider

    def get(self, name):
        return self._providers.get(name)

    def list_status(self):
        return {
            name: provider.status()
            for name, provider in self._providers.items()
        }
