class ProviderBase:
    provider_name = "base"
    provider_type = "generic"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False
        }
