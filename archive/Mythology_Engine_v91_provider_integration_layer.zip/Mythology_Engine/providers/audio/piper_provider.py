from providers.core.provider_base import ProviderBase

class PiperProvider(ProviderBase):
    provider_name = "piper"
    provider_type = "audio"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "tts_voice_generation",
                "narration_render"
            ],
            "note": "Wire to Piper or another TTS runtime."
        }
