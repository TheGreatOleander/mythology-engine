from providers.core.provider_base import ProviderBase

class TikTokAnalyticsProvider(ProviderBase):
    provider_name = "tiktok_analytics"
    provider_type = "analytics"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "read_views",
                "read_completion_rate",
                "read_engagement"
            ],
            "note": "Requires TikTok analytics integration."
        }
