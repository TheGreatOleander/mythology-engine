from providers.core.provider_base import ProviderBase

class YouTubeAnalyticsProvider(ProviderBase):
    provider_name = "youtube_analytics"
    provider_type = "analytics"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": [
                "read_views",
                "read_ctr",
                "read_watch_time",
                "read_comment_metrics"
            ],
            "note": "Requires YouTube Analytics API wiring."
        }
