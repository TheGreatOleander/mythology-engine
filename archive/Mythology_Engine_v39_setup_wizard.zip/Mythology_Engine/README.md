# Mythology Engine v39 – Setup Wizard

This version adds an easy first-run setup flow.

## New capability

The repo can now prompt the user for:
- YouTube OAuth paths
- API keys
- provider preferences
- channel metadata

and save those values locally.

## Run

`python tools/run_setup_wizard.py`

## Output

The wizard writes:

`secrets/local_secrets.json`

That file is local-only and is ignored by git.
