# Secrets Strategy

## Public repo model

The repository can be public while sensitive values remain private.

Public:
- source code
- docs
- examples
- setup wizard

Private / local only:
- API keys
- OAuth tokens
- credential JSON files

## Recommended approach

1. Ship the repo with:
   - `examples/local_secrets.example.json`
   - setup wizard
   - `.gitignore`

2. Each user runs:
   `python tools/run_setup_wizard.py`

3. The wizard saves:
   `secrets/local_secrets.json`

4. The runtime loads local secrets at execution time.
