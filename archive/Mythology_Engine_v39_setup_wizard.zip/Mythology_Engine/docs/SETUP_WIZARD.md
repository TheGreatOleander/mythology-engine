# Setup Wizard

This module gives the project a simple first-run setup flow.

## Goal

If the repo is made public, each user should be able to wire in their own:
- YouTube OAuth credentials
- API keys
- provider preferences
- channel metadata

without editing source files manually.

## How it works

Run:

`python tools/run_setup_wizard.py`

The wizard prompts for:
- YouTube credential paths
- API keys
- default providers
- channel name
- contact email

Then it writes them to:

`secrets/local_secrets.json`

## Important

That file should stay local and should never be committed to a public repository.

The included `.gitignore` is set up to help prevent that.
