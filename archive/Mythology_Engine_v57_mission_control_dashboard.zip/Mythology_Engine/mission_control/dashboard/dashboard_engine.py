from pipeline_manager.engines.store import load, summarize
from youtube_intelligence.engines.intelligence_report import build_report

def build_dashboard():

    pipeline_records = load()
    pipeline_summary = summarize(pipeline_records)

    intel = build_report()

    return {
        "pipeline_summary": pipeline_summary,
        "pipeline_records": pipeline_records,
        "youtube_intelligence": intel
    }
