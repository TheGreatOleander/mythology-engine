from youtube_intelligence.providers.youtube.youtube_signal_provider import YouTubeSignalProvider

def build_report():
    provider = YouTubeSignalProvider()
    signals = provider.fetch_comment_signals()

    scores = {}
    for s in signals:
        scores.setdefault(s["topic"],0)
        scores[s["topic"]] += s["weight"]

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)

    return {
        "ranked_topics": ranked,
        "recommended_next_topic": ranked[0][0] if ranked else None
    }
