Mythology Engine v57 – Mission Control Dashboard

Adds a unified operational dashboard.

Run:

python tools/run_dashboard.py

Output shows:

- production pipeline state
- episode progress
- YouTube audience intelligence
