from mission_control.dashboard.dashboard_engine import build_dashboard
import json

dashboard = build_dashboard()
print(json.dumps(dashboard, indent=2))
