Mission Control Dashboard

This module combines multiple subsystems into a single operational overview.

Dashboard shows:

Pipeline Summary:
- how many episodes are in each production stage

Pipeline Records:
- individual episode progress

YouTube Intelligence:
- viewer signal ranking
- recommended next topic
