from truth_engine.models.canon_item import CanonItem
from truth_engine.engines.truth_engine import TruthEngine
import json

engine = TruthEngine()

fact = CanonItem(
    statement="The Impossible Map was discovered beneath the archive vault.",
    category="artifact",
    status="canon",
    source_episode="Episode_001"
)

engine.add_fact(fact)

result = engine.verify_statement("Impossible Map")

print(json.dumps(result, indent=2))
