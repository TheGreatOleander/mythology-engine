# Mythology Engine v111 – Truth / Canon Engine

Adds a canon management layer to the mythology system.

## Run

python runtime/tools/demo_truth_engine.py

## Purpose

Keep track of what is:

- canon (established truth)
- mystery (unknown)
- theory (audience speculation)
- fiction (intentional narrative device)
