from truth_engine.storage.canon_store import CanonStore

class TruthEngine:

    def __init__(self):
        self.store = CanonStore()

    def add_fact(self, canon_item):
        self.store.add(canon_item.to_dict())

    def list_by_status(self, status):
        items = self.store.load()
        return [i for i in items if i.get("status") == status]

    def verify_statement(self, text):
        items = self.store.load()
        for item in items:
            if text.lower() in item.get("statement","").lower():
                return {
                    "match": True,
                    "status": item["status"],
                    "source_episode": item.get("source_episode")
                }
        return {"match": False}
