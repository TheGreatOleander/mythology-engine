class CanonItem:
    def __init__(self, statement, category, status="canon", source_episode=None):
        self.statement = statement
        self.category = category
        self.status = status
        self.source_episode = source_episode

    def to_dict(self):
        return {
            "statement": self.statement,
            "category": self.category,
            "status": self.status,
            "source_episode": self.source_episode
        }
