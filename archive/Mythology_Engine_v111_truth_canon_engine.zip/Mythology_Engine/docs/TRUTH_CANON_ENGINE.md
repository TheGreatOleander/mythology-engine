# Truth / Canon Engine

Maintains a structured distinction between:

- Canon facts
- Mysteries
- Audience theories
- Deliberate fiction

This prevents narrative drift and keeps the mythology internally consistent.
