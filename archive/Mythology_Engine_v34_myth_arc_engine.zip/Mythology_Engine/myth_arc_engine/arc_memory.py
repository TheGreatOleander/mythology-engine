import json
from pathlib import Path

ARC_FILE = Path("examples/myth_arcs.json")

def load_arcs():
    if ARC_FILE.exists():
        return json.loads(ARC_FILE.read_text())
    return []

def save_arc(title, mysteries):
    arcs = load_arcs()
    arcs.append({
        "arc_title": title,
        "mysteries": mysteries
    })
    ARC_FILE.write_text(json.dumps(arcs, indent=2))
    return arcs[-1]
