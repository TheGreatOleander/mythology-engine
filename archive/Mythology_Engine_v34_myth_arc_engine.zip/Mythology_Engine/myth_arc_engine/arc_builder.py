import random
from myth_arc_engine.arc_memory import load_arcs

ARC_PATTERNS = [
    "Hidden technology lost to time",
    "Signals from unknown origins",
    "Civilizations erased from history",
    "Maps that shouldn't exist",
    "Artifacts that defy explanation"
]

def suggest_arc():
    arcs = load_arcs()
    theme = random.choice(ARC_PATTERNS)
    return {
        "arc_theme": theme,
        "suggested_episode_chain": [
            f"Episode 1 – Discovery of {theme}",
            f"Episode 2 – Historical clues about {theme}",
            f"Episode 3 – Strange evidence surrounding {theme}",
            f"Episode 4 – Competing theories about {theme}",
            f"Episode 5 – The unresolved mystery of {theme}"
        ]
    }
