from myth_arc_engine.arc_builder import suggest_arc
import json

arc = suggest_arc()
print(json.dumps(arc, indent=2))
