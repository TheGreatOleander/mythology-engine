# Mythology Engine v34 – Myth Arc Engine

Adds long‑running narrative arcs to the documentary system.

Instead of producing only isolated episodes, the system can now
generate multi‑episode story chains based on recurring mysteries.
