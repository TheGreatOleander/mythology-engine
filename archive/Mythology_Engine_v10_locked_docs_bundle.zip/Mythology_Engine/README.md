# Mythology Engine (Locked Documentation Edition)

This repository contains a **documentary content production system**
and a companion **Android control center**.

The project exists to assist a human operator in producing
mystery‑driven documentary videos.

## Core Components

### Mythology Engine (Python)
Generates episode packages and metadata.

### Android Control Center
Provides a mobile cockpit for reviewing and managing generated episodes.

## Core Workflow

topic discovery
→ title / hook variants
→ narrative script
→ media preparation
→ review bundle
→ human approval
→ publication

## Key Principle

Automation supports the creator.  
It does not replace the creator.

See the documentation in `docs/` for the canonical system definition.
