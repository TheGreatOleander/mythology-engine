class TimelineClip:
    def __init__(self, image, duration):
        self.image = image
        self.duration = duration
