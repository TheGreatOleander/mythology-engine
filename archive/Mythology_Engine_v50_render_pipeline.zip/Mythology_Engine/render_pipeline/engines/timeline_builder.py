import json

def build_timeline(scene_assets):

    timeline = []

    for asset in scene_assets:
        timeline.append({
            "image": asset,
            "duration": 4
        })

    return timeline
