import subprocess
from pathlib import Path

def render_video(images, audio, output):

    list_file = Path("render_images.txt")

    with open(list_file, "w") as f:
        for img in images:
            f.write(f"file '{img}'\n")
            f.write("duration 4\n")

    cmd = [
        "ffmpeg",
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", str(list_file),
        "-i", audio,
        "-shortest",
        "-pix_fmt", "yuv420p",
        output
    ]

    subprocess.run(cmd)

    return output
