# Render Pipeline

This subsystem assembles the final video.

Steps:

1. Scene images generated
2. Timeline created
3. FFmpeg combines images + narration
4. Final video produced

Requires FFmpeg installed on system.
