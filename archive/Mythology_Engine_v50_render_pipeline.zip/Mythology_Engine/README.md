Mythology Engine v50 – Video Render Pipeline

This version adds automatic video assembly.

Workflow:

scene images
+ narration audio
→ FFmpeg renderer
→ final_video.mp4

Run:

python tools/render_episode.py

Requires FFmpeg installed.
