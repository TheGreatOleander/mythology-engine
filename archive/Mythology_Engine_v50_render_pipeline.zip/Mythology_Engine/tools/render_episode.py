from render_pipeline.engines.timeline_builder import build_timeline
from render_pipeline.engines.ffmpeg_renderer import render_video

scene_images = [
    "examples/scene1.png",
    "examples/scene2.png",
    "examples/scene3.png"
]

audio = "examples/narration.wav"

timeline = build_timeline(scene_images)

images = [t["image"] for t in timeline]

output = render_video(images, audio, "examples/final_video.mp4")

print("Video rendered:", output)
