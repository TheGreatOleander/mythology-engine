import datetime

def build_calendar(episodes, cadence_days):

    start = datetime.date.today()
    schedule = []

    for ep in episodes:
        publish_date = start + datetime.timedelta(days=(ep["episode_number"]-1)*cadence_days)
        schedule.append({
            "episode_number": ep["episode_number"],
            "title": ep["title"],
            "publish_date": publish_date.isoformat()
        })

    return schedule
