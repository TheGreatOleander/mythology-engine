# Mythology Engine v90 – Unified Multi‑Platform Studio Core

This version merges:

studio core
growth loop
multi‑platform adapters

into one execution engine.

Endpoint:

POST /run-studio

Result:

A single story arc becomes publish packages for:

YouTube
TikTok
Instagram Reels
YouTube Shorts
Podcast
