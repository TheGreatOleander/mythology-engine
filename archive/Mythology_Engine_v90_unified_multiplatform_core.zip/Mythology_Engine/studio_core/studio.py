from strategy_engine.strategy_provider import get_strategy
from story_engine.arc_generator import generate_arc
from calendar_engine.calendar_builder import build_calendar
from production.render.video_renderer import render_episode
from platform_adapters.core.registry import build_all
from production.publish.publisher import publish_package
from learning_engine.performance_analyzer import analyze

def run_studio():

    strategy = get_strategy()

    arc = generate_arc(strategy["topic"], strategy["episodes"])

    calendar = build_calendar(arc, strategy["cadence_days"])

    production = []

    for ep in arc:

        rendered = render_episode(ep)

        packages = build_all(rendered)

        publish_results = [publish_package(p) for p in packages]

        production.append({
            "episode": ep,
            "packages": packages,
            "publish_results": publish_results
        })

    learning = analyze()

    return {
        "strategy": strategy,
        "calendar": calendar,
        "production": production,
        "learning": learning
    }
