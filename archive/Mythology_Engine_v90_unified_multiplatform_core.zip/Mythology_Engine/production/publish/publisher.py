def publish_package(pkg):
    return {
        "platform": pkg["platform"],
        "status": "publish_simulated"
    }
