def render_episode(episode):

    return {
        "title": episode["title"],
        "hook": episode["hook"],
        "summary": "An ancient mystery unfolds beneath forgotten history.",
        "video_file": f"rendered/{episode['episode_number']}.mp4"
    }
