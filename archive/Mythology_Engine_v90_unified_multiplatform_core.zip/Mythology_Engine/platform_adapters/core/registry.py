from platform_adapters.youtube.youtube import build
from platform_adapters.tiktok.tiktok import build as build_tt
from platform_adapters.reels.reels import build as build_reels
from platform_adapters.shorts.shorts import build as build_shorts
from platform_adapters.podcast.podcast import build as build_podcast

def build_all(story):

    return [
        build(story),
        build_tt(story),
        build_reels(story),
        build_shorts(story),
        build_podcast(story)
    ]
