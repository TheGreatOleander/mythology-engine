def build(story):
    return {
        "platform": "tiktok",
        "aspect": "9:16",
        "title": story["hook"],
        "video": "output/tiktok.mp4"
    }
