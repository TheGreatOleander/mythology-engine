def build(story):
    return {
        "platform": "reels",
        "aspect": "9:16",
        "title": story["hook"],
        "video": "output/reels.mp4"
    }
