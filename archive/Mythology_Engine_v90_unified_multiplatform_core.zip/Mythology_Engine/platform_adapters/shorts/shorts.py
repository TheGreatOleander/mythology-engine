def build(story):
    return {
        "platform": "youtube_shorts",
        "aspect": "9:16",
        "title": story["hook"],
        "video": "output/shorts.mp4"
    }
