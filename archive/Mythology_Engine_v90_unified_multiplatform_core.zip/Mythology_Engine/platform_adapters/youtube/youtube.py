def build(story):
    return {
        "platform": "youtube",
        "aspect": "16:9",
        "title": story["title"],
        "video": "output/youtube.mp4",
        "thumbnail": "output/youtube_thumb.png"
    }
