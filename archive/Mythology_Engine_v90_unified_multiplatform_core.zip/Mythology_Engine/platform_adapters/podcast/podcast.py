def build(story):
    return {
        "platform": "podcast",
        "aspect": "audio",
        "title": story["title"],
        "audio": "output/podcast.mp3"
    }
