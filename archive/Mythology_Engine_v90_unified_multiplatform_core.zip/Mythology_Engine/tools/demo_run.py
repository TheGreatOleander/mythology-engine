import urllib.request, json

req = urllib.request.Request("http://127.0.0.1:8765/run-studio", method="POST")

with urllib.request.urlopen(req) as r:
    print(json.dumps(json.loads(r.read().decode()), indent=2))
