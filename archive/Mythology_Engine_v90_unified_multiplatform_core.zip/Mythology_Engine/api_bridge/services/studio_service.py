from studio_core.studio import run_studio

def studio_service():
    return run_studio()
