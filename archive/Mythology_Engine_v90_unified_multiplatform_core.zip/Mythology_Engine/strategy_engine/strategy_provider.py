def get_strategy():
    return {
        "topic": "oak island treasure mystery",
        "episodes": 3,
        "cadence_days": 2
    }
