def generate_arc(topic, episodes):

    titles = [
        "The Discovery",
        "The Hidden Evidence",
        "The Forbidden Map",
        "The Lost Expedition",
        "The Final Secret"
    ]

    return [
        {
            "episode_number": i+1,
            "title": f"{topic} – Part {i+1}: {titles[i % len(titles)]}",
            "hook": "This discovery shouldn't exist."
        }
        for i in range(episodes)
    ]
