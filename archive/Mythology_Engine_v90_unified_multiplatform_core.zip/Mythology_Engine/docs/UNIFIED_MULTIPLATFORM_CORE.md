# Unified Multi‑Platform Studio Core

Runs the full studio pipeline and produces publish packages
for multiple platforms simultaneously.

Flow:

strategy → arc → calendar → render → platform adapters → publish → learning
