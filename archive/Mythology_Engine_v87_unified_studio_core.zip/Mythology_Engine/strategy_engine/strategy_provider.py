def get_strategy(topic=None):
    if topic:
        return {"topic": topic, "episodes": 3, "cadence_days": 2}

    return {"topic": "oak island treasure mystery", "episodes": 3, "cadence_days": 2}
