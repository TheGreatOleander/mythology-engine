from studio_core.engines.studio_core import run_studio

def studio_service():
    return run_studio()
