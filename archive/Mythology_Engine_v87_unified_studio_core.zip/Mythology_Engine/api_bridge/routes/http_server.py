from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from api_bridge.services.studio_service import studio_service

class Handler(BaseHTTPRequestHandler):

    def send_json(self,data,code=200):
        body=json.dumps(data,indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):

        if self.path == "/run-studio":
            self.send_json(studio_service())
        else:
            self.send_json({"error":"not_found"},404)

def run():
    server = HTTPServer(("127.0.0.1",8765),Handler)
    print("Unified Studio Core running http://127.0.0.1:8765")
    server.serve_forever()

if __name__ == "__main__":
    run()
