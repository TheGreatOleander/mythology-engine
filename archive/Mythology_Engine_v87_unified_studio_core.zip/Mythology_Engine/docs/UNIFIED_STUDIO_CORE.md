# Unified Studio Core

This module merges:

strategy
story arc
calendar
production
publishing
learning
growth flywheel

into one unified engine.

API:

POST /run-studio
