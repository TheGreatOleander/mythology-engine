def publish_video(video):

    return {
        "title": video["title"],
        "status": "published_simulated"
    }
