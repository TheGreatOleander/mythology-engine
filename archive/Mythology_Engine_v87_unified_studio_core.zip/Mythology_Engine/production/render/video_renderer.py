def render_episode(episode):

    return {
        "title": episode["title"],
        "video_file": f"rendered/{episode['episode_number']}.mp4"
    }
