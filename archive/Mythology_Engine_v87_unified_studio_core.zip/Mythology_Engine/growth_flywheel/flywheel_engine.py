from strategy_engine.strategy_provider import get_strategy
from story_engine.arc_generator import generate_arc
from calendar_engine.calendar_builder import build_calendar
from production.render.video_renderer import render_episode
from production.publish.publisher import publish_video
from learning_engine.performance_analyzer import analyze_performance

def run_flywheel():

    strategy = get_strategy()

    arc = generate_arc(strategy["topic"], strategy["episodes"])

    calendar = build_calendar(arc, strategy["cadence_days"])

    results = []

    for ep in arc:
        video = render_episode(ep)
        pub = publish_video(video)
        results.append({"episode": ep, "video": video, "publish": pub})

    learning = analyze_performance()

    next_strategy = get_strategy(learning["recommended_topic"])

    return {
        "strategy": strategy,
        "arc": arc,
        "calendar": calendar,
        "production_results": results,
        "learning": learning,
        "next_strategy": next_strategy
    }
