from growth_flywheel.flywheel_engine import run_flywheel

def run_studio():
    return run_flywheel()
