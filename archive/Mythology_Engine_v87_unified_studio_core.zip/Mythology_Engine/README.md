# Mythology Engine v87 – Unified Studio Core

This version merges the entire studio stack into a single orchestrated engine.

Pipeline:

strategy
→ arc
→ calendar
→ render
→ publish
→ analyze
→ next strategy

Endpoint:

POST /run-studio
