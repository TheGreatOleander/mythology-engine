from narrative_arc.engines.arc_planner import generate_arc
import json

arc = generate_arc("ancient mystery")

print(json.dumps(arc, indent=2))
