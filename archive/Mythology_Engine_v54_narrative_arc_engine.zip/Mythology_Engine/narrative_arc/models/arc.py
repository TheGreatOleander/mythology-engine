class NarrativeArc:
    def __init__(self, title, description, episodes):
        self.title = title
        self.description = description
        self.episodes = episodes

    def to_dict(self):
        return {
            "title": self.title,
            "description": self.description,
            "episodes": self.episodes
        }
