def generate_arc(theme):

    theme = theme.lower()

    if "treasure" in theme:
        return {
            "title": "Lost Treasures of the Ancient World",
            "description": "A journey through history's most mysterious lost riches.",
            "episodes": [
                "Oak Island Treasure",
                "The Lost Gold of the Incas",
                "The Ark of the Covenant",
                "The Knights Templar Treasure",
                "The Amber Room Mystery"
            ]
        }

    if "ancient" in theme:
        return {
            "title": "Secrets of Ancient Civilizations",
            "description": "Uncovering forgotten knowledge buried in ancient cultures.",
            "episodes": [
                "Atlantis: Myth or Memory",
                "Göbekli Tepe",
                "The Antikythera Mechanism",
                "The Library of Alexandria",
                "The Pyramids' Hidden Purpose"
            ]
        }

    return {
        "title": "Mysteries of the Unknown",
        "description": "Exploring strange historical puzzles and unexplained discoveries.",
        "episodes": [
            "The Wow Signal",
            "The Voynich Manuscript",
            "The Tunguska Event",
            "The Dyatlov Pass Incident",
            "The Bermuda Triangle"
        ]
    }
