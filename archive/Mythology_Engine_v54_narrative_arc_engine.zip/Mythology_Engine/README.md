Mythology Engine v54 – Narrative Arc Engine

Adds season-style story planning.

Instead of generating random episodes, the system can create arcs like:

Season Theme → Episode Sequence

Run demo:

python tools/demo_narrative_arc.py
