# Release Notes v73

This version focuses on product packaging polish.

## Added
- shell launcher scripts
- requirements.txt
- .gitignore
- runtime config example
- quickstart documentation
- release notes

## Goal
Make the repo feel more like something a real user can clone, start, and test
without guessing how the pieces fit together.
