# Quickstart

## 1. Prepare secrets
Copy:
- `secrets/client_secret.example.json`
to:
- `secrets/client_secret.json`

Or leave it missing if you only want to test the scaffold.

## 2. Optional dev token
Create a local placeholder token:

`python tools/create_dev_token.py`

## 3. Start the studio API
`python tools/start_api.py`

## 4. Check health
Open:
`http://127.0.0.1:8765/health`

## 5. Check OAuth readiness
Open:
`http://127.0.0.1:8765/youtube-auth-status`

## 6. Test publish scaffold
POST to:
`http://127.0.0.1:8765/publish`
