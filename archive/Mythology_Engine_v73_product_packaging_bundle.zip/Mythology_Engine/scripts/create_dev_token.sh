#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
python tools/create_dev_token.py
