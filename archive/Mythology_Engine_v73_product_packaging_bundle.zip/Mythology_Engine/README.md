# Mythology Engine v73 – Product Packaging Bundle

This version focuses on product packaging polish.

## Included
- Studio Engine
- Local API bridge
- OAuth-aware YouTube publishing scaffold
- Shell launcher scripts
- requirements.txt
- quickstart docs
- runtime config example

## Start fast

### Start studio API
`python tools/start_api.py`

### Check OAuth
`python tools/check_oauth.py`

### Create local dev token
`python tools/create_dev_token.py`

## Shell helpers
- `scripts/start_studio.sh`
- `scripts/check_oauth.sh`
- `scripts/create_dev_token.sh`
