class Scene:
    def __init__(self, image, duration=4, zoom=True, subtitle=""):
        self.image = image
        self.duration = duration
        self.zoom = zoom
        self.subtitle = subtitle
