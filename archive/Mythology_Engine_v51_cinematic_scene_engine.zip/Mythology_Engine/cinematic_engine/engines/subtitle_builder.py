def build_subtitles(text_blocks):
    lines=[]
    t=0
    for i,text in enumerate(text_blocks,1):
        start=f"00:00:{t:02},000"
        t+=4
        end=f"00:00:{t:02},000"
        lines.append(f"{i}\n{start} --> {end}\n{text}\n")
    return "\n".join(lines)
