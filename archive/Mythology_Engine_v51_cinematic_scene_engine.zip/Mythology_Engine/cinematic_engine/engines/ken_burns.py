def build_zoom_filter(duration):
    # basic slow zoom filter expression for ffmpeg
    return f"zoompan=z='min(zoom+0.0015,1.5)':d={duration*25}"
