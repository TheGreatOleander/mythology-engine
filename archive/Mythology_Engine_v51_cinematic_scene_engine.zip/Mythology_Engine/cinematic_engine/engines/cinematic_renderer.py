import subprocess, pathlib
from cinematic_engine.engines.ken_burns import build_zoom_filter

def render(images,audio,output):

    filters=[]
    inputs=[]

    for i,img in enumerate(images):
        inputs.extend(["-loop","1","-t","4","-i",img])
        filters.append(f"[{i}:v]{build_zoom_filter(4)}[v{i}]")

    filter_complex=";".join(filters)

    cmd=["ffmpeg","-y"]
    cmd+=inputs
    cmd+=["-filter_complex",filter_complex]
    cmd+=["-i",audio,"-shortest",output]

    subprocess.run(cmd)

    return output
