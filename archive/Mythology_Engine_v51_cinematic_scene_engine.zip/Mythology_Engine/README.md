Mythology Engine v51 – Cinematic Scene Engine

Adds documentary-style visuals:

• Ken Burns camera motion
• Subtitle timing generation
• Multi-scene cinematic rendering

Run demo:

python tools/render_cinematic_demo.py
