Cinematic Scene Engine

Adds motion and polish to the render pipeline.

Features:
- Ken Burns zoom motion
- subtitle timing builder
- multi-scene renderer scaffold
- FFmpeg compatible

This layer transforms static slideshow renders into documentary-style motion visuals.
