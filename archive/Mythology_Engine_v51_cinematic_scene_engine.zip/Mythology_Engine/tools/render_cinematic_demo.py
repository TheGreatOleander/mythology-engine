from cinematic_engine.engines.cinematic_renderer import render
from cinematic_engine.engines.subtitle_builder import build_subtitles

images=[
"examples/scene1.png",
"examples/scene2.png",
"examples/scene3.png"
]

audio="examples/narration.wav"

render(images,audio,"examples/cinematic_video.mp4")

subs=build_subtitles([
"Ancient maps hide forgotten routes.",
"Treasure hunters chase impossible clues.",
"But some mysteries refuse to stay buried."
])

open("examples/subtitles.srt","w").write(subs)

print("Cinematic video + subtitles generated.")
