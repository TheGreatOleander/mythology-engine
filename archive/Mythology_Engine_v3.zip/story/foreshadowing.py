
import random
lines=[
"This would not be the last time the symbol appeared.",
"The discovery hinted at something older.",
"Future investigations would reveal deeper connections."
]
def foreshadow():
    return random.choice(lines)
