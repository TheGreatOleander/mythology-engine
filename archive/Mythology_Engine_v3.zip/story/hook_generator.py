
import random
hooks=[
"In 1924 researchers discovered something impossible.",
"A sealed archive file resurfaced after a century.",
"The ruins revealed an object historians refuse to discuss."
]
def generate_hook():
    return random.choice(hooks)
