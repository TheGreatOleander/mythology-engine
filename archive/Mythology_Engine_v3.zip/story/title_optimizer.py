
def optimize_title(topic):
    return f"The Mystery Historians Can't Explain About {topic}"
