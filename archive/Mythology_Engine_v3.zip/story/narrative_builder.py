
def build_story(topic):
    return f'''
Background:
Historical records reference {topic}.

Discovery:
Investigators uncover new fragments.

Twist:
Evidence suggests the discovery connects to a larger mystery.

Conclusion:
The truth remains hidden… for now.
'''
