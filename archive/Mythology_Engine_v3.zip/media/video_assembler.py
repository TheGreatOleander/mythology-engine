
def assemble(script,audio):
    print("Assembling video with ffmpeg pipeline")
