
def synthesize(script):
    print("Generating narration audio...")
