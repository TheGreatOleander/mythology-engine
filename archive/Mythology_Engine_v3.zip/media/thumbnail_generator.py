
def generate_prompt(topic):
    return f"dark cinematic scene of {topic}, mysterious lighting"
