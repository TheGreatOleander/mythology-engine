
def render():
    print("FFmpeg render placeholder")
