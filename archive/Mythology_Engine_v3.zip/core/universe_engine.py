
import json

class UniverseEngine:

    def __init__(self,path="bible/universe_graph.json"):
        self.path=path
        self.data=json.load(open(path))

    def add(self,category,item):
        self.data.setdefault(category,[]).append(item)

    def save(self):
        json.dump(self.data,open(self.path,"w"),indent=2)
