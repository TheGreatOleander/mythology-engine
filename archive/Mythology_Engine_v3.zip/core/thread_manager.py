
class ThreadManager:

    def __init__(self):
        self.threads={}

    def increase(self,name):
        self.threads.setdefault(name,0)
        self.threads[name]+=1

    def reset(self,name):
        self.threads[name]=0

    def hottest(self):
        if not self.threads:
            return None
        return max(self.threads,key=self.threads.get)
