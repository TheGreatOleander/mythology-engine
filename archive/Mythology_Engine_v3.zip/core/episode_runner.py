
from story.hook_generator import generate_hook
from story.narrative_builder import build_story
from discovery.topic_discovery import get_topic

def run_episode():
    topic=get_topic()
    hook=generate_hook()
    script=build_story(topic)
    print("HOOK:",hook)
    print(script)
