
Architecture

Discovery Engine -> Story Generator -> Media Pipeline -> Publishing -> Analytics
