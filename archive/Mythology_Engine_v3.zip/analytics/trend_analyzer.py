
def trends():
    return ["lost cities","ancient artifacts","secret experiments"]
