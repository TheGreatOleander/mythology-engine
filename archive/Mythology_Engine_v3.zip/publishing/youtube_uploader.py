
def upload(video,title,description):
    print("Uploading video to YouTube (API stub)")
