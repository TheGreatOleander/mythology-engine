
import random

topics=[
"the Baghdad Battery",
"the Antikythera mechanism",
"the Voynich manuscript",
"a lost expedition in Siberia",
"a forbidden monastery archive"
]

def get_topic():
    return random.choice(topics)
