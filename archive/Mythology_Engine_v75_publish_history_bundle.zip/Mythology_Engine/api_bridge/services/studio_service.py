from studio.engines.studio_engine import StudioEngine

engine = StudioEngine()

last_manifest = None

def health_service():
    return engine.health()

def generate_service():
    global last_manifest
    last_manifest = engine.generate()
    return last_manifest

def publish_service():
    if not last_manifest:
        return {"error":"generate episode first"}
    return engine.publish(last_manifest)

def history_service():
    return engine.publish_history()
