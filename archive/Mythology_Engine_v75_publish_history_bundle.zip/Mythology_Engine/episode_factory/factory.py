import datetime, json
from pathlib import Path

def generate_episode():
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    episode_id = f"EP_{stamp}"

    base = Path("examples/generated") / episode_id
    base.mkdir(parents=True, exist_ok=True)

    (base / "final_video.mp4").write_text("placeholder video")
    (base / "thumbnail.png").write_text("placeholder thumb")

    return {
        "episode_id": episode_id,
        "video": str(base / "final_video.mp4"),
        "thumbnail": str(base / "thumbnail.png"),
        "title": "The Map That Shouldn't Exist",
        "description": "An ancient discovery that may rewrite history."
    }
