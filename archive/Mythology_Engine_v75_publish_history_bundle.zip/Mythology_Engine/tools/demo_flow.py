import urllib.request, json

BASE="http://127.0.0.1:8765"

def call(path,method="GET"):
    req=urllib.request.Request(BASE+path,method=method)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())

print("Health:",call("/health"))
print("Generate:",call("/generate","POST"))
print("Publish:",call("/publish","POST"))
print("History:",call("/publish-history"))
