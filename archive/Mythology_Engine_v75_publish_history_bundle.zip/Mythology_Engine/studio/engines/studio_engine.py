from episode_factory.factory import generate_episode
from publishing_engine.engines.publish_pipeline import publish_episode
from pipeline_manager.engines.publish_history import load

class StudioEngine:

    def health(self):
        return {"status":"ok"}

    def generate(self):
        return generate_episode()

    def publish(self, manifest):
        return publish_episode(
            manifest["video"],
            manifest["title"],
            manifest["description"],
            manifest["thumbnail"]
        )

    def publish_history(self):
        return load()
