# Mythology Engine v75 – Publish History Bundle

Adds a publish history log so Mission Control can display:

- past publish attempts
- success/failure states
- timestamps

Endpoints:

GET /health
POST /generate
POST /publish
GET /publish-history

Start:

python tools/start_api.py
