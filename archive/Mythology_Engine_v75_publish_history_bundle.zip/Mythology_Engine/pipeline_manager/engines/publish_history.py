import json, datetime
from pathlib import Path

STORE = Path("examples/publish_history/history.json")

def load():
    if STORE.exists():
        return json.loads(STORE.read_text())
    return []

def save(records):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(records, indent=2))

def record(entry):
    records = load()
    records.append(entry)
    save(records)
    return entry
