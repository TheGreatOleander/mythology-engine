from pathlib import Path
import json

CLIENT_SECRET = Path("secrets/client_secret.json")
TOKEN_FILE = Path("secrets/oauth_token.json")

def auth_status():
    return {
        "client_secret_exists": CLIENT_SECRET.exists(),
        "token_exists": TOKEN_FILE.exists()
    }
