# Publish History Engine

Adds a persistent publish history log.

API:
GET /publish-history

Each publish attempt records:

- timestamp
- video
- title
- result
