import json
from pathlib import Path
from publishing.publish_queue import enqueue
from publishing.youtube_uploader_stub import upload

def auto_publish(manifest_path: str):
    manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))

    job = {
        "episode_id": manifest["episode_id"],
        "title": manifest["selected_title"],
        "video_path": manifest.get("render_output", manifest.get("render_plan_path")),
        "thumbnail": manifest.get("thumbnail_path"),
        "description": f"Documentary exploration: {manifest['topic']}"
    }

    job_file = enqueue(job)
    upload_result = upload(job)

    return {
        "job_file": job_file,
        "upload_result": upload_result,
        "status": "queued_for_upload"
    }
