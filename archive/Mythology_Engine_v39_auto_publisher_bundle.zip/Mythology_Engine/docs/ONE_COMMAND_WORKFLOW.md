# One Command Workflow

The long-term goal is:

topic
→ script
→ narration
→ scenes
→ thumbnail
→ render plan
→ publish preparation

all from one command.

This version implements that workflow as an episode package builder.

It does not yet automatically render or upload, but it prepares every major artifact
required to do so.
