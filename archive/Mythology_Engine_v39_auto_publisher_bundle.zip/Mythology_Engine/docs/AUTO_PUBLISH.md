# Auto Publish

This module moves an episode from render stage into publishing.

## Workflow

episode manifest
→ publish queue
→ uploader

## Command

python tools/auto_publish_episode.py episodes/<episode_id>/manifest.json

Currently uses a safe uploader stub.
Real YouTube OAuth integration can replace it later.
