# Build and Render Workflow

This version adds a unified command that:

1. Builds the episode package
2. Generates narration
3. Generates thumbnail
4. Generates render plan
5. Attempts a dry‑run render

## Command

python tools/build_and_render_episode.py "the Piri Reis map"

## What happens

topic
→ episode builder
→ narration generation
→ thumbnail generation
→ render plan
→ render executor (dry run)

The renderer still defaults to safe mode.
Actual FFmpeg execution can be enabled later.
