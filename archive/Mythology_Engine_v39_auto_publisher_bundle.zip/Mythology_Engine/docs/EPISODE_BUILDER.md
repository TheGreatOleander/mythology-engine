# Episode Builder

This module assembles a full episode package in one command.

## It creates

- `script.txt`
- `metadata_package.json`
- `narration.mp3`
- `scene_plan.json`
- `subtitles.srt`
- `thumbnail.png`
- `render_plan.json`
- `manifest.json`

## Command

Build one episode:

`python tools/build_episode.py "the Piri Reis map"`

## Why this matters

This is the first point where the system behaves like a true production machine
instead of a collection of separate tools.
