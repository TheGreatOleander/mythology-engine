# Mythology Engine v39 – Auto Publisher

Adds automated publishing stage.

Command:

python tools/auto_publish_episode.py episodes/<episode_id>/manifest.json

Pipeline now:

topic
→ episode builder
→ narration
→ thumbnail
→ render plan
→ render executor
→ publish queue
→ uploader
