import json
from pathlib import Path
from datetime import datetime

from narrative_engine.script_builder import build_script
from title_thumbnail_lab.title_engine import generate_titles
from title_thumbnail_lab.thumbnail_engine import generate_thumbnail_concepts
from tts_engine.tts_manager import synthesize_text
from thumbnail_engine.thumbnail_manager import generate_thumbnail
from cinematic_engine.render_plan import write_render_plan

def _slugify(text: str) -> str:
    return "".join(c.lower() if c.isalnum() else "_" for c in text).strip("_")[:60]

def build_episode(topic: str, base_dir: str = "episodes") -> dict:
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    slug = _slugify(topic)
    episode_id = f"EP_{stamp}_{slug}"
    ep = Path(base_dir) / episode_id
    ep.mkdir(parents=True, exist_ok=True)

    # Script
    script = build_script(topic)
    script_path = ep / "script.txt"
    script_path.write_text(script, encoding="utf-8")

    # Title + thumbnail concepts
    titles = generate_titles(topic, count=5)
    thumbnail_concepts = generate_thumbnail_concepts(topic, count=4)
    selected_title = titles[0] if titles else topic
    selected_thumb = thumbnail_concepts[0] if thumbnail_concepts else {
        "topic": topic, "text": "UNEXPLAINED", "style": "dark mystery"
    }

    metadata = {
        "selected_title": selected_title,
        "description": f"A documentary-style investigation into {topic}.",
        "tags": ["mystery", "documentary", "history", "archive", "anomaly"],
        "all_titles": titles,
        "thumbnail_concepts": thumbnail_concepts,
    }
    metadata_path = ep / "metadata_package.json"
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    # Narration
    narration_path = ep / "narration.mp3"
    narration_result = synthesize_text(script, str(narration_path))

    # Scene plan
    scene_plan = [
        {
            "scene_index": 0,
            "text": "TITLE",
            "visual_type": "text_card",
            "motion": "slow_zoom_in",
            "duration_seconds": 8
        },
        {
            "scene_index": 1,
            "text": selected_title,
            "visual_type": "artifact" if "map" not in topic.lower() else "map",
            "motion": "slow_pan_left",
            "duration_seconds": 8
        },
        {
            "scene_index": 2,
            "text": f"Some discoveries refuse to stay buried, and {topic} is one of them.",
            "visual_type": "document",
            "motion": "gentle_parallax",
            "duration_seconds": 10
        }
    ]
    scene_plan_path = ep / "scene_plan.json"
    scene_plan_path.write_text(json.dumps(scene_plan, indent=2), encoding="utf-8")

    # Placeholder subtitles
    subtitles_path = ep / "subtitles.srt"
    subtitles_path.write_text(
        "1\n00:00:00,000 --> 00:00:04,000\nSome discoveries refuse to stay buried.\n\n"
        "2\n00:00:04,000 --> 00:00:08,000\nAnd this one may be stranger than most.\n",
        encoding="utf-8"
    )

    # Thumbnail image
    thumb_prompt = f'{topic}, {selected_thumb.get("style","dark mystery")}, central object, high contrast'
    thumb_path = ep / "thumbnail.png"
    thumb_result = generate_thumbnail(thumb_prompt, str(thumb_path))

    # Render plan
    render_plan_path = write_render_plan(str(ep))

    manifest = {
        "episode_id": episode_id,
        "topic": topic,
        "script_path": str(script_path),
        "metadata_path": str(metadata_path),
        "narration_path": str(narration_path),
        "subtitles_path": str(subtitles_path),
        "scene_plan_path": str(scene_plan_path),
        "thumbnail_path": str(thumb_path),
        "render_plan_path": render_plan_path,
        "selected_title": selected_title,
        "tts_result": narration_result,
        "thumbnail_result": thumb_result,
        "status": "episode_package_built"
    }
    manifest_path = ep / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    return manifest
