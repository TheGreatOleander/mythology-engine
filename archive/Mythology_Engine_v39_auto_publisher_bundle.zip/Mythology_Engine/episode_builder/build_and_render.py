import json
from episode_builder.builder import build_episode
from cinematic_engine.render_executor import (
    load_render_plan,
    write_concat_file,
    execute_scene_commands,
    execute_final_concat
)

def build_and_render(topic: str):
    manifest = build_episode(topic)

    render_plan_path = manifest["render_plan_path"]
    render_plan = load_render_plan(render_plan_path)

    concat = write_concat_file(render_plan)

    scene_results = execute_scene_commands(render_plan, dry_run=True)
    concat_result = execute_final_concat(render_plan, dry_run=True)

    result = {
        "manifest": manifest,
        "concat_file": concat,
        "scene_execution": scene_results,
        "concat_execution": concat_result,
        "status": "build_complete_render_dry_run"
    }

    return result
