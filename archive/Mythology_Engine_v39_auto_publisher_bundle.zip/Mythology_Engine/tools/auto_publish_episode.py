import sys, json
from publishing.auto_publisher import auto_publish

if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("Usage: python tools/auto_publish_episode.py <manifest.json>")
        raise SystemExit(1)

    manifest = sys.argv[1]
    result = auto_publish(manifest)
    print(json.dumps(result, indent=2))
