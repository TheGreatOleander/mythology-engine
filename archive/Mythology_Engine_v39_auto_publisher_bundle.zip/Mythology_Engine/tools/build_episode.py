import sys
import json
from episode_builder.builder import build_episode

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python tools/build_episode.py "Topic Here"')
        raise SystemExit(1)

    topic = sys.argv[1]
    result = build_episode(topic)
    print(json.dumps(result, indent=2))
