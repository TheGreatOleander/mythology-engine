import json
from episode_builder.builder import build_episode

if __name__ == "__main__":
    result = build_episode("the Piri Reis map")
    print(json.dumps(result, indent=2))
