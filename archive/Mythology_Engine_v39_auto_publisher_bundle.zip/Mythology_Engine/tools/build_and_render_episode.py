import sys, json
from episode_builder.build_and_render import build_and_render

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python tools/build_and_render_episode.py "Topic Here"')
        raise SystemExit(1)

    topic = sys.argv[1]
    result = build_and_render(topic)
    print(json.dumps(result, indent=2))
