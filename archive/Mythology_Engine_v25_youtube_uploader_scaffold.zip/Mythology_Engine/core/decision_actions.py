from pathlib import Path
import shutil
from publishing.publish_bridge import queue_episode_for_publish

EPISODES_DIR = Path("episodes")
REJECTED_DIR = Path("rejected_episodes")
REJECTED_DIR.mkdir(exist_ok=True)

def handle_approved(eid):
    src = EPISODES_DIR / eid
    if not src.exists():
        return {"publish_error": eid, "reason": "episode_dir_missing"}

    result = queue_episode_for_publish(str(src), privacy_status="private")
    return {"approved_for_publish": eid, "publish_bridge": result}

def handle_rejected(eid):
    src = EPISODES_DIR / eid
    dst = REJECTED_DIR / eid
    if src.exists():
        shutil.move(str(src), str(dst))
    return {"rejected": eid}

def handle_regenerate(eid):
    return {"regenerate_requested": eid, "status": "placeholder"}

def dispatch(actions):
    results = []
    for eid in actions.get("approved_for_publish", []):
        results.append(handle_approved(eid))
    for eid in actions.get("rejected", []):
        results.append(handle_rejected(eid))
    for eid in actions.get("regenerate_requested", []):
        results.append(handle_regenerate(eid))
    return results
