from publishing.publish_bridge import queue_episode_for_publish
import sys

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tools/queue_episode_for_publish.py <episode_dir>")
    else:
        result = queue_episode_for_publish(sys.argv[1], privacy_status="private")
        print(result)
