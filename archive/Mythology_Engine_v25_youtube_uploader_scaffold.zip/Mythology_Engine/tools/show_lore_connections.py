from lore_graph.lore_engine import find_connections

if __name__ == "__main__":
    cons = find_connections()

    print("\n--- LORE CONNECTIONS ---\n")
    for c in cons:
        print("Tag:", c["tag"])
        print("Fragments:", ", ".join(c["related_fragments"]))
        print()
