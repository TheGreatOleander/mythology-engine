import json
from pathlib import Path
from publishing.publish_queue import list_publish_jobs
from publishing.youtube_uploader_real import upload_video_stub

def run_queue():
    jobs = list_publish_jobs()

    if not jobs:
        print("No jobs in publish queue.")
        return

    for job in jobs:
        job_file = job["file"]
        data = json.loads(Path(job_file).read_text())

        result = upload_video_stub(data)

        print("Upload result:")
        print(result)
        print()

if __name__ == "__main__":
    run_queue()
