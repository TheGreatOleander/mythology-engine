from publishing.publish_queue import list_publish_jobs
from publishing.youtube_uploader import upload_job_stub

if __name__ == "__main__":
    jobs = list_publish_jobs()

    if not jobs:
        print("No publish jobs queued.")
    else:
        print("Publish queue:")
        for job in jobs:
            result = upload_job_stub(job["file"])
            print(result)
