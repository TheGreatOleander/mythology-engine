import json
from pathlib import Path
from collections import defaultdict

INDEX = Path("story_library/storage/index.json")

def load_fragments():
    if not INDEX.exists():
        return []
    return json.loads(INDEX.read_text())

def build_graph():
    frags = load_fragments()
    graph = defaultdict(list)

    for f in frags:
        tags = f.get("tags", [])
        for t in tags:
            graph[t].append(f["id"])

    return dict(graph)

def find_connections():
    graph = build_graph()
    connections = []

    for tag, items in graph.items():
        if len(items) > 1:
            connections.append({
                "tag": tag,
                "related_fragments": items
            })

    return connections
