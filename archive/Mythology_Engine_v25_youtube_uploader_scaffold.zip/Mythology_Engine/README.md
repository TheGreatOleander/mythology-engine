# Mythology Engine – YouTube Uploader Scaffold

Adds the final structural component needed for automated publishing.

Pipeline:

idea
→ episode package
→ review
→ approval
→ publish_queue
→ uploader
→ YouTube draft/private upload

Credentials must be configured before real uploads are enabled.
