from pathlib import Path

def upload_video_stub(job):
    return {
        "status": "ready_for_oauth_configuration",
        "episode_id": job.get("episode_id"),
        "title": job.get("title"),
        "video_path": job.get("video_path")
    }

def upload_video_real(job, credentials_path, token_path):
    # Placeholder to avoid accidental uploads until credentials exist
    return {
        "status": "uploader_not_activated",
        "episode_id": job.get("episode_id"),
        "note": "OAuth credentials required"
    }
