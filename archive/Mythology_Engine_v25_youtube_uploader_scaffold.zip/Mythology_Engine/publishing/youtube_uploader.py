from pathlib import Path
import json

def upload_job_stub(job_file: str) -> dict:
    job = json.loads(Path(job_file).read_text(encoding="utf-8"))
    # This is intentionally a safe stub.
    return {
        "status": "stub_not_uploaded",
        "episode_id": job.get("episode_id"),
        "title": job.get("title"),
        "privacy_status": job.get("privacy_status"),
        "video_path": job.get("video_path"),
        "thumbnail_path": job.get("thumbnail_path"),
    }
