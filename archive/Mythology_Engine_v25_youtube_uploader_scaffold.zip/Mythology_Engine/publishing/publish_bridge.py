from publishing.package_validator import validate_episode_package
from publishing.job_builder import build_publish_job
from publishing.publish_queue import enqueue_publish_job

def queue_episode_for_publish(episode_dir: str, privacy_status: str = "private") -> dict:
    validation = validate_episode_package(episode_dir)

    if not validation["is_valid"]:
        return {
            "status": "validation_failed",
            "validation": validation
        }

    job = build_publish_job(episode_dir=episode_dir, privacy_status=privacy_status)
    job_path = enqueue_publish_job(job)

    return {
        "status": "queued",
        "job_file": str(job_path),
        "validation": validation,
        "job": job
    }
