from pathlib import Path
import json

REQUIRED_FILES = [
    "manifest.json",
    "metadata_package.json",
]

def validate_episode_package(episode_dir: str) -> dict:
    ep = Path(episode_dir)
    missing = []

    for name in REQUIRED_FILES:
        if not (ep / name).exists():
            missing.append(name)

    # video can be one of several names depending on pipeline maturity
    video_candidates = ["video.mp4", "video_render.mp4"]
    has_video = any((ep / name).exists() for name in video_candidates)

    if not has_video:
        missing.append("video.mp4|video_render.mp4")

    # thumbnail is optional in scaffold, but checked for readiness
    thumb_candidates = ["thumbnail.jpg", "thumbnail.png", "thumbnail_variants.json"]
    has_thumb = any((ep / name).exists() for name in thumb_candidates)

    return {
        "episode_dir": str(ep),
        "is_valid": len(missing) == 0,
        "missing": missing,
        "has_thumbnail_asset": has_thumb
    }
