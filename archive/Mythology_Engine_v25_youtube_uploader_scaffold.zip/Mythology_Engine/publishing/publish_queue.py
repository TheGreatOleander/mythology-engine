from pathlib import Path
import json
from datetime import datetime

QUEUE_DIR = Path("publish_queue")
QUEUE_DIR.mkdir(exist_ok=True)

def enqueue_publish_job(job: dict) -> Path:
    job_id = job.get("episode_id", "unknown")
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    path = QUEUE_DIR / f"publish_{job_id}_{stamp}.json"
    path.write_text(json.dumps(job, indent=2), encoding="utf-8")
    return path

def list_publish_jobs() -> list:
    jobs = []
    for file in sorted(QUEUE_DIR.glob("*.json")):
        jobs.append({
            "file": str(file),
            "name": file.name
        })
    return jobs
