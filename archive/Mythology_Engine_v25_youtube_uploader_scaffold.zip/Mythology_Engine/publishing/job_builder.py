from pathlib import Path
import json

def build_publish_job(episode_dir: str, privacy_status: str = "private") -> dict:
    ep = Path(episode_dir)
    manifest = json.loads((ep / "manifest.json").read_text(encoding="utf-8"))
    metadata = json.loads((ep / "metadata_package.json").read_text(encoding="utf-8"))

    video_path = ep / "video.mp4"
    if not video_path.exists():
        alt = ep / "video_render.mp4"
        if alt.exists():
            video_path = alt

    thumb_path = None
    for candidate in ["thumbnail.jpg", "thumbnail.png"]:
        c = ep / candidate
        if c.exists():
            thumb_path = str(c)
            break

    return {
        "episode_id": manifest.get("episode_id"),
        "video_path": str(video_path),
        "title": metadata.get("selected_title", manifest.get("selected_title", "Untitled Episode")),
        "description": metadata.get("description", ""),
        "tags": metadata.get("tags", []),
        "thumbnail_path": thumb_path,
        "privacy_status": privacy_status,
        "source_episode_dir": str(ep),
    }
