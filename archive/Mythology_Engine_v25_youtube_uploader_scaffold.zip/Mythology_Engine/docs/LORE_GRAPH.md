# Lore Graph

The Lore Graph maps relationships between stored story fragments.

Fragments sharing tags become connected nodes.

Example:

plane + mystery
signal + mystery
ai + mystery

The system detects that "mystery" links multiple fragments and surfaces
possible narrative constellations.

Run:

python tools/show_lore_connections.py
