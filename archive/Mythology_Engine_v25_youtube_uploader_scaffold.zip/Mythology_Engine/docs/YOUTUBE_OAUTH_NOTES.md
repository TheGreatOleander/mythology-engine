# YouTube OAuth Notes

A real uploader requires:
- a Google Cloud project
- YouTube Data API enabled
- OAuth client credentials
- token storage

This scaffold does **not** include real credentials.

The intended flow is:

1. create Google API credentials
2. store `client_secret.json`
3. authorize locally once
4. save token for future uploads

The uploader module in this repo is structured to accept those pieces later.
