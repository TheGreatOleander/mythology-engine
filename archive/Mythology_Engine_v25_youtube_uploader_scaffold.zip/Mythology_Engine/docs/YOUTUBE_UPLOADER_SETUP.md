# YouTube Uploader Setup

To enable real uploads:

1. Create a Google Cloud project
2. Enable the YouTube Data API v3
3. Create OAuth credentials
4. Download client_secret.json
5. Place credentials in:

secrets/client_secret.json

The uploader will then:

- authorize your account
- upload video files
- set title, description, tags
- attach thumbnail
