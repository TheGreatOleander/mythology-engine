# Publish Queue

The publish queue is the final staging area before upload.

Directory:

`publish_queue/`

Each queued upload is represented by a JSON job file.

Example:

```json
{
  "episode_id": "EP_20260309_120000",
  "video_path": "episodes/EP_20260309_120000/video.mp4",
  "title": "The Mystery Historians Still Cannot Explain About the Piri Reis map",
  "description": "....",
  "tags": ["mystery", "history"],
  "privacy_status": "private"
}
```

## Why this exists

The queue separates:
- operator approval
- upload preparation
- actual upload execution

That makes the system safer and easier to audit.
