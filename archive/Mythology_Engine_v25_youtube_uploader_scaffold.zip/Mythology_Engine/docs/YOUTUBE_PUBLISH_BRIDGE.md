# YouTube Publish Bridge

This version restores the project's main commercial destination:
**approved episode packages should flow toward YouTube**.

## Core objective

The system is not being built as an abstract myth engine for its own sake.

It is being built to support this loop:

idea
→ package
→ review
→ approval
→ publish to YouTube

## Publish bridge responsibilities

The publish bridge is responsible for:

- locating an approved episode package
- validating required assets
- assembling upload metadata
- placing the episode into a publish queue
- handing off to the YouTube uploader module
- defaulting to draft/private uploads for safety

## Required package files

A publish-ready episode package should contain:

- `manifest.json`
- `metadata_package.json`
- `script.txt`
- `video.mp4` or equivalent final render artifact
- `thumbnail.jpg` or an accepted thumbnail placeholder reference

## Safety model

Uploads should default to:
- draft
- private
- or manual-confirmation mode

Blind direct publishing should not be the default.
