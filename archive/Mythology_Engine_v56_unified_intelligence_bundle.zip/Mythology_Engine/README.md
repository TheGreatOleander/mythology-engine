# Mythology Engine v56 – Unified Intelligence Bundle

This bundle merges the studio architecture with the YouTube Intelligence layer.

## Includes

- Mission Control
- Episode Factory
- Provider Layer
- Channel Brain
- Learning Loop
- Title + Thumbnail Optimizer
- Episode Pipeline Manager
- YouTube Intelligence

## Demos

Unified demo:

`python tools/demo_full_system.py`

YouTube intelligence only:

`python tools/run_youtube_intelligence.py`
