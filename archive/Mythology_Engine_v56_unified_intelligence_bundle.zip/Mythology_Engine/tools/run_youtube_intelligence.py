from youtube_intelligence.engines.intelligence_report import build_report
import json
print(json.dumps(build_report(), indent=2))
