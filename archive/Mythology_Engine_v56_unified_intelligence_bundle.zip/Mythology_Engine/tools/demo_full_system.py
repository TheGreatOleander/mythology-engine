import json
from mission_control.control_center import MissionControl
from channel_brain.engines.decision_engine import choose_next_topic

mc = MissionControl()

print("Generating episode")
ep = mc.generate_episode()
print(json.dumps(ep, indent=2))

print("\nYouTube intelligence")
intel = mc.get_youtube_intelligence()
print(json.dumps(intel, indent=2))

print("\nBrain selecting topic")
print(choose_next_topic(
    ["Oak Island","Lost Roman Map"],
    ["Oak Island","Atlantis"]
))
