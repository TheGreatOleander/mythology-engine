from episode_factory.factory import run_factory
from youtube_intelligence.engines.intelligence_report import build_report

class MissionControl:
    def generate_episode(self):
        return run_factory(queue_for_publish=False)

    def generate_and_queue(self):
        return run_factory(queue_for_publish=True)

    def get_youtube_intelligence(self):
        return build_report()
