class TopicSignal:
    def __init__(self, topic, trend=0, audience=0):
        self.topic = topic
        self.trend = trend
        self.audience = audience

    def score(self):
        return self.trend + self.audience
