# YouTube Intelligence Integration

This unified bundle folds YouTube Intelligence into the main studio architecture.

## Purpose

Bridge:

- comments
- viewer behavior
- title pattern signals

into:

- ranked topics
- next-topic recommendations
- Mission Control visibility

## Why it matters

The engine can now listen to the channel instead of only pushing content outward.
