import json, pathlib
STORE = pathlib.Path("examples/pipeline.json")

def load():
    if STORE.exists():
        return json.loads(STORE.read_text(encoding="utf-8"))
    return []

def save(data):
    STORE.write_text(json.dumps(data, indent=2), encoding="utf-8")
