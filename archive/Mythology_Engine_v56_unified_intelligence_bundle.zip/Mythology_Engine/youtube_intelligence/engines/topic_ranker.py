def rank_topics(signal_bundle):
    scores = {}
    for group in signal_bundle.values():
        for item in group:
            topic = item["topic"]
            scores.setdefault(topic, 0)
            scores[topic] += item.get("weight", 0)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)
