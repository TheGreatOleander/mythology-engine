class YouTubeSignalProvider:
    def fetch_comment_signals(self):
        return [
            {"topic": "Oak Island treasure mystery", "source": "comment", "weight": 5, "note": "multiple viewers requested follow-up"},
            {"topic": "Atlantis evidence", "source": "comment", "weight": 3, "note": "one viewer requested a deep dive"},
            {"topic": "Ark of the Covenant location", "source": "comment", "weight": 4, "note": "strong curiosity in replies"}
        ]

    def fetch_behavior_signals(self):
        return [
            {"topic": "Oak Island treasure mystery", "source": "watch_pattern", "weight": 4, "note": "retention cluster around treasure content"},
            {"topic": "Lost Roman map discovery", "source": "watch_pattern", "weight": 2, "note": "map content produced moderate replay behavior"}
        ]

    def fetch_title_pattern_signals(self):
        return [
            {"topic": "mystery wording", "source": "title_pattern", "weight": 3, "note": "videos using mystery wording showed higher CTR"},
            {"topic": "question titles", "source": "title_pattern", "weight": 2, "note": "question framing improved clicks"}
        ]
