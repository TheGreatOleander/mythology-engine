from providers.writing.base import BaseWritingProvider

class OpenAIWritingProvider(BaseWritingProvider):
    name = "openai"
    def generate_script(self, topic: str) -> str:
        return f"TITLE: {topic}\n\n## HOOK\nSome discoveries refuse to stay buried, and {topic} is one of them."
