from providers.image.base import BaseImageProvider
from pathlib import Path

class SDXLImageProvider(BaseImageProvider):
    name = "sdxl"
    def generate_image(self, prompt: str, path: str):
        Path(path).write_text("[SDXL STUB]\n\n" + prompt, encoding="utf-8")
        return path
