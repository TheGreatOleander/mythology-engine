class BaseImageProvider:
    name = "base"
    def generate_image(self, prompt: str, path: str):
        raise NotImplementedError
