from providers.tts.base import BaseTTSProvider
from pathlib import Path

class PiperTTSProvider(BaseTTSProvider):
    name = "piper"
    def generate_audio(self, text: str, path: str):
        Path(path).write_text("[PIPER STUB]\n\n" + text, encoding="utf-8")
        return path
