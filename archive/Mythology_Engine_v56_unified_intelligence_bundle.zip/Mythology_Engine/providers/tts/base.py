class BaseTTSProvider:
    name = "base"
    def generate_audio(self, text: str, path: str):
        raise NotImplementedError
