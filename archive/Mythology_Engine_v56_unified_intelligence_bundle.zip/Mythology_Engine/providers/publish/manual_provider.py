class ManualPublishProvider:
    name = "manual"
    def upload(self, video_path, title, description, thumbnail_path=None):
        return {
            "status": "manual_review_required",
            "video_path": video_path,
            "title": title,
            "description": description,
            "thumbnail_path": thumbnail_path
        }
