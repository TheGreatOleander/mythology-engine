import json, datetime
from pathlib import Path
from providers.registry import get_writing_provider, get_tts_provider, get_image_provider, get_publish_provider

EPDIR = Path("episodes")
EPDIR.mkdir(exist_ok=True)

def run_factory(queue_for_publish=False):
    writing = get_writing_provider()
    tts = get_tts_provider()
    image = get_image_provider()
    publish = get_publish_provider()

    topic = "Ancient Map Discovery"
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    ep = EPDIR / f"EP_{stamp}"
    ep.mkdir(parents=True, exist_ok=True)

    script = writing.generate_script(topic)
    (ep / "script.txt").write_text(script, encoding="utf-8")
    audio = tts.generate_audio(script, str(ep / "narration.wav"))
    image.generate_image("ancient mysterious map cinematic still", str(ep / "scene.png"))

    manifest = {
        "episode_id": ep.name,
        "topic": topic,
        "script": str(ep / "script.txt"),
        "audio": audio,
        "image": str(ep / "scene.png"),
        "status": "GENERATED"
    }
    (ep / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    publish_preview = None
    if queue_for_publish:
        publish_preview = publish.upload(str(ep / "final_video.mp4"), topic, f"Automated episode about {topic}")

    return {
        "episode_dir": str(ep),
        "manifest": manifest,
        "publish_preview": publish_preview
    }
