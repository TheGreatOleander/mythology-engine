class VideoMetrics:

    def __init__(self, title, ctr, retention, views, comments):
        self.title = title
        self.ctr = ctr
        self.retention = retention
        self.views = views
        self.comments = comments

    def score(self):
        return (
            self.ctr * 3 +
            self.retention * 2 +
            (self.views / 1000) +
            (self.comments * 0.5)
        )

    def to_dict(self):
        return {
            "title": self.title,
            "ctr": self.ctr,
            "retention": self.retention,
            "views": self.views,
            "comments": self.comments,
            "score": self.score()
        }
