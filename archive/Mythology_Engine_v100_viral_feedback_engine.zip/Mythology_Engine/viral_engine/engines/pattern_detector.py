def detect_patterns(metrics):

    best = sorted(metrics, key=lambda m: m.score(), reverse=True)[:5]

    keywords = {}

    for m in best:
        for word in m.title.lower().split():
            if len(word) > 4:
                keywords[word] = keywords.get(word, 0) + 1

    sorted_keywords = sorted(keywords.items(), key=lambda x: x[1], reverse=True)

    return {
        "top_videos": [b.to_dict() for b in best],
        "keywords": sorted_keywords[:10]
    }
