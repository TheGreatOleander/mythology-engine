def recommend_topics(patterns):

    keywords = [k for k,_ in patterns["keywords"]]

    recommendations = []

    for k in keywords[:5]:
        recommendations.append(f"mystery of the {k}")
        recommendations.append(f"the hidden truth about {k}")

    return recommendations
