import json
from pathlib import Path
from viral_engine.models.video_metrics import VideoMetrics

def load_metrics(path):

    data = json.loads(Path(path).read_text())
    metrics = []

    for v in data:
        metrics.append(
            VideoMetrics(
                v["title"],
                v["ctr"],
                v["retention"],
                v["views"],
                v["comments"]
            )
        )

    return metrics
