from viral_engine.storage.analytics_loader import load_metrics
from viral_engine.engines.pattern_detector import detect_patterns
from viral_engine.engines.strategy_adjuster import recommend_topics
import json

metrics = load_metrics("examples/analytics/sample_metrics.json")

patterns = detect_patterns(metrics)
topics = recommend_topics(patterns)

print(json.dumps({
    "patterns": patterns,
    "recommended_topics": topics
}, indent=2))
