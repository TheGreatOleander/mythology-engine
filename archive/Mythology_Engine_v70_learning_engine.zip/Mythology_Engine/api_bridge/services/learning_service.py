from learning_engine.engines.learning_cycle import run_learning_cycle

def learning_cycle_service():
    return run_learning_cycle()
