from learning_engine.engines.learning_cycle import run_learning_cycle
import json

result = run_learning_cycle()
print(json.dumps(result, indent=2))
