class YouTubeAnalyticsFetcher:

    def fetch_video_metrics(self):
        # Placeholder for real YouTube Analytics API
        return [
            {"title": "The Map That Shouldn't Exist", "views": 12000, "ctr": 7.2, "watch_time": 4.8},
            {"title": "Atlantis Evidence Found?", "views": 8500, "ctr": 5.5, "watch_time": 3.9},
            {"title": "Oak Island Treasure Mystery", "views": 15000, "ctr": 8.1, "watch_time": 5.2}
        ]
