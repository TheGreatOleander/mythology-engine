class VideoMetrics:
    def __init__(self, title, views, ctr, watch_time):
        self.title = title
        self.views = views
        self.ctr = ctr
        self.watch_time = watch_time

    def to_dict(self):
        return {
            "title": self.title,
            "views": self.views,
            "ctr": self.ctr,
            "watch_time": self.watch_time
        }
