def analyze_performance(videos):
    best_ctr = max(videos, key=lambda v: v["ctr"])
    best_views = max(videos, key=lambda v: v["views"])
    best_watch = max(videos, key=lambda v: v["watch_time"])

    insights = {
        "highest_ctr_video": best_ctr["title"],
        "highest_views_video": best_views["title"],
        "highest_watch_time_video": best_watch["title"]
    }

    return insights
