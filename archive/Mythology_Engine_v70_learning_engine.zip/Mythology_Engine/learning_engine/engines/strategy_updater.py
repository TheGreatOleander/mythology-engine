def suggest_strategy(insights):
    return {
        "recommended_focus": insights["highest_views_video"],
        "note": "Future episodes should explore similar themes."
    }
