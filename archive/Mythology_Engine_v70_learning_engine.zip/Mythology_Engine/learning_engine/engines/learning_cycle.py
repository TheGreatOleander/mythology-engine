from learning_engine.providers.youtube.analytics_fetcher import YouTubeAnalyticsFetcher
from learning_engine.engines.performance_analyzer import analyze_performance
from learning_engine.engines.strategy_updater import suggest_strategy

def run_learning_cycle():
    fetcher = YouTubeAnalyticsFetcher()
    metrics = fetcher.fetch_video_metrics()

    insights = analyze_performance(metrics)
    strategy = suggest_strategy(insights)

    return {
        "metrics": metrics,
        "insights": insights,
        "strategy": strategy
    }
