from calendar_engine.integration.calendar_status_provider import get_calendar, summarize
from mission_control_bridge.calendar_dashboard.dashboard_model import build_dashboard

def dashboard_service():
    calendar = get_calendar()
    summary = summarize()
    return build_dashboard(calendar, summary)
