def build_dashboard(calendar, summary):

    upcoming = sorted(
        calendar.get("entries", []),
        key=lambda x: x.get("publish_date","")
    )[:5]

    return {
        "calendar_summary": summary,
        "next_releases": upcoming
    }
