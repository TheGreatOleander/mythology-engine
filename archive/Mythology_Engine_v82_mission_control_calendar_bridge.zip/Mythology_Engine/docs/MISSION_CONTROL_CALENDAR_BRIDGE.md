# Mission Control Calendar Bridge

Integrates the Content Calendar Engine with Mission Control dashboards.

API:

GET /mission-dashboard

Returns:

- calendar summary
- next scheduled releases
