# Mythology Engine v82 – Mission Control Calendar Bridge

Connects the Content Calendar Engine to a dashboard API for Mission Control.

Endpoint:

GET /mission-dashboard
