from pathlib import Path
import json

DATA = Path("examples/dashboard/content_calendar.json")

def get_calendar():
    if DATA.exists():
        return json.loads(DATA.read_text())
    return {"entries":[]}

def summarize():
    data = get_calendar()
    entries = data.get("entries", [])
    return {
        "total": len(entries),
        "planned": len([e for e in entries if e.get("status") == "planned"]),
        "published": len([e for e in entries if e.get("status") == "published"])
    }
