from audience_engine.engines.interaction_pipeline import run_interaction_cycle

def audience_interaction_service():
    return run_interaction_cycle()
