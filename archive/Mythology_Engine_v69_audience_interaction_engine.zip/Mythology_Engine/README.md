# Mythology Engine v69 – Audience Interaction Engine

Adds audience interaction capability.

Responsibilities:

- read viewer comments
- classify comment intent
- generate reply drafts

API endpoint:

GET /audience-cycle
