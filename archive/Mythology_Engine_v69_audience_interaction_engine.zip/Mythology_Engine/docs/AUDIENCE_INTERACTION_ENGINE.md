# Audience Interaction Engine

This module processes viewer comments and generates reply drafts.

Flow:

YouTube comments
     ↓
comment analysis
     ↓
intent detection
     ↓
reply generation
     ↓
human review → post reply

Endpoint:

GET /audience-cycle
