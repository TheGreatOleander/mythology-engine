def analyze_comment(comment):
    text = comment["text"].lower()
    if "?" in text:
        intent = "question"
    elif "great" in text or "amazing" in text:
        intent = "positive_feedback"
    else:
        intent = "discussion"

    return {
        "author": comment["author"],
        "text": comment["text"],
        "intent": intent
    }
