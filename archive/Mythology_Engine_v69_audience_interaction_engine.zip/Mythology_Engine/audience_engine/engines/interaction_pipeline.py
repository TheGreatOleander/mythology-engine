from audience_engine.providers.youtube.comment_fetcher import YouTubeCommentFetcher
from audience_engine.engines.comment_analyzer import analyze_comment
from audience_engine.engines.reply_generator import generate_reply

def run_interaction_cycle():
    fetcher = YouTubeCommentFetcher()
    comments = fetcher.fetch_recent_comments()

    analyzed = [analyze_comment(c) for c in comments]
    replies = [generate_reply(c) for c in analyzed]

    return {
        "comments_processed": len(comments),
        "reply_drafts": replies
    }
