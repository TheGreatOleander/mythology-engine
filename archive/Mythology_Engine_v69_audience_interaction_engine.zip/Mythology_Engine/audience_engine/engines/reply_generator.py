def generate_reply(comment):
    if comment["intent"] == "question":
        reply = f"Great question, {comment['author']}! We're investigating that further in the next episode."
    elif comment["intent"] == "positive_feedback":
        reply = f"Thanks for watching, {comment['author']}! More mysteries coming soon."
    else:
        reply = f"Interesting thought, {comment['author']}. We'll keep digging into this topic."

    return {
        "author": comment["author"],
        "original_comment": comment["text"],
        "draft_reply": reply
    }
