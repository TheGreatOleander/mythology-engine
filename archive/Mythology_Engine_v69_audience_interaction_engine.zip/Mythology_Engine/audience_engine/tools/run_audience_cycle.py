from audience_engine.engines.interaction_pipeline import run_interaction_cycle
import json

result = run_interaction_cycle()
print(json.dumps(result, indent=2))
