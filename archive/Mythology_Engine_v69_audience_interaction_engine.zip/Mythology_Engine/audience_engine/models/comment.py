class Comment:
    def __init__(self, author, text):
        self.author = author
        self.text = text

    def to_dict(self):
        return {"author": self.author, "text": self.text}
