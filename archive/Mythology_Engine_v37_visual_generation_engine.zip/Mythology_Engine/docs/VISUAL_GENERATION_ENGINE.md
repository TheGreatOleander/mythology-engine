# Visual Generation Engine

Purpose:
Automatically generate visual assets for documentary scenes.

Pipeline:

scene_plan.json
→ prompt builder
→ image generation engine
→ generated scene assets

Supported generators (future):

- Stable Diffusion
- SDXL
- DALL-E
- local diffusion models

Goal:
Remove dependency on stock footage by generating custom visuals
for every scene.
