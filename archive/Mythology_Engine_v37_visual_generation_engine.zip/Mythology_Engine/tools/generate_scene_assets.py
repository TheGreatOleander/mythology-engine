import sys
from visual_generation_engine.scene_asset_builder import generate_scene_assets

if len(sys.argv) < 3:
    print("Usage: python tools/generate_scene_assets.py <scene_plan.json> <output_dir>")
else:
    assets = generate_scene_assets(sys.argv[1], sys.argv[2])
    print(assets)
