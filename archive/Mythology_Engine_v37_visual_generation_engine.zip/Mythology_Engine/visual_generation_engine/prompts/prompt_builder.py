def build_prompt(scene_text, visual_type):
    base_style = "cinematic documentary still, atmospheric lighting, detailed, dramatic composition"

    if visual_type == "map":
        return f"ancient map illustration, mysterious cartography, {base_style}, {scene_text}"
    elif visual_type == "artifact":
        return f"ancient artifact on dark background, museum lighting, {base_style}, {scene_text}"
    elif visual_type == "document":
        return f"aged historical document parchment texture, {base_style}, {scene_text}"
    elif visual_type == "text_card":
        return f"dark mysterious background texture, minimal cinematic style, {scene_text}"

    return f"{base_style}, {scene_text}"
