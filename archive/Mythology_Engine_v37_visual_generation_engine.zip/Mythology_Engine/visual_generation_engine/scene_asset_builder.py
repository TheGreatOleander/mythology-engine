import json
from pathlib import Path
from visual_generation_engine.prompts.prompt_builder import build_prompt
from visual_generation_engine.generators.image_generator import generate_image

def generate_scene_assets(scene_plan_file, output_dir):
    plan = json.loads(Path(scene_plan_file).read_text())

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    assets = []

    for scene in plan:
        prompt = build_prompt(scene.get("text",""), scene.get("visual_type","artifact"))
        file = out_dir / f'scene_asset_{scene["scene_index"]:03d}.png'
        generate_image(prompt, str(file))

        assets.append({
            "scene_index": scene["scene_index"],
            "prompt": prompt,
            "asset": str(file)
        })

    return assets
