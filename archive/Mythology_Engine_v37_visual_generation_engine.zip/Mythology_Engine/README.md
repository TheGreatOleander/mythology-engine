# Mythology Engine v37 – Visual Generation Engine

Adds automatic visual generation for documentary scenes.

New subsystem:

visual_generation_engine/

Capabilities:

- scene prompt generation
- asset generation scaffold
- integration point for diffusion models

Tool:

python tools/generate_scene_assets.py scene_plan.json output_dir
