# Subtitle & Caption Engine

Adds timed captions to the Mythology Engine pipeline.

Pipeline addition:

script
→ subtitle timing
→ SRT generation
→ optional FFmpeg burn-in

This enables:

- YouTube subtitles
- TikTok captions
- Reels captions
- accessibility
- SEO transcription
