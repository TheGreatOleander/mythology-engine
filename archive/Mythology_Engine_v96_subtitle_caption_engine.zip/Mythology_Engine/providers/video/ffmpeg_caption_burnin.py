import subprocess
from pathlib import Path

def burn_in_captions(video, srt, output):

    Path(output).parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",
        "-i", video,
        "-vf", f"subtitles={srt}",
        "-c:a", "copy",
        output
    ]

    subprocess.run(cmd, check=False)

    if not Path(output).exists():
        Path(output).write_text(
            "CAPTIONED VIDEO PLACEHOLDER\n"
            + f"video={video}\n"
            + f"srt={srt}",
            encoding="utf-8"
        )

    return output
