class SubtitleLine:

    def __init__(self, index, start, end, text):
        self.index = index
        self.start = start
        self.end = end
        self.text = text

    def to_srt(self):
        return f"{self.index}\n{self.start} --> {self.end}\n{self.text}\n"
