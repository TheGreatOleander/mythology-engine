from pathlib import Path

def write_srt(subtitles, output_file):

    Path(output_file).parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, "w", encoding="utf-8") as f:
        for sub in subtitles:
            f.write(sub.to_srt())
            f.write("\n")

    return output_file
