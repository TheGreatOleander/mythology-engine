from subtitle_engine.models.subtitle_line import SubtitleLine

def seconds_to_timestamp(seconds):

    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)

    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def generate_subtitles(script_lines, seconds_per_line=3):

    subtitles = []
    time = 0

    for i, line in enumerate(script_lines, start=1):

        start = seconds_to_timestamp(time)
        end = seconds_to_timestamp(time + seconds_per_line)

        subtitles.append(
            SubtitleLine(i, start, end, line)
        )

        time += seconds_per_line

    return subtitles
