# Mythology Engine v96 – Subtitle & Caption Timing Engine

This version introduces automated subtitle generation.

## Features

- subtitle timing engine
- SRT file generation
- FFmpeg caption burn-in helper

## Run

python runtime/tools/demo_subtitles.py

## Output

examples/output/subtitles.srt
