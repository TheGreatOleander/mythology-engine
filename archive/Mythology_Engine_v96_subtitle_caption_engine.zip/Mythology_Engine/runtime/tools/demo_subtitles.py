from subtitle_engine.engines.subtitle_generator import generate_subtitles
from subtitle_engine.engines.srt_writer import write_srt
import json

script = [
"This map may not be possible.",
"It was discovered beneath a forgotten archive.",
"The markings suggest a lost route.",
"Some believe it points to a lost civilization."
]

subs = generate_subtitles(script)
srt = write_srt(subs, "examples/output/subtitles.srt")

print(json.dumps({
    "subtitle_lines": len(subs),
    "srt_file": srt
}, indent=2))
