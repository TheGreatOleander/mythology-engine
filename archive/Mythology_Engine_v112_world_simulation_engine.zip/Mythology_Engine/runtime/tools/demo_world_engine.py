from world_sim.models.world_entity import WorldEntity
from world_sim.engines.world_engine import WorldEngine
import json

engine = WorldEngine()

entity = WorldEntity(
    name="The Hidden Archive",
    entity_type="location",
    description="A sealed repository rumored to hold forbidden cartographic records.",
    first_seen="Episode_001"
)

engine.register_entity(entity)

print(json.dumps(engine.list_entities(), indent=2))
