# World Simulation Engine

Tracks locations, artifacts, organizations, and characters across the narrative universe.

## Purpose

Provide a structured "world model" so stories can reference a consistent universe.
