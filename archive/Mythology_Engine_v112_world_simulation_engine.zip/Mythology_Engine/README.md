# Mythology Engine v112 – World Simulation Engine

Adds a structured world model for the mythology universe.

## Run

python runtime/tools/demo_world_engine.py
