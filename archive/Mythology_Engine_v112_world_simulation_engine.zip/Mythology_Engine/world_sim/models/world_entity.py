class WorldEntity:
    def __init__(self, name, entity_type, description, first_seen=None):
        self.name = name
        self.entity_type = entity_type
        self.description = description
        self.first_seen = first_seen

    def to_dict(self):
        return {
            "name": self.name,
            "entity_type": self.entity_type,
            "description": self.description,
            "first_seen": self.first_seen
        }
