from world_sim.storage.world_store import WorldStore

class WorldEngine:

    def __init__(self):
        self.store = WorldStore()

    def register_entity(self, entity):
        self.store.add(entity.to_dict())

    def list_entities(self, entity_type=None):
        items = self.store.load()
        if entity_type:
            return [i for i in items if i.get("entity_type") == entity_type]
        return items

    def timeline(self):
        items = self.store.load()
        return sorted(items, key=lambda x: x.get("first_seen") or "")
