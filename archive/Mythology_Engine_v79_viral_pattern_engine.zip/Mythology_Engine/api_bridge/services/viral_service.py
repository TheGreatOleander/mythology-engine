from analysis.viral_pattern_engine.viral_pattern_engine import analyze

def viral_analysis_service():
    return analyze()
