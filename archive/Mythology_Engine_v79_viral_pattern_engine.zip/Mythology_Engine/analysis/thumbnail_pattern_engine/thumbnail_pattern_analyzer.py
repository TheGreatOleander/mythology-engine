def analyze_thumbnail_patterns(history):

    patterns = {
        "cinematic":0,
        "dramatic":0,
        "artifact":0,
        "map":0
    }

    for h in history:
        p = h.get("thumbnail_prompt","").lower()

        if "cinematic" in p: patterns["cinematic"]+=1
        if "dramatic" in p: patterns["dramatic"]+=1
        if "artifact" in p: patterns["artifact"]+=1
        if "map" in p: patterns["map"]+=1

    return patterns
