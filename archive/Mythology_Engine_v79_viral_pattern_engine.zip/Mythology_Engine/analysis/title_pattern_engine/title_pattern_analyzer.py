def analyze_title_patterns(history):

    patterns = {
        "secret":0,
        "truth":0,
        "shouldnt_exist":0,
        "decoded":0
    }

    for h in history:
        t = h["title"].lower()
        if "secret" in t: patterns["secret"]+=1
        if "truth" in t: patterns["truth"]+=1
        if "shouldn't exist" in t: patterns["shouldnt_exist"]+=1
        if "decoded" in t: patterns["decoded"]+=1

    return patterns
