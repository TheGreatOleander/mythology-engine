def cluster_topics(history):

    clusters = {}

    for h in history:
        topic = h.get("topic","unknown")

        if topic not in clusters:
            clusters[topic] = 0

        clusters[topic]+=1

    ranked = sorted(clusters.items(), key=lambda x: x[1], reverse=True)

    return ranked
