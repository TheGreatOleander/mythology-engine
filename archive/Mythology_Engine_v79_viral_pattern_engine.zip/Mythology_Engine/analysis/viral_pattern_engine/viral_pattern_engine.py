import json
from pathlib import Path

from analysis.title_pattern_engine.title_pattern_analyzer import analyze_title_patterns
from analysis.thumbnail_pattern_engine.thumbnail_pattern_analyzer import analyze_thumbnail_patterns
from analysis.topic_cluster_engine.topic_cluster_analyzer import cluster_topics

DATA = Path("examples/viral_patterns/history.json")

def load_history():
    if DATA.exists():
        return json.loads(DATA.read_text())
    return []

def analyze():

    history = load_history()

    return {
        "title_patterns": analyze_title_patterns(history),
        "thumbnail_patterns": analyze_thumbnail_patterns(history),
        "topic_clusters": cluster_topics(history)
    }
