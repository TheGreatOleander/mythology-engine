# Viral Pattern Engine

Analyzes channel history to detect:

- title keyword patterns
- thumbnail visual patterns
- topic clusters

API:

GET /viral-patterns
