import datetime
from publishing_engine.providers.youtube.youtube_uploader import YouTubeUploader
from pipeline_manager.engines.publish_history import record

def publish_episode(video,title,description,thumbnail):

    result = YouTubeUploader().upload(video,title,description,thumbnail)

    entry = {
        "timestamp":datetime.datetime.utcnow().isoformat(),
        "title":title,
        "video":video,
        "result":result["status"]
    }

    record(entry)

    return {
        "publish_result":result,
        "history_entry":entry
    }
