# Channel Activity Dashboard API

Endpoint:

GET /channel-activity

Returns:

- last 5 publish attempts
- recommended topic
- ranked topic signals
