# Mythology Engine v76 – Channel Activity Dashboard

Adds a unified activity endpoint for Mission Control dashboards.

Endpoint:

GET /channel-activity

Includes:

- recent publish attempts
- intelligence recommendations
- topic ranking
