import json
from pathlib import Path
from pipeline_manager.engines.publish_history import load as load_history

INTEL = Path("examples/intelligence/report.json")

def channel_activity():

    history = load_history()

    if INTEL.exists():
        intel = json.loads(INTEL.read_text())
    else:
        intel = {"recommended_topic":None,"ranked_topics":[]}

    return {
        "recent_publish_attempts": history[-5:],
        "recommended_topic": intel.get("recommended_topic"),
        "ranked_topics": intel.get("ranked_topics")
    }
