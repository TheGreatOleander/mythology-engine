from episode_factory.factory import generate_episode
from publishing_engine.engines.publish_pipeline import publish_episode
from studio.engines.channel_activity import channel_activity

class StudioEngine:

    def health(self):
        return {"status":"ok"}

    def generate(self):
        return generate_episode()

    def publish(self,manifest):
        return publish_episode(
            manifest["video"],
            manifest["title"],
            manifest["description"],
            manifest["thumbnail"]
        )

    def activity(self):
        return channel_activity()
