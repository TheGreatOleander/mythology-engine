# Trend Radar

Trend Radar is designed to feed the story library with signals from
emerging topics and anomalies.

Current version uses simulated sources.

Future integrations:

- YouTube trending API
- Reddit mystery / history communities
- Wikipedia anomaly pages
- news API feeds

Pipeline:

trend signal
→ story fragment
→ story library
→ story forge
→ episode concept
