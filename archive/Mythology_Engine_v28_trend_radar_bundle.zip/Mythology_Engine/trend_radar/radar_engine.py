import random
from datetime import datetime
from pathlib import Path
import json

# Simulated sources for now
TREND_SOURCES = [
    "strange archaeological discovery",
    "unexplained radio signal",
    "ancient map mystery",
    "lost civilization rumor",
    "odd satellite anomaly",
    "historical document controversy"
]

LIB = Path("story_library/storage")
INDEX = LIB/"index.json"

def load_index():
    if INDEX.exists():
        return json.loads(INDEX.read_text())
    return []

def save_fragment(text, tags=None):
    tags = tags or []
    data = load_index()

    fid = f"frag_trend_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    path = LIB/f"{fid}.md"
    path.write_text(text)

    entry = {"id":fid,"tags":tags,"file":str(path)}
    data.append(entry)
    INDEX.write_text(json.dumps(data,indent=2))

    return entry

def scan_trends():
    topic = random.choice(TREND_SOURCES)

    fragment = f"Trend signal detected: {topic}. Investigate whether deeper historical or unexplained patterns exist."

    entry = save_fragment(fragment, tags=["trend","signal"])

    return {
        "trend_topic": topic,
        "fragment_saved": entry["id"]
    }
