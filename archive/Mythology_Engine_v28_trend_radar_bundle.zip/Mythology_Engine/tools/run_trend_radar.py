from trend_radar.radar_engine import scan_trends

if __name__ == "__main__":
    result = scan_trends()

    print("\nTrend Radar Result\n")
    print(result)
