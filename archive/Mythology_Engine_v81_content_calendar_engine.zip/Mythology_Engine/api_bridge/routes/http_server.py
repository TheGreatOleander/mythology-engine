from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from api_bridge.services.calendar_service import create_calendar_service, calendar_status_service

class Handler(BaseHTTPRequestHandler):
    def send_json(self, data, code=200):
        body = json.dumps(data, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/calendar-status":
            self.send_json(calendar_status_service())
        else:
            self.send_json({"error":"not_found"},404)

    def do_POST(self):
        if self.path == "/build-calendar":
            self.send_json(create_calendar_service())
        else:
            self.send_json({"error":"not_found"},404)

def run():
    server = HTTPServer(("127.0.0.1",8765), Handler)
    print("Content Calendar API running http://127.0.0.1:8765")
    server.serve_forever()

if __name__ == "__main__":
    run()
