from calendar_engine.scheduler.calendar_scheduler import build_calendar
from calendar_engine.backlog_manager.backlog_store import add_entries, load
from calendar_engine.backlog_manager.backlog_summary import summarize

def create_calendar_service():
    arc = {
        "arc_id": "ARC_DEMO_001",
        "topic": "Ancient Map Discovery",
        "episodes": [
            {"episode_number": 1, "title": "Ancient Map Discovery – Part 1: The Discovery"},
            {"episode_number": 2, "title": "Ancient Map Discovery – Part 2: The Hidden Evidence"},
            {"episode_number": 3, "title": "Ancient Map Discovery – Part 3: The Forbidden Map"},
            {"episode_number": 4, "title": "Ancient Map Discovery – Part 4: The Lost Expedition"},
            {"episode_number": 5, "title": "Ancient Map Discovery – Part 5: The Final Secret"}
        ]
    }
    entries = build_calendar(arc, cadence_days=2)
    data = add_entries(entries)
    return {
        "arc_id": arc["arc_id"],
        "entries_added": len(entries),
        "calendar": data
    }

def calendar_status_service():
    data = load()
    return {
        "calendar": data,
        "summary": summarize(data)
    }
