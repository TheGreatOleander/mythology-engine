def summarize(calendar_data):
    entries = calendar_data.get("entries", [])
    summary = {
        "total_entries": len(entries),
        "planned": 0,
        "drafting": 0,
        "ready": 0,
        "published": 0
    }

    for e in entries:
        status = e.get("status", "planned")
        if status in summary:
            summary[status] += 1

    return summary
