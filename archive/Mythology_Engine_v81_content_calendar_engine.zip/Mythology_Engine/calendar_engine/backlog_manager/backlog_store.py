import json
from pathlib import Path

STORE = Path("examples/calendar/content_calendar.json")

def load():
    if STORE.exists():
        return json.loads(STORE.read_text(encoding="utf-8"))
    return {"entries": []}

def save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(STORE)

def add_entries(entries):
    data = load()
    data["entries"].extend(entries)
    save(data)
    return data
