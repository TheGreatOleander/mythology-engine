class CalendarEntry:
    def __init__(self, publish_date, title, arc_id=None, status="planned"):
        self.publish_date = publish_date
        self.title = title
        self.arc_id = arc_id
        self.status = status

    def to_dict(self):
        return {
            "publish_date": self.publish_date,
            "title": self.title,
            "arc_id": self.arc_id,
            "status": self.status
        }
