import datetime
from calendar_engine.models.calendar_entry import CalendarEntry

def build_calendar(arc, cadence_days=2, start_date=None):
    if start_date is None:
        start = datetime.date.today()
    else:
        start = datetime.date.fromisoformat(start_date)

    entries = []
    for i, episode in enumerate(arc.get("episodes", [])):
        publish_date = start + datetime.timedelta(days=i * cadence_days)
        entries.append(
            CalendarEntry(
                publish_date=publish_date.isoformat(),
                title=episode["title"],
                arc_id=arc.get("arc_id"),
                status="planned"
            ).to_dict()
        )
    return entries
