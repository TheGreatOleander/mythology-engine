# Content Calendar Engine

This module turns story arcs into a real publishing calendar.

## Purpose

- convert a multi-episode arc into dated publish slots
- maintain a backlog of planned content
- summarize calendar health for dashboards

## API

POST /build-calendar
GET /calendar-status

## Why it matters

This upgrades the system from:
- generating content ideas

to:
- managing a real release schedule
