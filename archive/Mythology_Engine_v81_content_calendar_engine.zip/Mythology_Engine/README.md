# Mythology Engine v81 – Content Calendar Engine

Adds channel scheduling and backlog planning.

## Endpoints

POST /build-calendar
GET /calendar-status

## What it does

- turns a story arc into scheduled publish dates
- stores entries in a content calendar
- summarizes backlog status

## Start

python tools/start_api.py
