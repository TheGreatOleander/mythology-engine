import urllib.request, json

BASE = "http://127.0.0.1:8765"

def call(path, method="GET"):
    req = urllib.request.Request(BASE + path, method=method)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())

print("Build:", json.dumps(call("/build-calendar", "POST"), indent=2))
print("Status:", json.dumps(call("/calendar-status"), indent=2))
