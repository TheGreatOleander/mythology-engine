# Mythology Engine v35 – TTS Integration Bundle

This version adds the first real narration bridge.

## What it adds

- provider-based TTS manager
- OpenAI TTS scaffold
- ElevenLabs TTS scaffold
- placeholder fallback
- narration tools
- voice direction docs

## Main tools

Synthesize audio from a script:
`python tools/synthesize_script_audio.py <script.txt>`

Run smoke test:
`python tools/tts_smoke_test.py`

## Goal

Replace placeholder narration with an actual documentary voice.
