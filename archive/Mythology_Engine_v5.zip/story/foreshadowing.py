import random


def generate_foreshadow() -> str:
    lines = [
        "What appeared isolated would later prove connected.",
        "The symbol would emerge again in an entirely different century.",
        "At the time, no one understood this was part of a wider pattern.",
        "The archive entry seemed small. The consequences were not.",
    ]
    return random.choice(lines)
