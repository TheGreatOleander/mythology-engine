import random


def generate_hook(topic: str) -> str:
    hooks = [
        f"In the historical record, {topic} appears where it should not.",
        f"Researchers thought {topic} was a footnote until the pattern sharpened.",
        f"Some discoveries are strange. {topic} is stranger because it keeps returning.",
        f"The deeper investigators looked into {topic}, the less ordinary it became.",
    ]
    return random.choice(hooks)
