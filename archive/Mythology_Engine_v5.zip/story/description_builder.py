def build_description(topic: str, title: str) -> str:
    return (
        f"{title}\n\n"
        f"This episode explores {topic} through a documentary-style mystery lens. "
        "The goal is not cheap noise but compelling narrative structure, strong curiosity, "
        "and a larger mythology that unfolds across the channel.\n\n"
        "Review all claims before publication if you replace the fictionalized scaffolding "
        "with source-backed research."
    )
