from typing import List


def build_outline(topic: str, hook: str, foreshadow_line: str) -> List[str]:
    return [
        f"Hook: {hook}",
        f"Context: introduce {topic} as a real anomaly, disputed artifact, or unresolved case.",
        "Escalation: explain why the accepted explanation feels incomplete.",
        "Evidence: present three pieces of tension, contradiction, or unexplained detail.",
        "Twist: connect the case to a broader hidden pattern.",
        f"Foreshadowing: {foreshadow_line}",
        "Close: end with a compelling unresolved question.",
    ]
