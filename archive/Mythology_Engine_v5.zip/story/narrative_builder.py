from typing import List


def build_story(topic: str, hook: str, outline: List[str], foreshadow_line: str) -> str:
    sections = [
        "TITLE",
        topic.upper(),
        "",
        "HOOK",
        hook,
        "",
        "BACKGROUND",
        f"Historical references to {topic} are fragmentary, contradictory, or strangely persistent.",
        "The case survives because it refuses to resolve cleanly.",
        "",
        "DISCOVERY",
        f"Investigators examining {topic} uncover details that should have settled the issue but do the opposite.",
        "Each answer opens a larger chamber of doubt.",
        "",
        "TWIST",
        "The anomaly does not feel isolated. It behaves like a shard from a larger hidden system.",
        foreshadow_line,
        "",
        "CLOSING QUESTION",
        f"If {topic} was never meant to stand alone, what else belongs to the same pattern?",
    ]
    return "\n".join(sections + ["", "OUTLINE", *outline, ""])
