from core.episode_runner import run_episode


if __name__ == "__main__":
    manifest = run_episode()
    print("Generated episode package:")
    print(f"  Episode ID: {manifest.episode_id}")
    print(f"  Title:      {manifest.title}")
    print(f"  Topic:      {manifest.topic}")
    print(f"  Status:     {manifest.status}")
