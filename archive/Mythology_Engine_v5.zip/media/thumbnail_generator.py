def generate_thumbnail_prompt(topic: str, title: str) -> str:
    return (
        f"{topic}, dark documentary style, one central object, cinematic fog, "
        f"ancient archive mood, high contrast, visual emphasis on mystery, title theme: {title}"
    )
