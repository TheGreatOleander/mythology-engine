from tools.ffmpeg_tools import build_render_command


def assemble_video(script_path: str, audio_path: str, output_path: str, resolution: str) -> str:
    return build_render_command(
        image_sequence="assets/images/*.png",
        audio_path=audio_path,
        output_path=output_path,
        resolution=resolution,
    )
