from pathlib import Path


def synthesize(script_text: str, output_path: Path) -> str:
    output_path.write_text(
        "Stub narration placeholder. Replace with TTS byte output in production.",
        encoding="utf-8",
    )
    return str(output_path)
