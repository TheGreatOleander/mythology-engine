import random
from typing import List


STATIC_TOPICS: List[str] = [
    "the Antikythera Mechanism",
    "the Voynich Manuscript",
    "the Baghdad Battery",
    "the Piri Reis map",
    "a lost monastery archive",
    "an unexplained subterranean structure",
    "a vanished polar expedition",
    "the mechanism beneath the ruins",
]


def get_topic(use_real_sources: bool = False) -> str:
    # Deliberately stubbed. This is where source-backed discovery should be added.
    # For now the system returns a curated topic that fits the channel identity.
    return random.choice(STATIC_TOPICS)
