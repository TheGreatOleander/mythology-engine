# Content Strategy

## Best-fit channel format

This engine is best suited to a **documentary mystery** channel.

That format works because it is:
- narration-driven
- visually economical
- endlessly extensible
- naturally curiosity-based

## Recommended content buckets

Use 3 recurring buckets:

1. **Impossible artifacts**
2. **Vanished expeditions**
3. **Forbidden archives / hidden institutions**

That gives variety without diluting the brand.

## Episode length

Recommended starting range:
- 6 to 10 minutes

Long enough for narrative shape.
Short enough to avoid dead air.

## Hidden advantage

Most channels make isolated episodes.
This system can make connected ones.

That means:
- casual viewers get a clean entry point
- repeat viewers get mythology payoff
