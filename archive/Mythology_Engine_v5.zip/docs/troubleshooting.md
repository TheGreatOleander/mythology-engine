# Troubleshooting

## `python -m scheduler.daily_run` fails with import errors

Make sure you are running from the project root and have installed requirements.

## FFmpeg command exists but no video renders

That is expected in this scaffold unless you provide actual image and audio assets.
This repo currently generates the command string and placeholders.

## Narration file is not a real WAV

Correct. The narration module is stubbed by design.
Replace `media/narration.py` with a real TTS integration.

## No real upload occurs

Correct. The uploader is a safe stub.

## Episodes folder remains empty

Check for permission issues or earlier exceptions in the pipeline.

## Why is there no scraping yet?

Because half-baked scraping creates junk topics, bad summaries, and brittle systems.
The curated-topic phase is deliberate.
