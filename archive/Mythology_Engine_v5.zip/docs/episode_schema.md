# Episode Package Schema

Each generated episode folder should contain at minimum:

- `script.txt` — full narration script
- `manifest.json` — machine-readable episode data
- `REVIEW.txt` — operator-facing summary

## Manifest fields

- `episode_id`
- `topic`
- `title`
- `script_path`
- `narration_path`
- `thumbnail_prompt`
- `render_command`
- `metadata`
- `status`

## Recommended future additions

- source citations
- character / artifact references
- continuity thread references
- estimated duration
- performance summary after publish
