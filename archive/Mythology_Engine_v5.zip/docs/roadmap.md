# Roadmap

## Stage 1 — Solid scaffold
Status: done in this repo

- modular code layout
- review-first pipeline
- episode manifests
- strong docs

## Stage 2 — Real production media
Recommended next

- real TTS integration
- real image generation
- real FFmpeg render flow
- subtitle generation

## Stage 3 — Source-backed discovery
After media is stable

- Wikipedia / archive source intake
- topic scoring
- novelty filtering
- duplication checks

## Stage 4 — Publishing and feedback
After confidence improves

- YouTube upload with approval gate
- analytics ingestion
- title and topic feedback loop

## Stage 5 — Multi-channel universe
Only after one channel proves itself

- multiple content lanes
- shared mythology graph
- cross-channel callbacks
