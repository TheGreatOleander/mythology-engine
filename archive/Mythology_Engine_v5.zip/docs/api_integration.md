# API Integration Notes

## TTS

Best integration candidates:
- OpenAI TTS
- ElevenLabs
- Coqui for self-hosted work

Keep the interface simple:
- input: script text
- output: audio file path

## Uploading

A real YouTube uploader should:
- authenticate via OAuth
- support drafts / private uploads
- never bypass review

## Discovery

Do not let discovery turn into random noisy scraping.
Source-backed does not mean source-drowned.

The discovery layer should rank topics by:
- mystery strength
- clarity
- visual potential
- title potential
- novelty against recent uploads
