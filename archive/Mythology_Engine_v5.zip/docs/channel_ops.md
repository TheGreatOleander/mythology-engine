# Channel Operations

## Naming guidance

The channel identity should feel archival, restrained, and mysterious.

Good naming style:
- The Hidden Archive
- The Black Library
- The Uncatalogued
- Archive North
- The Silent Record

## Posting cadence

Recommended:
- 3 quality uploads per week at first
- scale to daily only after the pipeline is stable

Daily slop is not a flex.
Consistency with quality is the flex.

## Thumbnail rules

Keep thumbnails simple:
- one main object
- dark background
- strong contrast
- minimal text

## Title rules

Good title characteristics:
- clear mystery
- one central tension
- no mushy phrasing
- no generic “top 10” energy
