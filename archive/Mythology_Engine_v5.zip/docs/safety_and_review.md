# Safety and Review

## Why review is mandatory

Automated publishing systems drift.
They hallucinate.
They flatten nuance.
They repeat themselves.
They can also generate claims that sound stronger than the evidence.

That is why this repo defaults to review-first packaging.

## Review requirements before any public upload

- factual claims checked if using real historical material
- tone checked for platform compliance
- title checked for excess bait
- visuals checked for copyright issues
- narration checked for quality and pacing

## What not to do

Do not:
- fully auto-publish without checks
- scrape copyrighted material blindly
- present fictional framing as verified history
- trust analytics without context

## Best practice

Use the engine as leverage, not as a substitute for editorial judgment.
