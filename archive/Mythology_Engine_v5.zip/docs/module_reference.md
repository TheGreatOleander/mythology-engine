# Module Reference

## `core/episode_runner.py`
Main orchestrator for building one episode package.

## `discovery/topic_discovery.py`
Returns a channel-fit topic. Currently curated. Later should support source-backed intake.

## `story/hook_generator.py`
Creates curiosity-first opening lines.

## `story/title_optimizer.py`
Creates YouTube-friendly titles without needing manual drafting every time.

## `story/outline_builder.py`
Builds the narrative skeleton used by the long-form script builder.

## `story/narrative_builder.py`
Generates the actual script body.

## `media/narration.py`
Writes a placeholder narration artifact. Replace this with real TTS when ready.

## `media/thumbnail_generator.py`
Creates image-generation prompts for thumbnails.

## `media/video_assembler.py`
Returns an FFmpeg render command for the episode.

## `publishing/review_queue.py`
Writes a human review package into the episode folder.

## `publishing/youtube_uploader.py`
Uploader stub. Deliberately inert by default.

## `analytics/youtube_feedback.py`
Reserved for post-publication performance ingestion.
