# Workflow

## Daily use pattern

1. Run the daily scheduler
2. Inspect the generated script
3. Improve or approve the metadata
4. Replace placeholder media generation with real integrations
5. Render the final video
6. Upload only after review
7. Record performance later

## Practical operator model

The machine handles repetition.
The human handles judgment.

That split matters.

## Suggested review checklist

- Is the title strong without being nonsense?
- Does the script have a real hook in the first 10 seconds?
- Does the thumbnail prompt produce a single strong visual?
- Is the episode too vague, too repetitive, or too similar to the last one?
- Does the mythology remain coherent?
