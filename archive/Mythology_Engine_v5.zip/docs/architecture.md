# Architecture

Mythology Engine v5 is organized as a **human-reviewed narrative production system**.

## Primary loop

```text
Discovery
  → Story Planning
  → Script Generation
  → Narration / Thumbnail / Render Prep
  → Review Package
  → Upload Stub
  → Analytics Feedback
  → Universe Memory Update
```

## Layer responsibilities

### `discovery/`
Selects suitable topics for the channel.
Today this is curated and static.
Later it should support real source-backed intake.

### `story/`
Transforms a topic into:
- hook
- title
- outline
- long-form script
- description

This layer is responsible for **viewer curiosity** and **narrative shape**.

### `media/`
Produces or prepares:
- narration output
- thumbnail prompt
- render command

This layer is responsible for **presentation**.

### `publishing/`
Does not auto-publish by default.
It creates a review package first.
That is intentional and sane.

### `analytics/`
Eventually closes the loop by showing:
- CTR
- retention
- comment themes
- topic lift

### `bible/`
Stores the shared universe memory so the channel can maintain continuity.

## Design principle

This repo favors:
- modularity
- replaceable integrations
- explicit review points
- documentation over magic
