# Setup Guide

## Requirements

- Python 3.10+
- FFmpeg installed and available on PATH for real rendering
- API keys only if you later enable real TTS or uploads

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## First run

```bash
python -m scheduler.daily_run
```

## Expected output

A new folder will be created under `episodes/` containing:

- `script.txt`
- `manifest.json`
- `REVIEW.txt`

## Why there is no live uploader yet

Because blind automation is how channels get wrecked.

This version is intentionally built around **review-first publishing**.
