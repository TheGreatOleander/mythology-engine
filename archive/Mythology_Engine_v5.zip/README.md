# Mythology Engine v5

Mythology Engine v5 is a modular foundation for a documentary-style mystery channel
that can generate episodes, prepare media assets, package metadata, and keep a
shared mythology coherent across many uploads.

This repo is designed for **human-in-the-loop automation**.

It does **not** try to fully remove judgment from publishing.
Instead, it gives you a strong production spine:

topic discovery → story planning → script generation → narration synthesis →
thumbnail prompt generation → video assembly → metadata packaging →
review queue → upload → analytics feedback → mythology update

---

## What this project is

This is a **channel production system** for mystery / history / anomaly content.

It is built around one core creative insight:

> every episode can feel standalone to a casual viewer while secretly belonging
> to a larger connected universe.

That allows the channel to work on two levels:

1. **Single-video curiosity** for new viewers
2. **Deep mythology payoff** for repeat viewers

---

## Current state

This version is a **serious scaffold**, not a fake toy repo.

It includes:

- modular Python package layout
- a runnable daily episode pipeline
- config-driven behavior
- episode manifests
- topic discovery stubs
- story planning and metadata generation
- FFmpeg command generation
- uploader and analytics stubs
- persistent mythology memory
- extensive documentation
- tests for the core planning flow

It does **not** include live API credentials, real TTS calls, or direct upload keys.
Those should be added deliberately and reviewed before production use.

---

## Quick start

### 1) Create an environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Configure

Copy the sample environment file and edit as needed.

```bash
cp .env.example .env
```

### 3) Run one episode build

```bash
python -m scheduler.daily_run
```

The pipeline will:

- choose a topic
- create an episode plan
- generate a script
- create narration / thumbnail / render placeholders
- write an episode manifest into `episodes/`
- prepare metadata for review

---

## Repository structure

```text
Mythology_Engine_v5/
├── analytics/            # feedback and performance hooks
├── assets/               # placeholder media directories
├── bible/                # persistent mythology memory
├── config/               # engine configuration
├── core/                 # orchestration and shared models
├── discovery/            # topic discovery and source strategy
├── docs/                 # full documentation set
├── episodes/             # generated episode manifests
├── media/                # narration, thumbnail, and video helpers
├── publishing/           # upload and review queue stubs
├── scheduler/            # entrypoints for daily runs
├── story/                # hooks, titles, outlines, full scripts
├── templates/            # prompt and metadata templates
├── tests/                # smoke tests for planning flow
└── tools/                # ffmpeg and utility helpers
```

---

## Production philosophy

This project is strongest when used like this:

- the machine handles repetition
- the human handles taste
- the mythology system handles continuity
- the analytics layer handles adaptation

That is the sane path.

A blind autoposter is how channels become slop factories.
This repo aims higher than that.

---

## Next recommended build steps

1. Connect a real TTS engine
2. Add real FFmpeg rendering
3. Wire in a thumbnail image generator
4. Add source-backed topic discovery
5. Implement YouTube upload with a review gate
6. Feed analytics back into topic and title selection
7. Add multi-channel support

See `docs/roadmap.md` for the staged plan.
