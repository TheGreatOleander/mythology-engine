from story.title_optimizer import optimize_title
from story.hook_generator import generate_hook
from story.outline_builder import build_outline


def test_title_contains_topic():
    topic = "the Voynich Manuscript"
    assert topic in optimize_title(topic)


def test_hook_returns_text():
    hook = generate_hook("the Baghdad Battery")
    assert isinstance(hook, str)
    assert len(hook) > 10


def test_outline_has_multiple_sections():
    outline = build_outline("topic", "hook", "foreshadow")
    assert len(outline) >= 5
