def upload(video_path: str, title: str, description: str) -> dict:
    # Stub only. Real uploader should use OAuth and a deliberate approval step.
    return {
        "video_path": video_path,
        "title": title,
        "description": description,
        "status": "not_uploaded_stub",
    }
