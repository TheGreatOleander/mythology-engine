from pathlib import Path
from core.models import EpisodeManifest


def write_review_package(episode_dir: Path, manifest: EpisodeManifest) -> None:
    review_text = (
        f"Episode ID: {manifest.episode_id}\n"
        f"Title: {manifest.title}\n"
        f"Topic: {manifest.topic}\n"
        f"Script: {manifest.script_path}\n"
        f"Narration: {manifest.narration_path}\n"
        f"Thumbnail prompt: {manifest.thumbnail_prompt}\n"
        f"Render command: {manifest.render_command}\n"
        f"Status: {manifest.status}\n"
        "\nReview this package before upload.\n"
    )
    (episode_dir / "REVIEW.txt").write_text(review_text, encoding="utf-8")
