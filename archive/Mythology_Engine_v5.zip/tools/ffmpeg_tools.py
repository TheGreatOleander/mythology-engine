def build_render_command(image_sequence: str, audio_path: str, output_path: str, resolution: str) -> str:
    return (
        f'ffmpeg -y -framerate 1/6 -pattern_type glob -i "{image_sequence}" '
        f'-i "{audio_path}" -vf "scale={resolution},format=yuv420p" '
        f'-c:v libx264 -c:a aac -shortest "{output_path}"'
    )
