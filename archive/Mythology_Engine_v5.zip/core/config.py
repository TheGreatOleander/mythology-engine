import json
from pathlib import Path


DEFAULT_CONFIG_PATH = Path("config/engine_config.json")


def load_config(path: Path = DEFAULT_CONFIG_PATH) -> dict:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)
