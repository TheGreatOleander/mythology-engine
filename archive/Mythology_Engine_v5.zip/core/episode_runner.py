from pathlib import Path
import json
from datetime import datetime

from core.config import load_config
from core.models import EpisodeManifest
from core.universe_engine import UniverseEngine
from discovery.topic_discovery import get_topic
from story.hook_generator import generate_hook
from story.foreshadowing import generate_foreshadow
from story.title_optimizer import optimize_title
from story.narrative_builder import build_story
from story.description_builder import build_description
from story.outline_builder import build_outline
from media.narration import synthesize
from media.thumbnail_generator import generate_thumbnail_prompt
from media.video_assembler import assemble_video
from publishing.review_queue import write_review_package


def _episode_id() -> str:
    return datetime.utcnow().strftime("EP%Y%m%d_%H%M%S")


def run_episode() -> EpisodeManifest:
    config = load_config()
    universe = UniverseEngine()

    topic = get_topic(use_real_sources=config.get("use_real_sources", False))
    hook = generate_hook(topic)
    foreshadow_line = generate_foreshadow()
    title = optimize_title(topic)
    outline = build_outline(topic, hook, foreshadow_line)
    description = build_description(topic, title)

    script_text = build_story(topic, hook, outline, foreshadow_line)
    episode_id = _episode_id()

    episode_dir = Path("episodes") / episode_id
    episode_dir.mkdir(parents=True, exist_ok=True)

    script_path = episode_dir / "script.txt"
    script_path.write_text(script_text, encoding="utf-8")

    narration_path = synthesize(script_text, episode_dir / "narration.wav")
    thumbnail_prompt = generate_thumbnail_prompt(topic, title)
    render_command = assemble_video(
        script_path=str(script_path),
        audio_path=str(narration_path),
        output_path=str(episode_dir / "final_video.mp4"),
        resolution=config["video_resolution"],
    )

    metadata = {
        "title": title,
        "description": description,
        "tags": ", ".join([
            "mystery", "history", "archive", "documentary", "anomaly"
        ]),
    }

    manifest = EpisodeManifest(
        episode_id=episode_id,
        topic=topic,
        title=title,
        script_path=str(script_path),
        narration_path=str(narration_path),
        thumbnail_prompt=thumbnail_prompt,
        render_command=render_command,
        metadata=metadata,
        status="draft_review",
    )

    manifest_path = episode_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest.__dict__, indent=2), encoding="utf-8")

    write_review_package(episode_dir=episode_dir, manifest=manifest)

    universe.record_history({
        "episode_id": episode_id,
        "topic": topic,
        "title": title,
        "generated_at_utc": datetime.utcnow().isoformat() + "Z",
    })
    universe.save()

    return manifest
