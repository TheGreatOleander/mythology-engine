import json
from pathlib import Path
from typing import Any, Dict


class UniverseEngine:
    def __init__(self, path: str = "bible/universe_graph.json") -> None:
        self.path = Path(path)
        with self.path.open("r", encoding="utf-8") as fh:
            self.data: Dict[str, Any] = json.load(fh)

    def add(self, category: str, item: dict) -> None:
        self.data.setdefault(category, []).append(item)

    def record_history(self, item: dict) -> None:
        self.data.setdefault("history", []).append(item)

    def list_threads(self) -> list:
        return self.data.setdefault("threads", [])

    def save(self) -> None:
        with self.path.open("w", encoding="utf-8") as fh:
            json.dump(self.data, fh, indent=2)
