from dataclasses import dataclass, field
from typing import List, Dict


@dataclass
class EpisodePlan:
    topic: str
    hook: str
    title: str
    archetype: str
    outline: List[str]
    foreshadow_line: str
    description: str
    tags: List[str] = field(default_factory=list)


@dataclass
class EpisodeManifest:
    episode_id: str
    topic: str
    title: str
    script_path: str
    narration_path: str
    thumbnail_prompt: str
    render_command: str
    metadata: Dict[str, str]
    status: str = "draft"
