from typing import Dict, Optional


class ThreadManager:
    def __init__(self, threads: Optional[Dict[str, int]] = None) -> None:
        self.threads = threads or {}

    def increase(self, name: str, amount: int = 1) -> None:
        self.threads[name] = self.threads.get(name, 0) + amount

    def reset(self, name: str) -> None:
        self.threads[name] = 0

    def hottest(self) -> Optional[str]:
        if not self.threads:
            return None
        return max(self.threads, key=self.threads.get)

    def snapshot(self) -> Dict[str, int]:
        return dict(self.threads)
