class PublishEngine:

    def __init__(self):
        self.supported_targets = [
            "youtube",
            "youtube_shorts",
            "tiktok",
            "instagram_reels"
        ]

    def prepare_payload(self, release_package):

        return {
            "title": release_package.get("title"),
            "description": release_package.get("description"),
            "video": release_package.get("video"),
            "thumbnail": release_package.get("thumbnail"),
            "platform_targets": self.supported_targets
        }

    def simulate_publish(self, payload):

        return {
            "publish_mode": "simulation",
            "targets": payload["platform_targets"],
            "video": payload["video"],
            "title": payload["title"]
        }
