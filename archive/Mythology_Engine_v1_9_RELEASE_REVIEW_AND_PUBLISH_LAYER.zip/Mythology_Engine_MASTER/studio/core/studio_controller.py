from studio.config.loader import load_profile, load_secrets
from studio.providers.provider_registry import ProviderRegistry
from studio.modes.mode_runner import run_mode
from core.orchestrator.master_orchestrator import MasterOrchestrator

from publishing.provider_layer.video.ffmpeg_provider import FFmpegProvider
from publishing.provider_layer.image.sdxl_provider import SDXLProvider
from publishing.provider_layer.audio.piper_provider import PiperProvider

from production.episode_pipeline import EpisodePipeline
from release.review.release_review_engine import ReleaseReviewEngine
from publishing.publish_engine import PublishEngine

class StudioController:

    def __init__(self, profile_path="configs/studio_profile.json", secrets_path="configs/secrets.json"):

        self.profile = load_profile(profile_path)
        self.secrets = load_secrets(secrets_path)

        self.providers = ProviderRegistry(self.profile, self.secrets)
        self.orchestrator = MasterOrchestrator()

        self.ffmpeg = FFmpegProvider()
        self.sdxl = SDXLProvider()
        self.piper = PiperProvider()

        self.pipeline = EpisodePipeline(
            image_provider=self.sdxl,
            audio_provider=self.piper,
            video_provider=self.ffmpeg
        )

        self.reviewer = ReleaseReviewEngine()
        self.publisher = PublishEngine()

    def run(self, mode="manual", action="full-cycle", publish=False):

        run_policy = run_mode(mode, action, publish)

        if action == "episode-test":
            result = self.pipeline.run(
                topic="The Origin of the Impossible Map"
            )
            return {
                "episode_result": result,
                "run_policy": run_policy
            }

        if action == "review-release":
            review = self.reviewer.inspect()
            return {
                "release_review": review,
                "run_policy": run_policy
            }

        if action == "publish-sim":
            episode = self.pipeline.run(
                topic="The Origin of the Impossible Map"
            )

            payload = self.publisher.prepare_payload(
                episode["release_package"]
            )

            publish = self.publisher.simulate_publish(payload)

            return {
                "publish_simulation": publish,
                "run_policy": run_policy
            }

        cycle = self.orchestrator.run_cycle()

        return {
            "cycle_result": cycle,
            "run_policy": run_policy
        }
