# Mythology Engine – YouTube Publish Bridge

This version keeps the project pointed at its real destination: YouTube.

## What it adds

- package validator
- publish job builder
- publish queue
- YouTube upload stub
- approval-to-queue handoff

## Core loop

idea
→ package
→ review
→ approval
→ publish queue
→ uploader

## Safe default

Uploads are prepared as queued private/draft-style jobs first.
