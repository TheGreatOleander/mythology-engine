package com.mythology.missioncontrol

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var console: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        console = findViewById(R.id.txtConsole)
        status = findViewById(R.id.txtStatus)

        findViewById<Button>(R.id.btnHealth).setOnClickListener {
            call("Health") { LocalApiClient.get(this,"/health") }
        }

        findViewById<Button>(R.id.btnGenerate).setOnClickListener {
            call("Generate") { LocalApiClient.post(this,"/generate-episode") }
        }

        findViewById<Button>(R.id.btnIntel).setOnClickListener {
            call("Intel") { LocalApiClient.get(this,"/youtube-intelligence") }
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun call(label:String, req:()->String){
        status.text="Calling $label"
        thread {
            try{
                val r=req()
                runOnUiThread{
                    console.text=r
                    status.text="Success"
                }
            }catch(e:Exception){
                runOnUiThread{
                    console.text=e.toString()
                    status.text="Error"
                }
            }
        }
    }
}
