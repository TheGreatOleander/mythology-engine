# Mythology Engine v33 – Unified Cinematic Bundle

This version folds the Cinematic Engine back into the main repository so the entire
system remains one coherent project.

## Main subsystems

- story_library
- story_forge
- lore_graph
- narrative_engine
- title_thumbnail_lab
- trend_radar
- performance_feedback
- mission_control
- cinematic_engine
- publishing

## End goal

Generate, review, render, queue, upload, and improve documentary-style YouTube episodes.
