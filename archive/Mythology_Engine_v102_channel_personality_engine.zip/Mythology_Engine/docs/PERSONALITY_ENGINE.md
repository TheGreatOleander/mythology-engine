# Channel Personality Engine

This engine ensures the channel has a consistent voice and identity.

Responsibilities:

- narrator identity
- intro/outro style
- philosophical framing
- tonal consistency across episodes
