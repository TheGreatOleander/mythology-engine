from personality_engine.engines.personality_engine import PersonalityEngine

engine = PersonalityEngine()

script = "A map was discovered beneath a forgotten archive."

styled = engine.apply_to_script(script)

print(styled)
