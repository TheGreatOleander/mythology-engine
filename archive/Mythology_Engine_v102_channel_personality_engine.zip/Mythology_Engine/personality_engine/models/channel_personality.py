class ChannelPersonality:

    def __init__(self, name, tone, philosophy, narrator_style):
        self.name = name
        self.tone = tone
        self.philosophy = philosophy
        self.narrator_style = narrator_style

    def to_dict(self):
        return {
            "name": self.name,
            "tone": self.tone,
            "philosophy": self.philosophy,
            "narrator_style": self.narrator_style
        }
