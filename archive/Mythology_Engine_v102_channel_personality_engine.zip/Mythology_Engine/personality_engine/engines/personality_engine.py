from personality_engine.models.channel_personality import ChannelPersonality
from personality_engine.data.default_personality import DEFAULT_PERSONALITY

class PersonalityEngine:

    def load_default(self):
        p = DEFAULT_PERSONALITY
        return ChannelPersonality(
            p["name"],
            p["tone"],
            p["philosophy"],
            p["narrator_style"]
        )

    def apply_to_script(self, script):

        personality = self.load_default()

        intro = f"Welcome back. I am {personality.name}. "                 "Tonight we examine another fragment of forgotten history.\n\n"

        outro = "\n\nHistory rarely tells the full story. "                 "But sometimes the evidence survives."

        return intro + script + outro
