DEFAULT_PERSONALITY = {
    "name": "The Archivist",
    "tone": "mysterious, thoughtful, investigative",
    "philosophy": "history hides more than it reveals",
    "narrator_style": "calm documentary storyteller"
}
