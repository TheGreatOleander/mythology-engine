# Mythology Engine v102 – Channel Personality Engine

Adds a consistent narrator voice and channel philosophy.

This ensures all generated stories feel like they come from the
same storyteller.

Run demo:

python runtime/tools/demo_personality_engine.py
