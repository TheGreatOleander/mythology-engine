package com.mythology.missioncontrol

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val generate = findViewById<Button>(R.id.btnGenerateEpisode)
        val publish = findViewById<Button>(R.id.btnPublish)
        val analytics = findViewById<Button>(R.id.btnAnalytics)

        generate.setOnClickListener {
            Toast.makeText(this, "Episode Factory Triggered", Toast.LENGTH_SHORT).show()
        }

        publish.setOnClickListener {
            Toast.makeText(this, "Publishing Queue Opened", Toast.LENGTH_SHORT).show()
        }

        analytics.setOnClickListener {
            Toast.makeText(this, "Channel Analytics", Toast.LENGTH_SHORT).show()
        }
    }
}
