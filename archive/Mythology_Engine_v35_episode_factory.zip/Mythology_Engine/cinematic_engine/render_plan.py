import json
from pathlib import Path

BACKGROUND_MAP = {
    "artifact": "examples/assets/backgrounds/artifact_bg.jpg",
    "map": "examples/assets/backgrounds/map_bg.jpg",
    "document": "examples/assets/backgrounds/document_bg.jpg",
    "text_card": "examples/assets/backgrounds/dark_bg.jpg",
}

def write_render_plan(episode_dir: str) -> str:
    ep = Path(episode_dir)
    scene_plan = json.loads((ep / "scene_plan.json").read_text(encoding="utf-8"))
    scene_cmds = []

    for item in scene_plan:
        bg = BACKGROUND_MAP.get(item["visual_type"], BACKGROUND_MAP["text_card"])
        out = ep / "render_scenes" / f'scene_{item["scene_index"]:03d}.mp4'
        out.parent.mkdir(parents=True, exist_ok=True)
        duration = item.get("duration_seconds", 8)
        cmd = f'ffmpeg -y -loop 1 -i "{bg}" -t {duration} -vf "scale=1920:1080" -r 30 -c:v libx264 -pix_fmt yuv420p "{out}"'
        scene_cmds.append({
            "scene_index": item["scene_index"],
            "command": cmd,
            "output": str(out)
        })

    concat_cmd = f'ffmpeg -y -f concat -safe 0 -i concat.txt -i "{ep / "narration.wav"}" -vf "subtitles={ep / "subtitles.srt"}" -c:v libx264 -c:a aac -shortest "{ep / "final_video.mp4"}"'
    plan = {
        "episode_dir": str(ep),
        "scene_commands": scene_cmds,
        "concat_command": concat_cmd,
        "output_video": str(ep / "final_video.mp4")
    }
    path = ep / "render_plan.json"
    path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return str(path)
