def build_scene_plan(script_text: str) -> list:
    blocks = [line.strip() for line in script_text.splitlines() if line.strip() and not line.startswith("TITLE:")]
    plan = []
    idx = 0
    for line in blocks:
        visual_type = "artifact"
        motion = "slow_zoom_in"
        lowered = line.lower()
        if "map" in lowered:
            visual_type = "map"
            motion = "slow_pan_left"
        elif "question" in lowered:
            visual_type = "text_card"
            motion = "slow_zoom_in"
        elif "history" in lowered or "trace" in lowered:
            visual_type = "document"
            motion = "gentle_parallax"
        plan.append({
            "scene_index": idx,
            "text": line,
            "visual_type": visual_type,
            "motion": motion,
            "duration_seconds": 8
        })
        idx += 1
    return plan
