# Mythology Engine v35 – Episode Factory

This version adds the Episode Factory and Voice Engine.

## New subsystems

- episode_factory
- voice_engine

## What changed

The system can now generate a full episode package from one command:

Trend Radar
→ Story Forge
→ Narrative Engine
→ Title & Thumbnail Lab
→ Voice Engine
→ Cinematic Engine
→ Episode Package
→ optional Publish Queue

## Run it

`python tools/run_factory.py`

Queue for publish:

`python tools/run_factory.py --queue`
