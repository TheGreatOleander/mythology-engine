import json
from pathlib import Path

def _load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))

def show_dashboard():
    print("\n==============================")
    print("MYTHOLOGY ENGINE – MISSION CONTROL")
    print("==============================\n")
    trends = _load_json("trend_signals.json")
    print("Trend Signals:", len(trends) if trends else 0)
    q = Path("publish_queue")
    jobs = list(q.glob("*.json")) if q.exists() else []
    print("Publish Queue:", len(jobs), "jobs")
    perf = _load_json("performance_report.json")
    if perf:
        print("Average CTR:", perf.get("avg_ctr"))
        print("Average Watch Time:", perf.get("avg_watch_time"))
    else:
        print("Performance Data: none")
    print("\n==============================\n")
