import random
from story_library.fragment_store import save_fragment

TREND_SOURCES = [
    "strange archaeological discovery",
    "unexplained radio signal",
    "ancient map mystery",
    "lost civilization rumor",
    "odd satellite anomaly",
    "historical document controversy"
]

def scan_trends():
    topic = random.choice(TREND_SOURCES)
    entry = save_fragment(
        f"Trend signal detected: {topic}. Investigate whether deeper historical or unexplained patterns exist.",
        tags=["trend","signal"],
        source="trend_radar"
    )
    return {"trend_topic": topic, "fragment_saved": entry["id"]}
