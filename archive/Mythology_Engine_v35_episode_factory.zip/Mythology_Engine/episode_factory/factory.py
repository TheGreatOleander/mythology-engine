import json
from pathlib import Path
from datetime import datetime

from trend_radar.radar_engine import scan_trends
from story_forge.forge_engine import build_episode_idea
from narrative_engine.script_builder import build_script
from title_thumbnail_lab.title_engine import generate_titles
from title_thumbnail_lab.thumbnail_engine import generate_thumbnail_concepts
from cinematic_engine.scene_plan_builder import build_scene_plan
from cinematic_engine.render_plan import write_render_plan
from voice_engine.narration_stub import synthesize
from publishing.publish_queue import enqueue

EPISODES = Path("episodes")
EPISODES.mkdir(exist_ok=True)

def _pick_topic(trend_result, idea):
    if trend_result and trend_result.get("trend_topic"):
        return trend_result["trend_topic"]
    return idea.get("topic", "Unknown Mystery")

def run_factory(queue_for_publish: bool = False) -> dict:
    trend_result = scan_trends()
    idea = build_episode_idea()
    topic = _pick_topic(trend_result, idea)

    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    ep = EPISODES / f"EP_{stamp}"
    ep.mkdir(parents=True, exist_ok=True)

    script = build_script(topic)
    (ep / "script.txt").write_text(script, encoding="utf-8")

    titles = generate_titles(topic)
    thumbs = generate_thumbnail_concepts(topic)

    scene_plan = build_scene_plan(script)
    (ep / "scene_plan.json").write_text(json.dumps(scene_plan, indent=2), encoding="utf-8")
    (ep / "thumbnail_concepts.json").write_text(json.dumps(thumbs, indent=2), encoding="utf-8")

    synthesize(script, str(ep / "narration.wav"), voice_profile="documentary_calm")

    (ep / "subtitles.srt").write_text(
        "1\n00:00:00,000 --> 00:00:04,000\nSome discoveries refuse to stay buried.\n",
        encoding="utf-8"
    )

    render_plan = write_render_plan(str(ep))

    manifest = {
        "episode_id": ep.name,
        "topic": topic,
        "trend_result": trend_result,
        "story_idea": idea,
        "selected_title": titles[0] if titles else topic,
        "title_options": titles,
        "thumbnail_concepts_file": str(ep / "thumbnail_concepts.json"),
        "script_file": str(ep / "script.txt"),
        "scene_plan_file": str(ep / "scene_plan.json"),
        "render_plan_file": render_plan,
        "narration_file": str(ep / "narration.wav"),
        "subtitles_file": str(ep / "subtitles.srt"),
        "status": "factory_generated"
    }
    (ep / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    queue_job = None
    if queue_for_publish:
        queue_job = enqueue({
            "episode_id": ep.name,
            "title": manifest["selected_title"],
            "video_path": str(ep / "final_video.mp4"),
            "manifest": str(ep / "manifest.json")
        })

    return {
        "episode_dir": str(ep),
        "manifest": manifest,
        "queue_job": queue_job
    }
