from cinematic_engine.render_plan import write_render_plan
import sys
if len(sys.argv) < 2:
    print("Usage: python tools/generate_render_plan.py <episode_dir>")
else:
    print(write_render_plan(sys.argv[1]))
