from episode_factory.factory import run_factory
import json
import sys

queue = "--queue" in sys.argv
result = run_factory(queue_for_publish=queue)
print(json.dumps(result, indent=2))
