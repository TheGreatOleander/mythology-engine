from title_thumbnail_lab.title_engine import generate_titles
from title_thumbnail_lab.thumbnail_engine import generate_thumbnail_concepts
import json
topic = input("Topic: ").strip()
print(generate_titles(topic))
print(json.dumps(generate_thumbnail_concepts(topic), indent=2))
