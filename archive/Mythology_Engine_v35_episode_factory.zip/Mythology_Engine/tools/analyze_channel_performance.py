import json
from performance_feedback.feedback_engine import analyze_metrics
from performance_feedback.insight_engine import generate_insights

file = input("Metrics JSON file: ").strip()
data = json.loads(open(file, encoding="utf-8").read())
report = analyze_metrics(data)
print(json.dumps(report, indent=2))
print(generate_insights(report))
