from pathlib import Path
from voice_engine.voice_profile import get_profile

def synthesize(script_text: str, output_path: str, voice_profile: str = "documentary_calm") -> str:
    profile = get_profile(voice_profile)
    Path(output_path).write_text(
        "NARRATION STUB\n\n"
        f'VOICE_PROFILE={voice_profile}\n'
        f'PACE={profile["pace"]}\n'
        f'TONE={profile["tone"]}\n\n'
        f'{script_text}',
        encoding="utf-8"
    )
    return output_path
