VOICE_PROFILES = {
    "documentary_calm": {
        "pace": "deliberate",
        "tone": "curious and restrained",
        "provider_hint": "elevenlabs_or_openai",
        "notes": "Avoid robotic cadence. Let pauses breathe."
    },
    "mystery_low": {
        "pace": "slow",
        "tone": "subtle ominous warmth",
        "provider_hint": "elevenlabs_or_coqui",
        "notes": "Keep it grounded. No trailer voice."
    }
}

def get_profile(name="documentary_calm"):
    return VOICE_PROFILES.get(name, VOICE_PROFILES["documentary_calm"])
