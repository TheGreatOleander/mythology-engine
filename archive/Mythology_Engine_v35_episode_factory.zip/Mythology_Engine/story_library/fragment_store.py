import json
from pathlib import Path
from datetime import datetime

LIB = Path("story_library/storage")
INDEX = LIB / "index.json"
LIB.mkdir(parents=True, exist_ok=True)

def load_index():
    if INDEX.exists():
        return json.loads(INDEX.read_text(encoding="utf-8"))
    return []

def save_fragment(text, tags=None, source="manual"):
    tags = tags or []
    data = load_index()
    fid = f"frag_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    path = LIB / f"{fid}.md"
    path.write_text(text, encoding="utf-8")
    entry = {"id": fid, "tags": tags, "source": source, "file": str(path)}
    data.append(entry)
    INDEX.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return entry
