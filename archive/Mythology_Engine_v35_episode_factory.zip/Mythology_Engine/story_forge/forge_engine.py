import random, json
from pathlib import Path

INDEX = Path("story_library/storage/index.json")

def build_episode_idea():
    if not INDEX.exists():
        return {
            "topic": "No fragments yet",
            "seed_fragments": [],
            "direction": "Populate the Story Library first."
        }
    data = json.loads(INDEX.read_text(encoding="utf-8"))
    picks = random.sample(data, min(3, len(data)))
    return {
        "topic": "Pattern Beneath the Fragments",
        "seed_fragments": [p["id"] for p in picks],
        "direction": "Find the hidden pattern connecting these fragments."
    }
