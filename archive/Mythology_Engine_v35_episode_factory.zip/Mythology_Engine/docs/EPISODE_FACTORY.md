# Episode Factory

This module ties the system together into a single command.

## Flow

Trend Radar
→ Story Forge
→ Narrative Engine
→ Title Lab
→ Thumbnail Lab
→ Voice Engine
→ Cinematic Engine
→ Episode Package
→ optional Publish Queue

## Run

`python tools/run_factory.py`

Queue for publish:

`python tools/run_factory.py --queue`

## Why it matters

This is the first time the repo behaves like a real studio instead of a set of parts.
