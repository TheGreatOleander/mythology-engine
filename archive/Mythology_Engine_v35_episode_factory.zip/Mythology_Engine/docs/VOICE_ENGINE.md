# Voice Engine

The Voice Engine defines narrator intent and writes narration artifacts.

Current version:
- voice profiles
- narration stub output

Future versions:
- ElevenLabs integration
- OpenAI TTS integration
- Coqui / Piper local voice support

## Goal

Avoid robotic speech and preserve documentary tone.
