import json
from pathlib import Path
from datetime import datetime

Q = Path("publish_queue")
Q.mkdir(exist_ok=True)

def enqueue(job):
    p = Q / f'job_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}.json'
    p.write_text(json.dumps(job, indent=2), encoding="utf-8")
    return str(p)
