from pathlib import Path
from publishing_engine.providers.youtube.oauth_manager import auth_status

class YouTubeUploader:

    def upload(self, video, title, description, thumbnail=None):
        auth = auth_status()

        if not auth["client_secret_exists"] or not auth["token_exists"]:
            return {
                "status": "oauth_not_ready",
                "auth_status": auth
            }

        if not Path(video).exists():
            return {
                "status": "video_missing",
                "video": video
            }

        return {
            "status": "ready_for_real_upload",
            "video": video,
            "title": title,
            "description": description,
            "thumbnail": thumbnail
        }
