from publishing_engine.providers.youtube.youtube_uploader import YouTubeUploader

def publish_episode(video, title, description, thumbnail=None):
    uploader = YouTubeUploader()
    return uploader.upload(video, title, description, thumbnail)
