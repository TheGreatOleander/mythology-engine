from studio.engines.studio_engine import StudioEngine
from publishing_engine.providers.youtube.oauth_manager import auth_status

engine = StudioEngine()

def health_service():
    return engine.health()

def publish_service():
    return engine.publish()

def oauth_status_service():
    return auth_status()
