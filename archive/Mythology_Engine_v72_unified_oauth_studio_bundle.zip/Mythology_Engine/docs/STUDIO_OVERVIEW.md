# Mythology Studio – Unified OAuth Bundle

This bundle unifies the studio architecture and OAuth publishing scaffold.

Core capabilities:

- API server
- Studio orchestration engine
- OAuth-aware YouTube publishing pipeline
- CLI tools for auth inspection and dev token creation

Endpoints:

GET /health
GET /youtube-auth-status
POST /publish
