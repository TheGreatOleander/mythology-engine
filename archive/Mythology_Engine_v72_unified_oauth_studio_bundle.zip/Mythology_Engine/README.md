# Mythology Engine v72 – Unified OAuth Studio

This version merges the OAuth publishing pipeline into a simplified studio orchestrator.

Start API:

python tools/start_api.py

Check auth:

python tools/check_oauth.py

Create dev token:

python tools/create_dev_token.py
