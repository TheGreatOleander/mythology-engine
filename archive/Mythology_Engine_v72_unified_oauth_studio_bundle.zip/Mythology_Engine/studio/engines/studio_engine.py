from publishing_engine.engines.publish_pipeline import publish_episode

class StudioEngine:

    def health(self):
        return {"status": "ok", "service": "mythology_studio_engine"}

    def publish(self):
        return publish_episode(
            video="examples/episode/final_video.mp4",
            title="The Map That Shouldn't Exist",
            description="An ancient discovery that may rewrite history.",
            thumbnail="examples/episode/thumb.png"
        )
