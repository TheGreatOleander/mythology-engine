from publishing_engine.providers.youtube.oauth_manager import auth_status, bootstrap_oauth_instructions
import json

print(json.dumps({
    "auth_status": auth_status(),
    "instructions": bootstrap_oauth_instructions()
}, indent=2))
