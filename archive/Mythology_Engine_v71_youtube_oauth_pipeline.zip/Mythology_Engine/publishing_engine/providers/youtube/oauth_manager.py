from pathlib import Path
import json

CLIENT_SECRET_DEFAULT = Path("secrets/client_secret.json")
TOKEN_FILE_DEFAULT = Path("secrets/oauth_token.json")

def auth_status(client_secret_path=None, token_path=None):
    client_secret_path = Path(client_secret_path) if client_secret_path else CLIENT_SECRET_DEFAULT
    token_path = Path(token_path) if token_path else TOKEN_FILE_DEFAULT

    return {
        "client_secret_exists": client_secret_path.exists(),
        "token_exists": token_path.exists(),
        "client_secret_path": str(client_secret_path),
        "token_path": str(token_path)
    }

def bootstrap_oauth_instructions():
    return {
        "steps": [
            "Create a Google Cloud project.",
            "Enable the YouTube Data API v3.",
            "Create an OAuth Desktop App credential.",
            "Download the client_secret JSON and place it at secrets/client_secret.json.",
            "Run the local auth bootstrap script to generate secrets/oauth_token.json."
        ],
        "note": "This bundle includes the structure and file paths expected for a real OAuth flow."
    }

def save_fake_token_for_dev(token_path=None):
    token_path = Path(token_path) if token_path else TOKEN_FILE_DEFAULT
    token_path.parent.mkdir(parents=True, exist_ok=True)
    token_path.write_text(json.dumps({
        "access_token": "DEV_PLACEHOLDER",
        "refresh_token": "DEV_PLACEHOLDER",
        "token_uri": "https://oauth2.googleapis.com/token",
        "client_id": "DEV_PLACEHOLDER",
        "client_secret": "DEV_PLACEHOLDER",
        "scopes": ["https://www.googleapis.com/auth/youtube.upload"]
    }, indent=2), encoding="utf-8")
    return str(token_path)
