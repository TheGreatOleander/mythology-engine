from publishing_engine.providers.youtube.youtube_uploader import YouTubeUploader

def run_publish(video_path, title, description, thumbnail=None, privacy_status="private"):
    uploader = YouTubeUploader()
    return uploader.upload_video(video_path, title, description, thumbnail, privacy_status=privacy_status)
