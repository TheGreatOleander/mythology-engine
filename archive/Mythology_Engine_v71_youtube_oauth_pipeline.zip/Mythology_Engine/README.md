# Mythology Engine v71 – YouTube OAuth Pipeline

This version adds the OAuth-aware publishing scaffold.

## New capabilities

- inspect YouTube auth readiness
- standardize secrets file locations
- publish pipeline with OAuth checks
- API endpoint for Mission Control or local tools

## Endpoints

- `GET /youtube-auth-status`
- `POST /publish-episode`

## Start

Check auth:
`python publishing_engine/tools/check_youtube_auth.py`

Test publish:
`python publishing_engine/tools/publish_episode.py`
