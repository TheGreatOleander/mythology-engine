# YouTube OAuth Pipeline

This bundle adds the missing OAuth-aware publishing scaffold.

## What it includes

- OAuth file presence checks
- expected secrets paths
- YouTube uploader scaffold
- API endpoint to inspect auth readiness

## Paths

- `secrets/client_secret.json`
- `secrets/oauth_token.json`

## Endpoints

- `GET /youtube-auth-status`
- `POST /publish-episode`

## Local commands

Check auth state:
`python publishing_engine/tools/check_youtube_auth.py`

Generate a fake dev token for testing file flow:
`python publishing_engine/tools/bootstrap_fake_token.py`

Test publish scaffold:
`python publishing_engine/tools/publish_episode.py`

## Important

This is still a scaffold. It does not perform a live upload by itself.
It is designed so the real Google API client flow can be dropped in without changing the surrounding architecture.
