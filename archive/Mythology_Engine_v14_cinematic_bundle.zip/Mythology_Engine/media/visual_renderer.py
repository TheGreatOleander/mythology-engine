def render_scene(scene):
    background_map = {
        "map": "ancient_map",
        "document": "old_paper",
        "artifact": "museum_table",
        "text_card": "dark_archive"
    }

    return {
        "background": background_map.get(scene.get("visual_type", "artifact"), "dark_archive"),
        "motion": scene.get("motion", "slow_zoom_in"),
        "text": scene.get("text", ""),
        "overlay": scene.get("overlay_style", "subtitle_bottom")
    }
