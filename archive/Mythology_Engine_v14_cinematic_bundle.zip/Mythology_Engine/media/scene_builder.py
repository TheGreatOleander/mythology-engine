def build_scenes(script: str):
    scenes = []
    blocks = [p.strip() for p in script.split("\n") if p.strip()]

    for block in blocks:
        visual_type = "artifact"
        lowered = block.lower()

        if "map" in lowered:
            visual_type = "map"
        elif "archive" in lowered or "document" in lowered:
            visual_type = "document"
        elif "mechanism" in lowered or "artifact" in lowered:
            visual_type = "artifact"
        elif "question" in lowered:
            visual_type = "text_card"

        scenes.append({
            "text": block,
            "visual_type": visual_type,
            "motion": "auto"
        })

    return scenes
