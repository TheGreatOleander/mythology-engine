from pathlib import Path

def synthesize(script: str, out: Path, engine: str = "placeholder"):
    if engine == "placeholder":
        out.write_text("placeholder narration")
        return str(out)

    if engine == "openai":
        from .tts_openai import generate_openai_tts
        return generate_openai_tts(script, out)

    if engine == "elevenlabs":
        from .tts_elevenlabs import generate_elevenlabs_tts
        return generate_elevenlabs_tts(script, out)

    raise ValueError(f"Unknown TTS engine: {engine}")
