from pathlib import Path

def generate_openai_tts(script: str, out: Path):
    out.write_text("openai_tts_placeholder_audio")
    return str(out)
