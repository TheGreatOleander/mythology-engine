from pathlib import Path

def generate_elevenlabs_tts(script: str, out: Path):
    out.write_text("elevenlabs_placeholder_audio")
    return str(out)
