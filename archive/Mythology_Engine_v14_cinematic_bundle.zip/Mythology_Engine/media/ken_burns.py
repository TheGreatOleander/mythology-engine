def build_motion_plan(scene_index: int, motion_hint: str = "auto") -> dict:
    motions = [
        "slow_zoom_in",
        "slow_zoom_out",
        "slow_pan_left",
        "slow_pan_right",
        "gentle_parallax"
    ]

    if motion_hint != "auto":
        selected = motion_hint
    else:
        selected = motions[scene_index % len(motions)]

    return {
        "motion": selected,
        "intensity": "subtle",
        "duration_seconds": 8
    }
