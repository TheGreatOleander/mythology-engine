def generate_thumbnail_variants(topic: str, variant_count: int = 3) -> list:
    base = [
        {
            "title_text": "THEY HID THIS",
            "prompt": f"{topic}, one central object, dark background, high contrast, documentary mystery thumbnail"
        },
        {
            "title_text": "STILL UNEXPLAINED",
            "prompt": f"{topic}, dramatic spotlight, artifact on black, archival atmosphere, minimal composition"
        },
        {
            "title_text": "THE FILE REMAINED SEALED",
            "prompt": f"{topic}, ancient paper texture, red markings, hidden archive mood, cinematic mystery design"
        }
    ]
    return base[:variant_count]
