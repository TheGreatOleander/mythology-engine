from pathlib import Path

def select_music_bed(style: str = "documentary_archive") -> dict:
    if style == "documentary_archive":
        return {
            "track_id": "ambient_pad_01",
            "mood": "low_tension_archive",
            "mix_note": "keep under narration"
        }

    return {
        "track_id": "neutral_pad_01",
        "mood": "neutral",
        "mix_note": "keep subtle"
    }

def write_music_stub(out: Path, style: str = "documentary_archive") -> str:
    bed = select_music_bed(style=style)
    out.write_text(f"music_bed_stub::{bed['track_id']}::{bed['mood']}", encoding="utf-8")
    return str(out)
