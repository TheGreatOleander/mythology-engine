from media.ken_burns import build_motion_plan

def compose_scenes(raw_scenes: list) -> list:
    composed = []
    for index, scene in enumerate(raw_scenes):
        motion = build_motion_plan(index)
        composed.append({
            "scene_index": index,
            "text": scene.get("text", ""),
            "visual_type": scene.get("visual_type", "artifact"),
            "motion": motion["motion"],
            "duration_seconds": motion["duration_seconds"],
            "overlay_style": "subtitle_bottom"
        })
    return composed
