from pathlib import Path

def write_review(epdir, manifest):
    titles = manifest["variants"]["titles"]
    hooks = manifest["variants"]["hooks"]
    thumbs = manifest["variants"]["thumbnail_prompts"]

    review = f'''Review Episode
Episode ID: {manifest["episode_id"]}
Topic: {manifest["topic"]}
Selected title: {manifest["selected_title"]}

Title variants:
- {titles[0]}
- {titles[1]}
- {titles[2]}

Hook variants:
- {hooks[0]}
- {hooks[1]}
- {hooks[2]}

Thumbnail prompt variants:
- {thumbs[0]}
- {thumbs[1]}
- {thumbs[2]}

Cinematic package:
- scene plan: {manifest.get("scene_plan")}
- music bed: {manifest.get("music_bed")}
- thumbnail variants file: {manifest.get("thumbnail_variants")}

Topic score:
{manifest["topic_score"]}

Status: {manifest["status"]}
'''
    (Path(epdir) / "REVIEW.txt").write_text(review, encoding="utf-8")
