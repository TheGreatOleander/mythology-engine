from pathlib import Path
import json

def write_metadata_package(epdir, manifest):
    package = {
        "selected_title": manifest["selected_title"],
        "selected_hook": manifest["selected_hook"],
        "selected_thumbnail_prompt": manifest["selected_thumbnail_prompt"],
        "all_title_variants": manifest["variants"]["titles"],
        "all_hook_variants": manifest["variants"]["hooks"],
        "all_thumbnail_variants": manifest["variants"]["thumbnail_prompts"],
        "generated_thumbnail_packages": str(Path(epdir) / "thumbnail_variants.json"),
        "generated_scene_plan": str(Path(epdir) / "scene_plan.json"),
        "generated_music_bed": manifest.get("music_bed"),
        "tags": ["mystery", "history", "anomaly", "archive", "documentary"]
    }
    (Path(epdir) / "metadata_package.json").write_text(json.dumps(package, indent=2), encoding="utf-8")
