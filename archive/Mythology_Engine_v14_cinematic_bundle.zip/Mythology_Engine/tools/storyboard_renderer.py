def build_storyboard_render_plan(composed_scenes: list, audio_path: str, subtitle_path: str) -> dict:
    return {
        "scene_count": len(composed_scenes),
        "audio_path": audio_path,
        "subtitle_path": subtitle_path,
        "strategy": "ken_burns_slideshow_with_subtitles"
    }
