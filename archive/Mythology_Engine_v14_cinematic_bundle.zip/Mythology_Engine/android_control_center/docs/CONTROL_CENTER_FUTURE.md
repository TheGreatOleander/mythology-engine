# Control Center Future

The Android Control Center is expected to evolve into a full package inspector.

## Current bridge
- import `manifest.json`

## Next useful bridge
- import `scene_plan.json`
- import `thumbnail_variants.json`
- display generated music bed metadata
- preview review package decisions

That would let the phone inspect not just the episode identity, but the cinematic package too.
