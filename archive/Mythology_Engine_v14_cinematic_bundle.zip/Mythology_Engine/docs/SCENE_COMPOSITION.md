# Scene Composition

## Base approach

Each episode is broken into small scenes.

Typical scene duration:
- 6 to 12 seconds

Each scene should contain:
- one primary visual idea
- one motion treatment
- optional subtitle lines
- optional overlay emphasis

## Preferred motion styles

- slow_zoom_in
- slow_zoom_out
- slow_pan_left
- slow_pan_right
- gentle_parallax
- fade_overlay

## Recommended asset types

- archival document
- ancient map
- artifact close-up
- stone texture
- diagram reconstruction
- red-marked reference image

## Rule

Do not overcrowd scenes.
One good image with motion beats five bad images fighting each other.
