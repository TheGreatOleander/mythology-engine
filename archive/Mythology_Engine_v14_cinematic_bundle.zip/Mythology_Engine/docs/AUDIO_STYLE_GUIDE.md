# Audio Style Guide

## Narration

Narration is primary.
Music exists to support it, not compete with it.

## Music bed

Target music profile:
- low ambient pad
- soft tension drone
- minimal percussion
- no bombast
- no EDM nonsense

## Mix philosophy

Narration should always remain clearly intelligible.

If forced to choose between:
- cool sound design
- understandable narration

choose understandable narration every time.
