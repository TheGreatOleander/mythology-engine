# Media Pipeline

Defines how narration and visuals are generated.

script
→ narration synthesis
→ scene breakdown
→ background selection
→ motion generation
→ subtitle sync
→ final render

Visual style: calm documentary archive.
Scene length: 8–12 seconds.
Motion: slow zoom or slow pan.
