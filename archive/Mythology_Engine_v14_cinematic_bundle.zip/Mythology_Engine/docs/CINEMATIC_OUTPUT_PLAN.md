# Cinematic Output Plan

This document defines the intended media character of Mythology Engine.

## Goal

Produce watchable documentary-style videos that feel atmospheric and deliberate,
without requiring blockbuster graphics or hyperactive editing.

The visual target is:

- calm
- archival
- textural
- investigative
- cinematic in pacing, not in spectacle

## Core media layers

1. Narration
2. Scene sequence
3. Motion treatment
4. Background music bed
5. Subtitle track
6. Thumbnail package

## Narration target

The voice should feel like a documentary narrator:

- calm
- steady
- intelligent
- slightly mysterious

It should not feel like:
- a toy voice
- a retro speech synthesizer
- a hype-man yelling at the audience

## Visual target

The visuals should feel like a moving archive:

- slow zooms
- slow pans
- texture overlays
- diagrams
- maps
- artifact stills
- restrained transitions

## Production truth

The system does not need Avatar-grade visuals.
It needs enough motion, pacing, texture, and narration quality to remain engaging.
