class ChannelState:
    def __init__(self, last_topic=None, last_publish_time=None):
        self.last_topic = last_topic
        self.last_publish_time = last_publish_time

    def to_dict(self):
        return {
            "last_topic": self.last_topic,
            "last_publish_time": self.last_publish_time
        }
