import datetime

def next_publish_time():
    # simple cadence: one video per day
    return (datetime.datetime.utcnow() + datetime.timedelta(hours=24)).isoformat()
