import random

TRENDING_TOPICS = [
    "Oak Island treasure mystery",
    "Lost Roman map discovery",
    "Atlantis evidence uncovered",
    "Ark of the Covenant location",
    "Ancient underground city found",
    "Mysterious desert structure seen from space"
]

def choose_next_topic(previous_topic=None):
    pool = [t for t in TRENDING_TOPICS if t != previous_topic]
    if not pool:
        pool = TRENDING_TOPICS
    return random.choice(pool)
