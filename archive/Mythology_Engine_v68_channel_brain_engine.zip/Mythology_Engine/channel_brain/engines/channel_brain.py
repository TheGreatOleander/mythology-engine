from channel_brain.engines.topic_selector import choose_next_topic
from channel_brain.engines.publish_scheduler import next_publish_time

def run_channel_brain(state):
    next_topic = choose_next_topic(state.get("last_topic"))
    schedule = next_publish_time()

    return {
        "next_topic": next_topic,
        "scheduled_publish_time": schedule
    }
