from channel_brain.engines.channel_brain import run_channel_brain
import json

state = {
    "last_topic": "Oak Island treasure mystery",
    "last_publish_time": "2026-03-10T12:00:00"
}

result = run_channel_brain(state)
print(json.dumps(result, indent=2))
