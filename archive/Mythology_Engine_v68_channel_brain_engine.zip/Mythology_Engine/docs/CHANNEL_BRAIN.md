# Channel Brain

The Channel Brain decides what the channel should do next.

Responsibilities:

- choose the next video topic
- determine publish schedule
- avoid repeating recent topics

Endpoint:

GET /channel-brain

Returns the next recommended topic and publish time.
