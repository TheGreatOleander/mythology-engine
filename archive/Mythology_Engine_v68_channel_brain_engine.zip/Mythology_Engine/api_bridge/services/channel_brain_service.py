from channel_brain.engines.channel_brain import run_channel_brain

def channel_brain_service():
    state = {
        "last_topic": "Oak Island treasure mystery",
        "last_publish_time": "2026-03-10T12:00:00"
    }
    return run_channel_brain(state)
