package com.mythology.missioncontrol

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class PublishActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_publish)

        status = findViewById(R.id.txtPublishStatus)
        output = findViewById(R.id.txtPublishOutput)

        findViewById<Button>(R.id.btnAuthStatus).setOnClickListener {
            call("OAuth status") { LocalApiClient.get(this, "/youtube-auth-status") }
        }

        findViewById<Button>(R.id.btnPublishNow).setOnClickListener {
            call("Publish latest") { LocalApiClient.post(this, "/publish") }
        }
    }

    private fun call(label: String, req: () -> String) {
        status.text = "Calling $label ..."
        output.text = "Working..."
        thread {
            try {
                val r = req()
                runOnUiThread {
                    status.text = "Success: $label"
                    output.text = r
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error: $label"
                    output.text = e.stackTraceToString()
                }
            }
        }
    }
}
