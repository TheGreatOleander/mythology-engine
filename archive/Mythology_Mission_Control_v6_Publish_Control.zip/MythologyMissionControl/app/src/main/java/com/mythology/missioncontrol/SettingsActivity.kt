package com.mythology.missioncontrol

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("bridge_settings", MODE_PRIVATE)
        val field = findViewById<EditText>(R.id.editBaseUrl)
        field.setText(prefs.getString("base_url","http://127.0.0.1:8765"))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            prefs.edit().putString("base_url", field.text.toString()).apply()
            finish()
        }
    }
}
