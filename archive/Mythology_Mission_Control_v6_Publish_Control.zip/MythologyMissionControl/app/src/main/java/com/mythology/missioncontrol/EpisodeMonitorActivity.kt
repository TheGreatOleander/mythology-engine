package com.mythology.missioncontrol

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class EpisodeMonitorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_episode_monitor)

        val status = findViewById<TextView>(R.id.txtMonitorStatus)
        val monitor = findViewById<TextView>(R.id.txtMonitor)
        status.text = "Loading pipeline..."

        thread {
            try {
                val result = LocalApiClient.get(this, "/pipeline-status")
                runOnUiThread {
                    status.text = "Pipeline loaded"
                    monitor.text = result
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error"
                    monitor.text = e.stackTraceToString()
                }
            }
        }
    }
}
