# Mythology Mission Control v6

Android Studio project scaffold updated for the unified control + publish bundle.

## New in v6

Added a Publish Control screen with:

- YouTube Auth Status
- Publish Latest Episode

## Expected backend endpoints

- GET /health
- GET /pipeline-status
- GET /youtube-intelligence
- GET /youtube-auth-status
- POST /generate-episode
- POST /publish

## Backend pairing

Use with Mythology Engine v74 unified control + publish bundle.
