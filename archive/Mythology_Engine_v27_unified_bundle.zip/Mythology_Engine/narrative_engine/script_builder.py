ARC=[
"HOOK",
"THE MYSTERY",
"HISTORICAL CONTEXT",
"STRANGE DETAILS",
"THEORIES",
"THE TWIST",
"THE BIG QUESTION"
]

def build_script(topic):
    out=[f"TITLE: {topic}",""]
    for s in ARC:
        out.append("## "+s)
        out.append(f"Narration about {topic}.")
        out.append("")
    return "\n".join(out)
