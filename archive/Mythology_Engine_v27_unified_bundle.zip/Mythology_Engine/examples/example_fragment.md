A forgotten signal repeating across the desert every midnight.
