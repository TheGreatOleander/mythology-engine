import json
from pathlib import Path
from datetime import datetime

LIB = Path("story_library/storage")
INDEX = LIB/"index.json"
LIB.mkdir(parents=True, exist_ok=True)

def load_index():
    if INDEX.exists():
        return json.loads(INDEX.read_text())
    return []

def save_fragment(text, tags=None):
    tags = tags or []
    data = load_index()

    fid = f"frag_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    path = LIB/f"{fid}.md"
    path.write_text(text)

    entry = {"id":fid,"tags":tags,"file":str(path)}
    data.append(entry)
    INDEX.write_text(json.dumps(data,indent=2))
    return entry
