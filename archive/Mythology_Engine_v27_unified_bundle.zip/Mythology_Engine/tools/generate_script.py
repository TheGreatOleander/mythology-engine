from narrative_engine.script_builder import build_script

topic=input("Topic: ")
print(build_script(topic))
