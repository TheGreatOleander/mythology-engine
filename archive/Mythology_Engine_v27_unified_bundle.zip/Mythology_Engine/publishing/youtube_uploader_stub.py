def upload(job):
    return {
        "status":"stub",
        "episode":job.get("episode_id"),
        "note":"OAuth required before real uploads"
    }
