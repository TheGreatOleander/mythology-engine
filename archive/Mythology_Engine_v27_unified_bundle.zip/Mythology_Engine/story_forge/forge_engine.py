import random, json
from pathlib import Path

INDEX = Path("story_library/storage/index.json")

def build_episode_idea():
    if not INDEX.exists():
        return "No fragments yet."

    data = json.loads(INDEX.read_text())
    picks = random.sample(data, min(3,len(data)))

    lines=["EPISODE IDEA",""]
    for p in picks:
        lines.append(p["id"])
    return "\n".join(lines)
