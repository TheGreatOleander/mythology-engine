# Mythology Engine v27

Unified bundle.

Main subsystems:

story_library  – idea archive
story_forge    – combines fragments
lore_graph     – finds narrative connections
narrative_engine – builds structured scripts
publishing     – prepares YouTube uploads

Goal:
Generate, review, and publish documentary style episodes to YouTube.
