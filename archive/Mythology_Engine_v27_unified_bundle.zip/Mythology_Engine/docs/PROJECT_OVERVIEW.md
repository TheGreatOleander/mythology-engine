Mythology Engine

Purpose:
Create story driven YouTube documentary episodes using a human‑guided AI pipeline.

Pipeline:

Story Library
→ Story Forge
→ Lore Graph
→ Narrative Engine
→ Episode Package
→ Publish Queue
→ YouTube Upload
