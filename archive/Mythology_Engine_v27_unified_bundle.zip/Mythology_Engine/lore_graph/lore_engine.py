import json
from pathlib import Path
from collections import defaultdict

INDEX = Path("story_library/storage/index.json")

def connections():
    if not INDEX.exists():
        return {}

    data=json.loads(INDEX.read_text())
    graph=defaultdict(list)

    for f in data:
        for t in f.get("tags",[]):
            graph[t].append(f["id"])

    return graph
