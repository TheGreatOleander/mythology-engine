import shutil
from pathlib import Path

class PiperProvider:
    name = "piper"

    def status(self):
        return {
            "provider": self.name,
            "ready": shutil.which("piper") is not None,
            "binary": shutil.which("piper"),
            "capabilities": ["tts_narration", "voice_render"]
        }

    def synthesize_stub(self, text, output_path="examples/releases/output/narration.txt"):
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text("PIPER PLACEHOLDER\n\n" + text, encoding="utf-8")
        return str(out)
