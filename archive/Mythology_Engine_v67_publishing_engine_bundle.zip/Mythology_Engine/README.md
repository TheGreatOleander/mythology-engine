# Mythology Engine v67 – Publishing Engine

Adds the publishing layer.

Pipeline now supports:

script → scenes → narration → video → title → thumbnail → publish

API Endpoint:

POST /publish-episode

Currently uses a scaffold uploader ready for YouTube API wiring.
