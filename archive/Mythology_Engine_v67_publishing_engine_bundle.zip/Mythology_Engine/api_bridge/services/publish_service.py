from publishing_engine.engines.publish_pipeline import run_publish

def publish_episode_service():
    video = "examples/publish/final_video.mp4"
    title = "The Map That Shouldn't Exist"
    description = "A mysterious ancient map may reveal a forgotten civilization."
    thumbnail = "examples/publish/thumbnail.png"

    return run_publish(video, title, description, thumbnail)
