# Publishing Engine

This module publishes completed episodes.

Current provider:
- YouTube (scaffold)

Flow:

video + title + description + thumbnail
        ↓
publish pipeline
        ↓
YouTube uploader

Endpoint:

POST /publish-episode

Future work:
- OAuth integration
- automatic scheduling
- comment monitoring
- analytics feedback loop
