from publishing_engine.engines.publish_pipeline import run_publish
import json

video = "examples/publish/final_video.mp4"
title = "The Map That Shouldn't Exist"
description = "A mysterious ancient map may reveal a forgotten civilization."
thumbnail = "examples/publish/thumbnail.png"

result = run_publish(video, title, description, thumbnail)

print(json.dumps(result, indent=2))
