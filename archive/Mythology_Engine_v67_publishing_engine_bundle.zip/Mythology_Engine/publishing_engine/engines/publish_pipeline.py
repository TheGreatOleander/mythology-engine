from publishing_engine.providers.youtube.youtube_uploader import YouTubeUploader

def run_publish(video_path, title, description, thumbnail=None):
    uploader = YouTubeUploader()
    result = uploader.upload_video(video_path, title, description, thumbnail)
    return result
