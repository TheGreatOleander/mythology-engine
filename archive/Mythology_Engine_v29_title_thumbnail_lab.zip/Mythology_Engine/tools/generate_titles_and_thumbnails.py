from title_thumbnail_lab.title_engine import generate_titles
from title_thumbnail_lab.thumbnail_engine import generate_thumbnail_concepts
import json

topic=input("Topic: ").strip()

titles=generate_titles(topic)
thumbs=generate_thumbnail_concepts(topic)

print("\n--- TITLE OPTIONS ---\n")
for t in titles:
    print("-",t)

print("\n--- THUMBNAIL CONCEPTS ---\n")
print(json.dumps(thumbs,indent=2))
