# Title & Thumbnail Laboratory

This module generates candidate titles and thumbnail concepts.

Purpose:
Increase click-through-rate (CTR) by testing multiple headline angles.

Outputs:
- title variations
- thumbnail text concepts
- visual style hints

Run:

python tools/generate_titles_and_thumbnails.py
