# Mythology Engine v8

Mythology Engine v8 is a human-reviewed, AI-assisted narrative production framework
for documentary-style mystery channels.

This build adds the **single most important growth feature** for this format:

## Packaging multiple hook / title / thumbnail variants for every episode

That feature matters because most channels do not fail at topic selection.
They fail at the *first impression*.

A great script with a weak title and dull thumbnail dies quietly.
A strong episode package with multiple curiosity-first variants has a far better shot.

---

## New in v8

- variant pack generator
- topic scoring
- novelty filter against recent episode history
- metadata package generation
- stronger review bundle
- batch generation support
- subtitle generation
- FFmpeg render command generation
- documentation upgraded again

---

## Core pipeline

topic discovery
→ topic scoring
→ novelty filter
→ hook variants
→ title variants
→ thumbnail prompt variants
→ script generation
→ narration placeholder
→ render command
→ subtitles
→ review package
→ optional upload stub
→ analytics scaffold
→ mythology update

---

## Run

Generate one episode package:

```bash
python -m scheduler.daily_run
```

Generate multiple:

```bash
python -m scheduler.batch_run 5
```

Every episode lands in `episodes/EP_*`.

---

## Why variant packs matter

For this content format, the biggest multiplier is not just “more videos.”
It is:

- better hooks
- better titles
- better thumbnails
- better first-click conversion

That is why v8 now generates:
- 3 title variants
- 3 hook variants
- 3 thumbnail prompt variants

The operator can pick the strongest package before upload.
