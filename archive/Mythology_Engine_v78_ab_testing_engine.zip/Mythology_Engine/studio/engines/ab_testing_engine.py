from optimization.ab_testing_engine.ab_test_manager import create_test, evaluate_latest

def create_ab_test(topic="ancient map discovery"):
    return create_test(topic)

def evaluate_ab_test():
    return evaluate_latest()
