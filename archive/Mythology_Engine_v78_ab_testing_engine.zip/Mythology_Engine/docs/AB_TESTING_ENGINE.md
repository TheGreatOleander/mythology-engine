# A/B Testing Engine

Allows Mythology Engine to test multiple title + thumbnail combinations.

API:

POST /ab-test
GET /ab-test-result

The engine simulates CTR results for variants and selects the best.
