import urllib.request, json

BASE="http://127.0.0.1:8765"

def call(path,method="GET"):
    req = urllib.request.Request(BASE+path,method=method)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())

print("Create test:", call("/ab-test","POST"))
print("Best result:", call("/ab-test-result"))
