# Mythology Engine v78 – A/B Testing Engine

Adds an optimization layer for YouTube growth.

Features:

- Generate title + thumbnail variants
- Simulate CTR results
- Select winning combination

Endpoints:

POST /ab-test
GET /ab-test-result

Start:

python tools/start_api.py
