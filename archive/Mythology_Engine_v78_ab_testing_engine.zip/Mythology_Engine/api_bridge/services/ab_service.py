from studio.engines.ab_testing_engine import create_ab_test, evaluate_ab_test

def create_test_service():
    return create_ab_test()

def evaluate_test_service():
    return evaluate_ab_test()
