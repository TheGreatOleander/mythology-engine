import random

def score_title(title):
    score = random.randint(5,10)
    if "Secret" in title:
        score += 2
    if "Truth" in title:
        score += 2
    if "Shouldn't Exist" in title:
        score += 3
    return score

def score_thumbnail(prompt):
    score = random.randint(5,10)
    if "cinematic" in prompt:
        score += 2
    if "dramatic" in prompt:
        score += 2
    return score
