import json, datetime, random
from pathlib import Path
from optimization.title_engine.title_generator import generate_titles
from optimization.thumbnail_engine.thumbnail_prompts import generate_thumbnail_prompts
from optimization.scoring_engine.scorer import score_title, score_thumbnail

STORE = Path("examples/ab_tests/tests.json")

def load():
    if STORE.exists():
        return json.loads(STORE.read_text())
    return []

def save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(data, indent=2))

def create_test(topic):

    titles = generate_titles(topic)
    thumbs = generate_thumbnail_prompts(topic)

    variants = []

    for t in titles[:3]:
        for th in thumbs[:2]:
            variants.append({
                "title": t,
                "thumbnail_prompt": th,
                "ctr_simulated": round(random.uniform(0.02,0.15),3)
            })

    test = {
        "test_id": datetime.datetime.utcnow().strftime("AB_%Y%m%d_%H%M%S"),
        "topic": topic,
        "variants": variants
    }

    tests = load()
    tests.append(test)
    save(tests)

    return test

def evaluate_latest():

    tests = load()
    if not tests:
        return {"error":"no_tests"}

    test = tests[-1]

    best = sorted(
        test["variants"],
        key=lambda x: x["ctr_simulated"],
        reverse=True
    )[0]

    return {
        "test_id": test["test_id"],
        "best_variant": best,
        "variants": test["variants"]
    }
