# First Live Wiring Bundle

This bundle is the first practical step from architecture into usable provider execution.

## What it does

It wires three concrete provider attachment points into one runtime flow:

- FFmpeg provider
- SDXL provider
- Piper provider

## Current behavior

The bundle still uses stub outputs, but it now runs through a real provider registry
and produces a coherent runtime output directory.

## Why this is the right next move

This is the lowest-risk path from:
- fully defined architecture

to:
- testable runtime behavior

without hard-coding one-off hacks everywhere.
