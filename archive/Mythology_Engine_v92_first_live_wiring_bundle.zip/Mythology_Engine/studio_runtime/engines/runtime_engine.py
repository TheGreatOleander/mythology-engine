from pathlib import Path
from providers.core.provider_registry import ProviderRegistry
from providers.config.runtime_settings import load_settings

def run_runtime_demo():
    settings = load_settings()
    outdir = Path(settings["output_dir"])
    outdir.mkdir(parents=True, exist_ok=True)

    registry = ProviderRegistry()

    script = """TITLE: The Map That Shouldn't Exist

## HOOK
This map may not be possible.

## STORY
A forgotten document hints at a lost route beneath history.
"""

    scene1 = registry.image.generate_stub_image(
        "ancient map glowing under torchlight cinematic",
        str(outdir / "scene_001.txt")
    )
    scene2 = registry.image.generate_stub_image(
        "dusty archive table with impossible map markings",
        str(outdir / "scene_002.txt")
    )
    audio = registry.audio.generate_stub_audio(
        script,
        str(outdir / "narration.txt")
    )
    video_plan = registry.video.assemble_stub(
        [scene1, scene2],
        audio,
        str(outdir / "final_video_plan.txt")
    )

    return {
        "provider_status": registry.status(),
        "outputs": {
            "scene_1": scene1,
            "scene_2": scene2,
            "audio": audio,
            "video_plan": video_plan
        }
    }
