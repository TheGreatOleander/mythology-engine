from studio_runtime.engines.runtime_engine import run_runtime_demo
import json

print(json.dumps(run_runtime_demo(), indent=2))
