# Mythology Engine v92 – First Live Wiring Bundle

This version is the first practical provider-runtime integration step.

## Included

- FFmpeg provider
- SDXL provider
- Piper provider
- runtime settings loader
- provider registry
- runtime demo engine

## Run

python studio_runtime/tools/demo_runtime.py

## Output

Creates a runtime output folder with:

- scene stub files
- narration stub file
- final video assembly plan

This is the bridge from abstract architecture to a real execution path.
