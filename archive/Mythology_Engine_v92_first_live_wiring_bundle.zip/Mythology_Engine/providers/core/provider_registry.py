from providers.video.ffmpeg_provider import FFmpegProvider
from providers.image.sdxl_provider import SDXLProvider
from providers.audio.piper_provider import PiperProvider

class ProviderRegistry:
    def __init__(self):
        self.video = FFmpegProvider()
        self.image = SDXLProvider()
        self.audio = PiperProvider()

    def status(self):
        return {
            "video": self.video.status(),
            "image": self.image.status(),
            "audio": self.audio.status()
        }
