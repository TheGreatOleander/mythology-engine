from providers.core.provider_base import ProviderBase
from pathlib import Path
import shutil

class FFmpegProvider(ProviderBase):
    provider_name = "ffmpeg"
    provider_type = "video"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": shutil.which("ffmpeg") is not None,
            "binary": shutil.which("ffmpeg"),
            "capabilities": ["assemble_video", "transcode", "vertical_reformat", "caption_burn_in"]
        }

    def assemble_stub(self, rendered_scene_paths, audio_path, output_path):
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_path).write_text(
            "FFMPEG ASSEMBLY PLAN\n"
            + f"audio={audio_path}\n"
            + "\n".join(f"scene={p}" for p in rendered_scene_paths),
            encoding="utf-8"
        )
        return output_path
