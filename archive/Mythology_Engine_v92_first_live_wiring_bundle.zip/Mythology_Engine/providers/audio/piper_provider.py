from providers.core.provider_base import ProviderBase
from pathlib import Path

class PiperProvider(ProviderBase):
    provider_name = "piper"
    provider_type = "audio"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": ["tts_voice_generation", "narration_render"],
            "note": "Wire to Piper or another TTS runtime."
        }

    def generate_stub_audio(self, script_text, output_path):
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_path).write_text(
            "PIPER STUB AUDIO\n\n" + script_text,
            encoding="utf-8"
        )
        return output_path
