import json
from pathlib import Path

DEFAULTS = {
    "video_provider": "ffmpeg",
    "image_provider": "sdxl",
    "audio_provider": "piper",
    "output_dir": "examples/runtime/output"
}

def load_settings():
    path = Path("examples/runtime/runtime_config.json")
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        merged = DEFAULTS.copy()
        merged.update(data)
        return merged
    return DEFAULTS.copy()
