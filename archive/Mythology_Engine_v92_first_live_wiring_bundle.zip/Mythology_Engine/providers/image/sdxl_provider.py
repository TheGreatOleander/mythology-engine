from providers.core.provider_base import ProviderBase
from pathlib import Path

class SDXLProvider(ProviderBase):
    provider_name = "sdxl"
    provider_type = "image"

    def status(self):
        return {
            "provider_name": self.provider_name,
            "provider_type": self.provider_type,
            "ready": False,
            "capabilities": ["thumbnail_generation", "scene_concept_art", "cover_art"],
            "note": "Wire to local SDXL or hosted image API."
        }

    def generate_stub_image(self, prompt, output_path):
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_path).write_text(
            f"SDXL STUB IMAGE\nprompt={prompt}\n",
            encoding="utf-8"
        )
        return output_path
