package com.mythology.missioncontrol

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object LocalApiClient {

    private fun baseUrl(context: Context): String {
        val prefs = context.getSharedPreferences("bridge_settings", Context.MODE_PRIVATE)
        return prefs.getString("base_url", "http://127.0.0.1:8765")!!
    }

    fun get(context: Context, path: String): String {
        val url = URL(baseUrl(context) + path)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        return connection.inputStream.use { input ->
            BufferedReader(InputStreamReader(input)).readText()
        }
    }

    fun post(context: Context, path: String): String {
        val url = URL(baseUrl(context) + path)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        return connection.inputStream.use { input ->
            BufferedReader(InputStreamReader(input)).readText()
        }
    }
}
