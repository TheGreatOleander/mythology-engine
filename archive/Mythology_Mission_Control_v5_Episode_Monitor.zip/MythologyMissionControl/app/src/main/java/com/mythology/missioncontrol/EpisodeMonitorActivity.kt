package com.mythology.missioncontrol

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class EpisodeMonitorActivity : AppCompatActivity() {

    private lateinit var txtMonitor: TextView
    private lateinit var txtMonitorStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_episode_monitor)

        txtMonitor = findViewById(R.id.txtMonitor)
        txtMonitorStatus = findViewById(R.id.txtMonitorStatus)

        txtMonitorStatus.text = "Loading pipeline..."
        loadPipeline()
    }

    private fun loadPipeline() {
        thread {
            try {
                // Expected future endpoint from the engine:
                // GET /pipeline-status
                val result = LocalApiClient.get(this, "/pipeline-status")
                runOnUiThread {
                    txtMonitorStatus.text = "Pipeline loaded"
                    txtMonitor.text = result
                }
            } catch (e: Exception) {
                runOnUiThread {
                    txtMonitorStatus.text = "Using demo pipeline data"
                    txtMonitor.text = demoPipeline()
                }
            }
        }
    }

    private fun demoPipeline(): String {
        return """
EP_20260310_000001  SCRIPTED
EP_20260310_000002  ASSETS_GENERATED
EP_20260310_000003  READY_TO_PUBLISH
EP_20260310_000004  ANALYZED
""".trimIndent()
    }
}
