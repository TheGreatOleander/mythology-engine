# Mythology Mission Control v5

Android Studio project scaffold with:

- Local API bridge support
- Bridge settings screen
- Episode monitor screen

## New in v5

Added an Episode Monitor activity so Mission Control starts behaving like a real
production dashboard instead of just a command pad.

## Expected future endpoint

The monitor tries to call:

`GET /pipeline-status`

If unavailable, it falls back to demo pipeline data so the screen is still useful
during development.

## Required backend

Run the local API bridge from Mythology Engine:

`python tools/start_local_api_bridge.py`

Then configure the bridge URL in the app settings if needed.
