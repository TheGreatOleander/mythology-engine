from continuity_engine.engines.continuity_engine import ContinuityEngine

engine = ContinuityEngine()

script = "Researchers recently uncovered a map that challenges known exploration routes."

context = engine.build_context("map")

updated_script = engine.inject_into_script(script, context)

print(updated_script)
