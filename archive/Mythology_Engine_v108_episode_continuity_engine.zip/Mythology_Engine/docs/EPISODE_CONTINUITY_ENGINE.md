# Episode Continuity Engine

This module connects new episode topics to previously recorded lore.

## Purpose

Automatically detect connections between:

- new topics
- previously discovered artifacts
- locations or symbols in earlier episodes

## Result

Scripts can reference previous discoveries, creating a living narrative universe.
