import json
from pathlib import Path
from continuity_engine.models.continuity_context import ContinuityContext

class ContinuityEngine:

    def __init__(self, lore_path="examples/lore_database.json"):
        self.lore_path = Path(lore_path)

    def load_lore(self):
        if not self.lore_path.exists():
            return []
        return json.loads(self.lore_path.read_text())

    def build_context(self, topic):

        lore = self.load_lore()

        related = []
        for item in lore:
            if topic.lower() in item.get("description","").lower():
                related.append(item)

        return ContinuityContext(topic, related)

    def inject_into_script(self, script, context):

        if not context.related_lore:
            return script

        references = []
        for item in context.related_lore:
            references.append(
                f"This may relate to the artifact known as '{item['name']}' discovered earlier."
            )

        reference_block = "\n".join(references)

        return script + "\n\nPossible connections:\n" + reference_block
