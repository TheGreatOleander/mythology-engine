class ContinuityContext:

    def __init__(self, topic, related_lore=None):
        self.topic = topic
        self.related_lore = related_lore or []

    def to_dict(self):
        return {
            "topic": self.topic,
            "related_lore": self.related_lore
        }
