# Mythology Engine v108 – Episode Continuity Engine

This module connects new episode scripts with previously recorded lore.

## Run

python runtime/tools/demo_continuity_engine.py

## Output

A script enriched with references to earlier myth elements.
