class PipelineRecord:
    def __init__(self, episode_id, topic, state):
        self.episode_id = episode_id
        self.topic = topic
        self.state = state

    def to_dict(self):
        return {
            "episode_id": self.episode_id,
            "topic": self.topic,
            "state": self.state
        }
