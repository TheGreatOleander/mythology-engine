import json
from pathlib import Path

STORE = Path("examples/pipeline.json")

def load_records():
    if STORE.exists():
        return json.loads(STORE.read_text())
    return []

def summarize(records):
    summary = {}
    for r in records:
        state = r.get("state","UNKNOWN")
        summary.setdefault(state,0)
        summary[state]+=1
    return summary
