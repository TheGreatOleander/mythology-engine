import datetime, json
from pathlib import Path

def run_factory():
    out = Path("examples/pipeline.json")
    out.parent.mkdir(exist_ok=True)

    data = []
    if out.exists():
        data = json.loads(out.read_text())

    stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    rec = {
        "episode_id": f"EP_{stamp}",
        "topic": "Ancient Map Discovery",
        "state": "SCRIPTED"
    }
    data.append(rec)

    out.write_text(json.dumps(data, indent=2))
    return rec
