# Pipeline Status Endpoint

This version adds a real endpoint used by the Android Episode Monitor.

GET /pipeline-status

Returns:

{
  "records":[...],
  "summary":{
     "SCRIPTED":1,
     "READY_TO_PUBLISH":1
  }
}

Mission Control Android v5 can now display real pipeline data.
