from episode_factory.factory import run_factory
from pipeline_manager.engines.pipeline_store import load_records, summarize

def generate_episode_service():
    return run_factory()

def pipeline_status_service():
    records = load_records()
    return {
        "records": records,
        "summary": summarize(records)
    }

def health_service():
    return {
        "status":"ok",
        "service":"mythology_engine_local_bridge"
    }
