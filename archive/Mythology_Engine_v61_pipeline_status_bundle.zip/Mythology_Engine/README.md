# Mythology Engine v61 – Pipeline Status

This version adds the backend endpoint required by the Android Episode Monitor.

Endpoint:

GET /pipeline-status

Also supports:

GET /health
POST /generate-episode

Run server:

python tools/start_api.py
