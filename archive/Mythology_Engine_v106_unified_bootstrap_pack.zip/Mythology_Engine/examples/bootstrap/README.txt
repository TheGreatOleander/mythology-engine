This folder exists as a placeholder for bootstrap demo output references.
