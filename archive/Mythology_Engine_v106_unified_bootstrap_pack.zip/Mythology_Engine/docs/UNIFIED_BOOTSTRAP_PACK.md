# Unified Bootstrap Pack

This module ties together the practical startup layers of Mythology Engine.

## Included

- environment checks
- runtime path creation
- provider readiness checks
- initial config bundle generation
- Termux helper scripts

## Why it matters

This is the clean on-ramp for real usage.

It combines the earlier ideas of:
- Termux compatibility
- first-run setup
- runtime path policy
- provider checks

into one repeatable bootstrap flow.
