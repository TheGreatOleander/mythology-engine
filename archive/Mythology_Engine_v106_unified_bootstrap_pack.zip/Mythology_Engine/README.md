# Mythology Engine v106 – Unified Bootstrap Pack

This version creates a single startup/bootstrap layer for the studio.

## Run

python bootstrap/tools/run_bootstrap.py

## Optional Termux setup

bash bootstrap/scripts/setup_termux.sh

## What it does

- checks environment
- creates runtime folders
- checks basic provider readiness
- writes initial config bundle

## Goal

Make Mythology Engine easier to bring up cleanly on Android Termux or desktop-like Python environments.
