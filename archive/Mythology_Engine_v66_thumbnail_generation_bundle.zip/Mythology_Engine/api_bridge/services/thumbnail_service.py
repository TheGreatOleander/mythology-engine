from thumbnail_engine.generators.simple_thumbnail_generator import SimpleThumbnailGenerator

generator = SimpleThumbnailGenerator()

def generate_thumbnail_service():
    title = "The Map That Shouldn't Exist"
    prompt = "dramatic glowing ancient map under torchlight documentary thumbnail"
    path = generator.generate(title, prompt)
    return {
        "title": title,
        "prompt": prompt,
        "thumbnail_file": path
    }
