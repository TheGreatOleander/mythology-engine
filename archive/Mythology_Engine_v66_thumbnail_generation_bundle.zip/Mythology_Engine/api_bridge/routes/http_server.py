from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from api_bridge.services.thumbnail_service import generate_thumbnail_service

class Handler(BaseHTTPRequestHandler):

    def send_json(self, data, code=200):
        body = json.dumps(data, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path == "/generate-thumbnail":
            self.send_json(generate_thumbnail_service())
        else:
            self.send_json({"error":"not_found","path":self.path},404)

def run_server(host="127.0.0.1",port=8765):
    s=HTTPServer((host,port),Handler)
    print(f"Mythology Thumbnail API running http://{host}:{port}")
    s.serve_forever()

if __name__ == "__main__":
    run_server()
