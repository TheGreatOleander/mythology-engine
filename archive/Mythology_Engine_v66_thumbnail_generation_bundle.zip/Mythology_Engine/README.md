# Mythology Engine v66 – Thumbnail Generation

Adds thumbnail generation capability.

New API endpoint:

POST /generate-thumbnail

Purpose:

Convert title + visual prompt into a thumbnail asset
for use during publishing.
