from thumbnail_engine.generators.simple_thumbnail_generator import SimpleThumbnailGenerator

generator = SimpleThumbnailGenerator()

title = "The Map That Shouldn't Exist"
prompt = "dramatic glowing ancient map under torchlight documentary thumbnail"

result = generator.generate(title, prompt)

print({
    "thumbnail_file": result,
    "title": title,
    "prompt": prompt
})
