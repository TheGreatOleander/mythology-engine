from pathlib import Path
import datetime

class SimpleThumbnailGenerator:

    def generate(self, title, prompt, output_dir="examples/thumbnails"):
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        stamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        file = Path(output_dir) / f"thumb_{stamp}.txt"

        # Stub placeholder representing generated image
        file.write_text(
            f"THUMBNAIL STUB\nTITLE: {title}\nPROMPT: {prompt}\n",
            encoding="utf-8"
        )

        return str(file)
