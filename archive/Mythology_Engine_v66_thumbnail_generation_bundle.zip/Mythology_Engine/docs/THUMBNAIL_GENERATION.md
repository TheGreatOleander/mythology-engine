# Thumbnail Generation Engine

This module produces thumbnails for episodes.

Currently uses a stub generator but is designed to plug into:

- Stable Diffusion
- DALL·E
- Midjourney
- SDXL local pipelines

Endpoint:

POST /generate-thumbnail

Returns a generated thumbnail file path plus title/prompt metadata.
