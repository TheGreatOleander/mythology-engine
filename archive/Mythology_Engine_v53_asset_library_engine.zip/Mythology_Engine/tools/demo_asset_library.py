from asset_library.engines.library_indexer import index_assets
from asset_library.engines.asset_selector import choose_asset
import json

assets=index_assets()

print("Indexed assets:",len(assets))

choice=choose_asset(assets,"maps")

print("Random map asset:")
print(json.dumps(choice,indent=2))
