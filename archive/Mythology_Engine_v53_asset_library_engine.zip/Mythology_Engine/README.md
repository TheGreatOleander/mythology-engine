Mythology Engine v53 – Asset Library Engine

Adds reusable asset collections.

Categories include:

maps
textures
overlays
sound effects

Run demo:

python tools/demo_asset_library.py
