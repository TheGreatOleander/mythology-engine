class Asset:
    def __init__(self, name, path, category):
        self.name = name
        self.path = path
        self.category = category

    def to_dict(self):
        return {
            "name": self.name,
            "path": self.path,
            "category": self.category
        }
