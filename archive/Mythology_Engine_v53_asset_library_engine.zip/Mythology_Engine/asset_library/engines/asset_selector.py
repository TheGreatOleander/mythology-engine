import random

def choose_asset(assets, category):

    filtered=[a for a in assets if a["category"]==category]

    if not filtered:
        return None

    return random.choice(filtered)
