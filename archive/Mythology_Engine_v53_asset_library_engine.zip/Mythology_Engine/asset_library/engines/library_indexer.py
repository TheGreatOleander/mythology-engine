import pathlib, json

def index_assets(base="asset_library/assets"):

    assets=[]
    base_path=pathlib.Path(base)

    for p in base_path.rglob("*"):
        if p.is_file():
            assets.append({
                "name":p.stem,
                "path":str(p),
                "category":p.parent.name
            })

    return assets
