Asset Library Engine

Maintains reusable visual and audio resources.

Examples:
- parchment textures
- antique maps
- occult symbols
- cinematic overlays
- sound effects

Advantages:

• avoids regenerating images every episode
• improves visual consistency
• enables higher production quality
