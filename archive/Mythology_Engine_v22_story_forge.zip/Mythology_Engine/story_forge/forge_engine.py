import json
import random
from pathlib import Path

INDEX = Path("story_library/storage/index.json")

def load_fragments():
    if not INDEX.exists():
        return []
    return json.loads(INDEX.read_text())

def build_episode_idea():
    frags = load_fragments()
    if len(frags) < 2:
        return "Not enough fragments in library."

    picks = random.sample(frags, min(3, len(frags)))
    texts = []

    for p in picks:
        path = Path(p["file"])
        if path.exists():
            texts.append(path.read_text().strip())

    idea = "\n\n".join(texts)

    outline = f"""
EPISODE CONCEPT

Hook:
A strange convergence of stories suggests a hidden pattern.

Fragments:
{idea}

Narrative Direction:
Explore how these fragments connect and reveal a larger mystery.
"""

    return outline
