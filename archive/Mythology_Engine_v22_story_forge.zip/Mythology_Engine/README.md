# Mythology Engine – Story Forge

Adds a Story Forge module that turns stored story fragments into
new episode ideas.
