from story_forge.forge_engine import build_episode_idea

if __name__ == "__main__":
    idea = build_episode_idea()
    print("\n--- GENERATED EPISODE IDEA ---\n")
    print(idea)
