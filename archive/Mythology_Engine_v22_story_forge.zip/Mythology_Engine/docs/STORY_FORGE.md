# Story Forge

The Story Forge assembles episode ideas from fragments in the story library.

Run:

python tools/forge_episode_idea.py
