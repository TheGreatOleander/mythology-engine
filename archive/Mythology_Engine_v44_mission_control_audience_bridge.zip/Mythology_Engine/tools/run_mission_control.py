from mission_control.control_center import MissionControl
import json

mc = MissionControl()

print("Generating episode...")
episode = mc.generate_episode()

print("Checking audience...")
audience = mc.check_audience()

print(json.dumps({
    "episode": episode,
    "audience_replies": audience
}, indent=2))
