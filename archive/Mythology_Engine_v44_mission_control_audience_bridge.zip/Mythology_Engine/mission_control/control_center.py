from episode_factory.factory import run_factory
from audience_interface.comment_responder import respond_to_comments

class MissionControl:

    def generate_episode(self):
        result = run_factory(queue_for_publish=False)
        return result

    def generate_and_queue(self):
        result = run_factory(queue_for_publish=True)
        return result

    def check_audience(self):
        responses = respond_to_comments()
        return responses
