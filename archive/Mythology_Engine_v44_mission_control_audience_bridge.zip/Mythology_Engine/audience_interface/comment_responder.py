from audience_interface.providers.youtube.youtube_comment_provider import YouTubeCommentProvider

def respond_to_comments():
    provider = YouTubeCommentProvider()

    comments = provider.fetch_recent_comments()

    responses = []

    for c in comments:
        text = c["text"]
        reply = build_reply(text)
        responses.append({
            "comment": text,
            "reply": reply
        })

    return responses


def build_reply(text):
    # Placeholder logic — later this will route through writing provider
    return f"Thanks for watching! Your comment about '{text[:30]}' is appreciated."
