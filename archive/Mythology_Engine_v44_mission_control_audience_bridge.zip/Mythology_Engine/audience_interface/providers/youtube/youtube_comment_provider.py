class YouTubeCommentProvider:

    def fetch_recent_comments(self):
        # Stub data until real YouTube API wiring
        return [
            {"author": "viewer1", "text": "This mystery map episode was incredible"},
            {"author": "viewer2", "text": "Are you going to cover Oak Island next?"}
        ]
