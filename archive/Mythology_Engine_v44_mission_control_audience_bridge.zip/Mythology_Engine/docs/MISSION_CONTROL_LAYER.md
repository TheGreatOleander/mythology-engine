# Mission Control Layer

Mission Control is the operational command interface for Mythology Engine.

Responsibilities:

- Trigger episode generation
- Queue episodes for publishing
- Check audience interaction
- Route actions to the correct engines

This layer is designed to be connected to:

- Android Mission Control App
- CLI automation
- Web dashboard
