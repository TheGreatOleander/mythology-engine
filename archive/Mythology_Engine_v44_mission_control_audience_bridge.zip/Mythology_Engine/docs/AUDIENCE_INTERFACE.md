# Audience Interface

Handles:

- comment retrieval
- fan mail
- reply suggestions

Current version contains a YouTube provider stub.

Future work:

- YouTube API integration
- provider registry support
- tone control for replies
