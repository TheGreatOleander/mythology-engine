# Mythology Engine – Lore Graph

Adds a Lore Graph module that discovers relationships between fragments
in the story library.

This allows the system to detect hidden narrative constellations that
can inspire deeper stories.
