from strategy_engine.strategy_provider import get_strategy
from learning_engine.engines.performance_analyzer import analyze_latest_performance
from autonomous_loop.engines.production_loop import run_production_loop

def run_flywheel_cycle(previous_recommendation=None):
    strategy = get_strategy(previous_recommendation=previous_recommendation)
    production = run_production_loop(strategy["topic"], strategy["episodes"])
    learning = analyze_latest_performance()

    next_strategy_preview = get_strategy(previous_recommendation=learning["recommended_topic"])

    return {
        "strategy_used": strategy,
        "production_result": production,
        "learning_result": learning,
        "next_cycle_preview": next_strategy_preview
    }
