class FlywheelState:
    def __init__(self, current_topic=None, recommended_topic=None, loop_count=0):
        self.current_topic = current_topic
        self.recommended_topic = recommended_topic
        self.loop_count = loop_count

    def to_dict(self):
        return {
            "current_topic": self.current_topic,
            "recommended_topic": self.recommended_topic,
            "loop_count": self.loop_count
        }
