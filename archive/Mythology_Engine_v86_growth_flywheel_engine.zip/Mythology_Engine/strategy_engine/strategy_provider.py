def get_strategy(previous_recommendation=None):
    base_topics = [
        "oak island treasure mystery",
        "ancient map discovery",
        "ark of the covenant location",
        "atlantis evidence",
        "lost roman map discovery"
    ]
    if previous_recommendation:
        return {
            "topic": previous_recommendation,
            "reason": "Using learning engine recommendation from prior cycle.",
            "episodes": 3,
            "cadence_days": 2
        }
    return {
        "topic": base_topics[0],
        "reason": "Default strategic seed topic.",
        "episodes": 3,
        "cadence_days": 2
    }
