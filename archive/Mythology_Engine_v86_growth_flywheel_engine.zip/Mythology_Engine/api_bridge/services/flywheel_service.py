from growth_flywheel.engines.flywheel_engine import run_flywheel_cycle

def flywheel_service():
    return run_flywheel_cycle()
