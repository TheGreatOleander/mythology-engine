from learning_engine.providers.metrics_provider import get_latest_metrics

def analyze_latest_performance():
    metrics = get_latest_metrics()
    best = sorted(
        metrics,
        key=lambda m: (m["views"] * 0.5) + (m["ctr"] * 100 * 0.2) + (m["watch_time"] * 1000 * 0.3),
        reverse=True
    )[0]
    return {
        "metrics": metrics,
        "recommended_topic": best["topic"],
        "best_title": best["title"],
        "reason": "Highest weighted combination of views, CTR, and watch time."
    }
