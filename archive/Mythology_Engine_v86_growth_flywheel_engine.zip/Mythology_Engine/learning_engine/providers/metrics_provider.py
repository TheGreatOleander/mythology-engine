def get_latest_metrics():
    return [
        {"title": "Oak Island treasure mystery – Part 1", "topic": "oak island treasure mystery", "views": 15000, "ctr": 8.2, "watch_time": 5.1},
        {"title": "Ancient map discovery – Part 1", "topic": "ancient map discovery", "views": 12000, "ctr": 7.4, "watch_time": 4.7},
        {"title": "Atlantis evidence – Part 1", "topic": "atlantis evidence", "views": 8400, "ctr": 5.8, "watch_time": 3.9}
    ]
