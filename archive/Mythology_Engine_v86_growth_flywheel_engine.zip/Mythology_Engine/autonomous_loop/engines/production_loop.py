def run_production_loop(topic, episodes=3):
    results = []
    for i in range(episodes):
        title = f"{topic} – Part {i+1}"
        results.append({
            "episode_number": i + 1,
            "title": title,
            "video_file": f"rendered/{topic.replace(' ', '_')}_{i+1}.mp4",
            "publish_status": "published_simulated"
        })
    return {
        "topic": topic,
        "episodes_processed": len(results),
        "results": results
    }
