import urllib.request, json

BASE = "http://127.0.0.1:8765"
req = urllib.request.Request(BASE + "/run-flywheel", method="POST")

with urllib.request.urlopen(req) as r:
    print(json.dumps(json.loads(r.read().decode()), indent=2))
