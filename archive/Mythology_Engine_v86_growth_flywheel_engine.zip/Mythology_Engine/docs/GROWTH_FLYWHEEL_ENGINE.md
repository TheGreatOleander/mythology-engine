# Growth Flywheel Engine

This module closes the studio loop by connecting:

strategy
→ production
→ performance analysis
→ next strategy preview

## Endpoint

POST /run-flywheel

## What it returns

- strategy used in the current cycle
- production results
- learning results
- recommended topic for the next cycle

## Why it matters

This moves Mythology Engine from:
- a one-shot content machine

to:
- a self-improving growth loop
