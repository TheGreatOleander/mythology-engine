# Mythology Engine v86 – Growth Flywheel Engine

Adds the closed-loop growth engine.

## Endpoint

POST /run-flywheel

## Flow

strategy
→ produce
→ publish (simulated)
→ measure
→ learn
→ adapt next strategy

## Start

python tools/start_api.py
