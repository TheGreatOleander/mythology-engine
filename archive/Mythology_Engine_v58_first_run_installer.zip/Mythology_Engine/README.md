# Mythology Engine v58 – First-Run Installer

This version adds a real first-run setup flow.

## Run

`python tools/first_run_install.py`

## It creates

- `secrets/local_secrets.json`
- `config/runtime_config.json`
- `.gitignore`

## Why this matters

This is a key step toward turning the project from a developer bundle into
something a real user can install and configure.
