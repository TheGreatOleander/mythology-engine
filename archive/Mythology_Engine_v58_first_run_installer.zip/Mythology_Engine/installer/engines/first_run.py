from installer.engines.questions import SETUP_QUESTIONS
from installer.engines.config_writer import write_local_secrets, write_runtime_config, write_gitignore

def run_first_run_installer():
    print("\n====================================")
    print("MYTHOLOGY ENGINE – FIRST RUN INSTALLER")
    print("====================================\n")
    print("This will create local configuration files for your install.")
    print("Secrets stay local and should not be committed to git.\n")

    answers = {}

    for q in SETUP_QUESTIONS:
        default = q.get("default", "")
        raw = input(f'{q["prompt"]} [{default}]: ').strip()
        if raw == "":
            raw = default
        answers[q["key"]] = raw

    secrets_path = write_local_secrets(answers)
    config_path = write_runtime_config(answers)
    gitignore_path = write_gitignore()

    print("\nSetup complete.")
    print("Secrets:", secrets_path)
    print("Runtime config:", config_path)
    print("Gitignore:", gitignore_path)

    return {
        "secrets_path": secrets_path,
        "config_path": config_path,
        "gitignore_path": gitignore_path,
        "answers": answers
    }
