import json
from pathlib import Path

def write_local_secrets(data: dict) -> str:
    path = Path("secrets/local_secrets.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(path)

def write_runtime_config(data: dict) -> str:
    config = {
        "channel_name": data.get("channel_name", "The Hidden Archive"),
        "primary_platform": data.get("primary_platform", "youtube"),
        "output_dir": data.get("output_dir", "episodes"),
        "providers": {
            "writing": data.get("writing_provider", "openai"),
            "tts": data.get("tts_provider", "piper"),
            "image": data.get("image_provider", "sdxl"),
            "publish": data.get("publish_provider", "manual")
        }
    }
    path = Path("config/runtime_config.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return str(path)

def write_gitignore() -> str:
    path = Path(".gitignore")
    lines = []
    if path.exists():
        lines = path.read_text(encoding="utf-8").splitlines()

    required = [
        "secrets/local_secrets.json",
        "secrets/client_secret.json",
        "secrets/oauth_token.json",
        "__pycache__/",
        "*.pyc",
        "episodes/",
        "publish_queue/"
    ]

    merged = lines[:]
    for item in required:
        if item not in merged:
            merged.append(item)

    path.write_text("\n".join(merged).strip() + "\n", encoding="utf-8")
    return str(path)
