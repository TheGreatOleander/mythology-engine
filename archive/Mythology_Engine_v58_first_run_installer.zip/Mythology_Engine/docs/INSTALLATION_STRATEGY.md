# Installation Strategy

The product should be easy to clone and configure.

## Public repo pattern

Ship:
- source code
- examples
- installer
- docs

Do not ship:
- live API keys
- live OAuth tokens

## First-run flow

1. clone repo
2. run installer
3. create local secrets and config
4. test providers
5. begin generating episodes

This is the right balance between public distribution and private credentials.
