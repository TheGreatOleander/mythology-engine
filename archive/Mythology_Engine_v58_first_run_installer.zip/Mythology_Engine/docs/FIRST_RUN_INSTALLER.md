# First-Run Installer

This module makes Mythology Engine much easier to set up.

## What it asks for

- channel name
- contact email
- output directory
- writing provider
- TTS provider
- image provider
- publish provider
- primary platform
- YouTube OAuth paths
- API keys

## What it writes

- `secrets/local_secrets.json`
- `config/runtime_config.json`
- `.gitignore`

## Run

`python tools/first_run_install.py`

## Why it matters

This is the first step toward making the project installable by other people
without hand-editing source code.
