import sys
from core.episode_runner import run_episode

def batch(n):
    for _ in range(n):
        m=run_episode()
        print("Generated:",m["episode_id"])

if __name__=="__main__":
    n=int(sys.argv[1]) if len(sys.argv)>1 else 3
    batch(n)
