from pathlib import Path

def synthesize(script,out:Path):
    out.write_text("placeholder narration")
    return str(out)
