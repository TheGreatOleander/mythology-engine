def generate_subtitles(script,out):
    out.write_text("1\n00:00:00,000 --> 00:00:05,000\nPlaceholder subtitle")
