from pathlib import Path
import datetime, json

from discovery.topic_discovery import get_topic
from story.script_builder import build_script
from story.title_optimizer import optimize_title
from media.narration import synthesize
from media.subtitle_generator import generate_subtitles
from media.video_assembler import render_video
from publishing.review_queue import write_review

def run_episode():

    topic=get_topic()
    title=optimize_title(topic)
    script=build_script(topic)

    eid=datetime.datetime.utcnow().strftime("EP_%Y%m%d_%H%M%S")
    epdir=Path("episodes")/eid
    epdir.mkdir(parents=True,exist_ok=True)

    script_file=epdir/"script.txt"
    script_file.write_text(script)

    audio=synthesize(script,epdir/"narration.wav")

    video=render_video(audio,epdir/"video.mp4")

    generate_subtitles(script,epdir/"subtitles.srt")

    manifest={
        "episode_id":eid,
        "topic":topic,
        "title":title,
        "script":str(script_file),
        "audio":str(audio),
        "video":str(video)
    }

    (epdir/"manifest.json").write_text(json.dumps(manifest,indent=2))

    write_review(epdir,manifest)

    return manifest
