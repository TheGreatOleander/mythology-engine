def build_script(topic):

    return f'''
TITLE
{topic.upper()}

HOOK
Some discoveries refuse to stay buried.

BACKGROUND
Researchers examining {topic} noticed patterns that should not exist.

DISCOVERY
Each investigation uncovered contradictions in accepted explanations.

TWIST
The artifact may be part of a much larger unknown system.

CLOSING QUESTION
If {topic} is not isolated, what else belongs to the same hidden pattern?
'''
