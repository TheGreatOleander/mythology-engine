from story.title_optimizer import optimize_title

def test_title():
    assert "Mystery" in optimize_title("test artifact")
