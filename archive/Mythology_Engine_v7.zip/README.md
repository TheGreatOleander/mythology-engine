# Mythology Engine v7

Mythology Engine v7 is an **automated narrative production framework** designed to help operate
a documentary‑style mystery YouTube channel.

This version moves the system closer to a real production tool by introducing:

• batch episode generation  
• optional draft upload workflow  
• subtitle generation  
• FFmpeg render pipeline hooks  
• stronger documentation  
• example media pipeline structure  
• analytics feedback scaffolding  

The system is intentionally designed around **human review before publishing**.

---

## Core Pipeline

topic discovery
→ episode planning
→ script generation
→ narration synthesis
→ thumbnail generation
→ video render pipeline
→ subtitle generation
→ review package
→ optional draft upload
→ analytics ingestion
→ mythology memory update

---

## Running the engine

Create environment:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Generate an episode:

```bash
python -m scheduler.daily_run
```

Generate multiple episodes:

```bash
python -m scheduler.batch_run 5
```

Generated content appears in:

```
episodes/
   EP_*
```

Each episode folder contains:

- script.txt
- narration.wav
- subtitles.srt
- manifest.json
- REVIEW.txt
