import random

TOPICS=[
"the Voynich Manuscript",
"the Antikythera Mechanism",
"the Baghdad Battery",
"a lost polar expedition",
"a forbidden monastery archive",
"an impossible map fragment"
]

def get_topic():
    return random.choice(TOPICS)
