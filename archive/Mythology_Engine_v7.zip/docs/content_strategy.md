Recommended channel format:

Documentary mystery

Topic buckets:

• impossible artifacts
• vanished expeditions
• forbidden archives
