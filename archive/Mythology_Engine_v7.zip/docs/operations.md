Operations Guide

Run daily generation:
python -m scheduler.daily_run

Batch generation:
python -m scheduler.batch_run 5
