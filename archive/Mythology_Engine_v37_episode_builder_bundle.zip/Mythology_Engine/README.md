# Mythology Engine v37 – Episode Builder

This version adds the first real one-command episode package builder.

## Command

`python tools/build_episode.py "the Piri Reis map"`

## It outputs

- script
- metadata package
- narration artifact
- scene plan
- subtitles
- thumbnail
- render plan
- manifest

## Why this matters

This is where the system starts behaving like a real automated studio.
