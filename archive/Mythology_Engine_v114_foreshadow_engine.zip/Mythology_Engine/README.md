# Mythology Engine v114 – Foreshadow Engine

Adds deliberate clue planting and future reveal tracking.

## Run

python runtime/tools/demo_foreshadow_engine.py

## Output

- planted clue seeds
- open foreshadow threads
- suggested future payoff target
