class ForeshadowSeed:
    def __init__(self, clue, intended_payoff, planted_in_episode=None, reveal_target=None, status="planted"):
        self.clue = clue
        self.intended_payoff = intended_payoff
        self.planted_in_episode = planted_in_episode
        self.reveal_target = reveal_target
        self.status = status

    def to_dict(self):
        return {
            "clue": self.clue,
            "intended_payoff": self.intended_payoff,
            "planted_in_episode": self.planted_in_episode,
            "reveal_target": self.reveal_target,
            "status": self.status
        }
