from foreshadow_engine.storage.foreshadow_store import ForeshadowStore

class ForeshadowEngine:
    def __init__(self):
        self.store = ForeshadowStore()

    def plant_seed(self, seed):
        self.store.add(seed.to_dict())
        return seed.to_dict()

    def list_open_seeds(self):
        return [i for i in self.store.load() if i.get("status") == "planted"]

    def suggest_payoff(self):
        seeds = self.list_open_seeds()
        if not seeds:
            return None
        return seeds[0]

    def resolve_seed(self, clue):
        items = self.store.load()
        resolved = None
        for item in items:
            if item.get("clue") == clue and item.get("status") == "planted":
                item["status"] = "resolved"
                resolved = item
                break
        self.store.update(items)
        return resolved
