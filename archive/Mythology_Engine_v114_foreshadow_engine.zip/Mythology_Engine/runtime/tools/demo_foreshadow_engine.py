from foreshadow_engine.models.foreshadow_seed import ForeshadowSeed
from foreshadow_engine.engines.foreshadow_engine import ForeshadowEngine
import json

engine = ForeshadowEngine()

seed = ForeshadowSeed(
    clue="A strange sigil is visible in the archive vault mural.",
    intended_payoff="The sigil is later revealed to be the seal of the Order of Ash.",
    planted_in_episode="Episode_004",
    reveal_target="Episode_012"
)

engine.plant_seed(seed)

print(json.dumps({
    "open_seeds": engine.list_open_seeds(),
    "suggested_payoff": engine.suggest_payoff()
}, indent=2))
