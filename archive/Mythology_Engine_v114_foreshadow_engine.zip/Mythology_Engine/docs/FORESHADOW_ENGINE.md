# Foreshadow Engine

Tracks clues planted in earlier episodes and their intended future payoff.

## Purpose

Enable long-form myth storytelling by managing:

- hidden clues
- deferred reveals
- symbolic callbacks
- future payoffs

## Why it matters

This is how a channel creates the feeling that:
"everything was connected all along."
