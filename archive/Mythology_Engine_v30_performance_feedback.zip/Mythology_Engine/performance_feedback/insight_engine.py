def generate_insights(report):
    insights=[]

    if report.get("avg_ctr",0) < 0.05:
        insights.append("Titles may be weak. Increase mystery or tension.")
    else:
        insights.append("CTR healthy. Continue similar headline structures.")

    if report.get("avg_watch_time",0) < 60:
        insights.append("Viewers leaving early. Strengthen opening hook.")
    else:
        insights.append("Retention good. Narrative pacing working.")

    return insights
