import json
from statistics import mean

def analyze_metrics(video_records):
    if not video_records:
        return {"status":"no_data"}

    ctrs=[v.get("ctr",0) for v in video_records]
    watch=[v.get("avg_watch_time",0) for v in video_records]

    result={
        "videos_analyzed":len(video_records),
        "avg_ctr":round(mean(ctrs),3),
        "avg_watch_time":round(mean(watch),2)
    }

    # crude signal scoring
    high_ctr=[v["title"] for v in video_records if v.get("ctr",0) > result["avg_ctr"]]
    result["high_performing_titles"]=high_ctr

    return result
