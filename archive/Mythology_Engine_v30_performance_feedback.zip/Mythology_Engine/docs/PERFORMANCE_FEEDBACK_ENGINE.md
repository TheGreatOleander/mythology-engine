# Performance Feedback Engine

Purpose:
Analyze published video metrics and extract learning signals.

Inputs:
- CTR (click-through-rate)
- average watch time
- titles

Outputs:
- channel performance summary
- suggested improvements

Future integrations:

- YouTube analytics API
- automated topic scoring
- title pattern learning
- thumbnail style learning
