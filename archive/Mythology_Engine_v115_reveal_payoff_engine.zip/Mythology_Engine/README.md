# Mythology Engine v115 – Reveal / Payoff Engine

Adds the ability to resolve previously planted foreshadow clues.

## Run

python runtime/tools/demo_reveal_engine.py
