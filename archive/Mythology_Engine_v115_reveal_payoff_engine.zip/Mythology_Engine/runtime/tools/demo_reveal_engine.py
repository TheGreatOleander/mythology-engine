from reveal_engine.models.reveal_event import RevealEvent
from reveal_engine.engines.reveal_engine import RevealEngine
import json

engine = RevealEngine()

reveal = RevealEvent(
    clue="Strange sigil in the archive mural",
    reveal_text="The sigil belonged to the forgotten Order of Ash.",
    episode="Episode_012",
    resolved_from="Episode_004"
)

engine.record_reveal(reveal)

print(json.dumps(engine.list_reveals(), indent=2))
