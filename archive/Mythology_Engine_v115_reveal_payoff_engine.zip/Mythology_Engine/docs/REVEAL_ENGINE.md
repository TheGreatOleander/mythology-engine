# Reveal / Payoff Engine

Handles narrative payoffs to previously planted clues.

## Purpose

Convert foreshadowed seeds into story reveals.

## Example

Episode 4:
A mysterious sigil appears.

Episode 12:
The sigil is revealed as the mark of the Order of Ash.
