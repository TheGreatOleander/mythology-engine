from reveal_engine.storage.reveal_store import RevealStore

class RevealEngine:

    def __init__(self):
        self.store = RevealStore()

    def record_reveal(self, reveal_event):
        self.store.add(reveal_event.to_dict())

    def list_reveals(self):
        return self.store.load()

    def generate_reveal_narrative(self, reveal):
        return f"Earlier we noticed: '{reveal['clue']}'. Now we finally understand: {reveal['reveal_text']}"
