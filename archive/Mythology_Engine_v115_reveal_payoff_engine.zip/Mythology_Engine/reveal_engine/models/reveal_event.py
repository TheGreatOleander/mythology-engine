class RevealEvent:
    def __init__(self, clue, reveal_text, episode=None, resolved_from=None):
        self.clue = clue
        self.reveal_text = reveal_text
        self.episode = episode
        self.resolved_from = resolved_from

    def to_dict(self):
        return {
            "clue": self.clue,
            "reveal_text": self.reveal_text,
            "episode": self.episode,
            "resolved_from": self.resolved_from
        }
