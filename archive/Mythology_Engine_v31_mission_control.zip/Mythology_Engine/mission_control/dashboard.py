import json
from pathlib import Path

def load_json(path):
    p=Path(path)
    if not p.exists():
        return None
    return json.loads(p.read_text())

def show_dashboard():

    print("\n==============================")
    print("MYTHOLOGY ENGINE – MISSION CONTROL")
    print("==============================\n")

    # Trend signals
    trends = load_json("trend_signals.json")
    if trends:
        print("Trend Signals:")
        for t in trends[:5]:
            print(" -",t)
    else:
        print("Trend Signals: none")

    print()

    # Publish queue
    q=Path("publish_queue")
    if q.exists():
        jobs=list(q.glob("*.json"))
        print("Publish Queue:",len(jobs),"jobs")
    else:
        print("Publish Queue: none")

    print()

    # Performance report
    perf=load_json("performance_report.json")
    if perf:
        print("Average CTR:",perf.get("avg_ctr"))
        print("Average Watch Time:",perf.get("avg_watch_time"))
    else:
        print("Performance Data: none")

    print("\n==============================\n")
