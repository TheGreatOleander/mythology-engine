from mission_control.dashboard import show_dashboard

if __name__=="__main__":
    show_dashboard()
