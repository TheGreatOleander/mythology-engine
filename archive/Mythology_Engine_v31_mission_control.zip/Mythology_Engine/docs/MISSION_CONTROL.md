# Mission Control

Mission Control is the operator cockpit for the Mythology Engine.

Purpose:
Give a single view of the system state.

Displays:

- Trend signals
- Story generation activity
- Publish queue
- Channel performance metrics

Two implementations are planned:

1. CLI dashboard (current scaffold)
2. Android control center app

Run:

python tools/mission_control.py
