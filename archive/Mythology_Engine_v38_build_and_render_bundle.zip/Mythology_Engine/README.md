# Mythology Engine v38 – Build + Render

This version introduces a combined episode creation and render attempt.

## Command

python tools/build_and_render_episode.py "the Piri Reis map"

## Pipeline

topic
→ script
→ narration
→ thumbnail
→ scene plan
→ render plan
→ render executor

The renderer currently runs in dry‑run mode for safety.
