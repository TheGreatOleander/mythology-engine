import subprocess
from pathlib import Path

class PiperTTSProvider:

    def __init__(self, model_path="models/en_US-lessac-medium.onnx", piper_binary="piper"):
        self.model = model_path
        self.piper = piper_binary

    def synthesize(self, script_text, output_wav):

        Path(output_wav).parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            self.piper,
            "--model", self.model,
            "--output_file", output_wav
        ]

        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            proc.communicate(script_text.encode("utf-8"))
        except FileNotFoundError:
            # fallback stub if Piper isn't installed
            Path(output_wav).write_text(
                "PIPER NOT INSTALLED — AUDIO PLACEHOLDER\n\n" + script_text,
                encoding="utf-8"
            )

        return output_wav
