import subprocess
from pathlib import Path

class FFmpegRenderer:

    def assemble_video(self, image, audio, output):

        Path(output).parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            "ffmpeg",
            "-y",
            "-loop", "1",
            "-i", image,
            "-i", audio,
            "-c:v", "libx264",
            "-tune", "stillimage",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-pix_fmt", "yuv420p",
            output
        ]

        subprocess.run(cmd, check=False)

        return output
