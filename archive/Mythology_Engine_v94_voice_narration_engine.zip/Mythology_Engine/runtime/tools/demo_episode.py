from runtime.engine.video_episode_engine import EpisodeEngine
import json

script = '''
The Map That Shouldn't Exist

This map may not be possible.

Hidden in a forgotten archive,
researchers discovered markings
that predate known exploration routes.
'''

engine = EpisodeEngine()

result = engine.produce_episode(
    image="examples/input/test_image.png",
    script=script,
    output_dir="examples/output"
)

print(json.dumps(result, indent=2))
