from providers.audio.piper_tts_provider import PiperTTSProvider
from providers.video.ffmpeg_renderer import FFmpegRenderer
from pathlib import Path

class EpisodeEngine:

    def __init__(self):
        self.tts = PiperTTSProvider()
        self.video = FFmpegRenderer()

    def produce_episode(self, image, script, output_dir):

        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        audio_file = str(out / "narration.wav")
        video_file = str(out / "episode.mp4")

        self.tts.synthesize(script, audio_file)

        self.video.assemble_video(
            image,
            audio_file,
            video_file
        )

        return {
            "audio": audio_file,
            "video": video_file
        }
