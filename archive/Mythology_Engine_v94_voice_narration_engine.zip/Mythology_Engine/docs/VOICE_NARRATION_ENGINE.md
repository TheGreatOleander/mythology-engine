# Voice Narration Engine

This module introduces narrated video production.

Pipeline:

script
→ Piper TTS (voice narration)
→ FFmpeg render
→ narrated MP4 output

If Piper is not installed, the system falls back to a stub file so the pipeline still runs.

## Piper

Install example:

    git clone https://github.com/rhasspy/piper
