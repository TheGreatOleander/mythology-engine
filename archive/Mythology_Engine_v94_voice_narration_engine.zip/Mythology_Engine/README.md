# Mythology Engine v94 – Voice Narration Engine

This version introduces automated narration generation.

## Features

- Piper TTS integration scaffold
- narrated episode pipeline
- FFmpeg video assembly

## Run

python runtime/tools/demo_episode.py

## Output

examples/output/

    narration.wav
    episode.mp4
