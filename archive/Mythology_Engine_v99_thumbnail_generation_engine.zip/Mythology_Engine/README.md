# Mythology Engine v99 – Thumbnail Generation Engine

This version introduces automated thumbnail generation.

## Features

- thumbnail concept generator
- image prompt system
- bold text overlays
- FFmpeg overlay helper

## Run

python runtime/tools/demo_thumbnail_engine.py

## Output

examples/output/
   thumbnail_1.png
   thumbnail_2.png
   ...
