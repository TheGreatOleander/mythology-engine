# Thumbnail Generation Engine

This module generates YouTube-style thumbnails automatically.

Pipeline:

topic
→ thumbnail concept generation
→ image generation
→ bold text overlay
→ final thumbnail

This pairs with the Title Engine to optimize click-through rate.
