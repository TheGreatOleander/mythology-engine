from pathlib import Path

def generate_thumbnail_image(prompt, output_path):

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    Path(output_path).write_text(
        "THUMBNAIL IMAGE PLACEHOLDER\n\nprompt=" + prompt,
        encoding="utf-8"
    )

    return output_path
