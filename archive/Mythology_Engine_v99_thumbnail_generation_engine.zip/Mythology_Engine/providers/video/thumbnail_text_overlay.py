import subprocess
from pathlib import Path

def apply_text_overlay(image, text, output):

    Path(output).parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        "ffmpeg",
        "-y",
        "-i", image,
        "-vf", f"drawtext=text='{text}':fontcolor=white:fontsize=60:x=(w-text_w)/2:y=h-120",
        output
    ]

    subprocess.run(cmd, check=False)

    if not Path(output).exists():
        Path(output).write_text(
            "THUMBNAIL WITH TEXT PLACEHOLDER\n"
            + f"image={image}\ntext={text}",
            encoding="utf-8"
        )

    return output
