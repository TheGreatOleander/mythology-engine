class ThumbnailConcept:

    def __init__(self, title, visual_prompt, overlay_text):
        self.title = title
        self.visual_prompt = visual_prompt
        self.overlay_text = overlay_text

    def to_dict(self):
        return {
            "title": self.title,
            "visual_prompt": self.visual_prompt,
            "overlay_text": self.overlay_text
        }
