from thumbnail_engine.models.thumbnail_concept import ThumbnailConcept

def generate_thumbnail_concepts(topic):

    prompts = [
        f"ancient map glowing on wooden table cinematic lighting",
        f"mysterious explorer holding impossible map dramatic shadows",
        f"old parchment map burning edges discovery moment",
        f"archive vault opening revealing ancient document"
    ]

    overlays = [
        "THIS MAP?",
        "IMPOSSIBLE",
        "HIDDEN FOR CENTURIES",
        "HISTORIANS SHOCKED"
    ]

    concepts = []

    for i in range(len(prompts)):
        concepts.append(
            ThumbnailConcept(
                topic,
                prompts[i],
                overlays[i]
            )
        )

    return concepts
