from thumbnail_engine.engines.concept_generator import generate_thumbnail_concepts
from providers.image.thumbnail_image_provider import generate_thumbnail_image
from providers.video.thumbnail_text_overlay import apply_text_overlay
import json

topic = "The Map That Shouldn't Exist"

concepts = generate_thumbnail_concepts(topic)

outputs = []

for i, c in enumerate(concepts, start=1):

    base_img = generate_thumbnail_image(
        c.visual_prompt,
        f"examples/output/thumb_base_{i}.txt"
    )

    final = apply_text_overlay(
        base_img,
        c.overlay_text,
        f"examples/output/thumbnail_{i}.png"
    )

    outputs.append({
        "concept": c.to_dict(),
        "thumbnail": final
    })

print(json.dumps(outputs, indent=2))
