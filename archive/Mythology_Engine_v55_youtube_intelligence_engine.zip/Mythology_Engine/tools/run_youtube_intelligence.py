from youtube_intelligence.engines.intelligence_report import build_report
import json

report = build_report()
print(json.dumps(report, indent=2))
