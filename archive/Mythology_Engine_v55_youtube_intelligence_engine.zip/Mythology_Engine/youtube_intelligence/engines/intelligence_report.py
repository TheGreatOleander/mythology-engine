from youtube_intelligence.engines.signal_collector import collect_all_signals
from youtube_intelligence.engines.topic_ranker import rank_topics

def build_report():
    bundle = collect_all_signals()
    ranked = rank_topics(bundle)

    top_topic = ranked[0][0] if ranked else None

    return {
        "signals": bundle,
        "ranked_topics": ranked,
        "recommended_next_topic": top_topic
    }
