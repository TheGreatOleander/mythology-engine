# YouTube Intelligence Engine

This subsystem turns raw YouTube-adjacent feedback into structured strategic signals.

## Inputs

- comment requests
- audience behavior patterns
- title / CTR pattern hints

## Outputs

- ranked topics
- recommended next episode topic
- reusable creative insights

## Why this matters

This bridges the gap between:

audience reaction
→ learning
→ Channel Brain topic selection

That makes the channel more adaptive and more aware of what viewers actually want.
