# Mythology Engine v55 – YouTube Intelligence Engine

This version adds a YouTube-aware signal analysis layer.

## It can now aggregate:

- comment requests
- behavior patterns
- title / CTR hints

and convert them into:

- ranked topics
- next-topic recommendations
- channel strategy signals

## Run demo

python tools/run_youtube_intelligence.py
