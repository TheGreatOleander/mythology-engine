def build_basic_scene_prompt(topic: str, scene_text: str, visual_type: str) -> str:
    style = "cinematic documentary still, atmospheric lighting, detailed, dramatic composition"
    return f"{visual_type} scene for {topic}, {scene_text}, {style}"
