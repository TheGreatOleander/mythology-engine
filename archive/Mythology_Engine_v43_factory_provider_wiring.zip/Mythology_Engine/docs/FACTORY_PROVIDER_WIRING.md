# Factory Provider Wiring

This version wires the Episode Factory into the provider registry.

## What changed

The factory now uses configured providers for:

- writing
- narration / TTS
- image generation
- publishing

instead of calling hard-coded stubs.

## Why this matters

This is the point where the system starts behaving like a configurable product.

A single repo can now support:

### Local Studio
- local_llm
- piper
- sdxl
- manual publish

### Cloud Studio
- openai
- elevenlabs
- dalle
- youtube

### Hybrid Studio
- openai
- piper
- sdxl
- manual

## Run

`python tools/run_factory_with_providers.py`

Queue a publish preview:

`python tools/run_factory_with_providers.py --queue`
