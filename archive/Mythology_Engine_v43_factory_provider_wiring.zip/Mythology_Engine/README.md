# Mythology Engine v33 – Unified Cinematic Bundle

This version folds the Cinematic Engine back into the main repository so the entire
system remains one coherent project.

## Main subsystems

- story_library
- story_forge
- lore_graph
- narrative_engine
- title_thumbnail_lab
- trend_radar
- performance_feedback
- mission_control
- cinematic_engine
- publishing

## End goal

Generate, review, render, queue, upload, and improve documentary-style YouTube episodes.


## Setup Wizard

This unified bundle now includes a first-run setup flow.

Run:

`python tools/run_setup_wizard.py`

It prompts for local OAuth paths, API keys, provider choices, and channel metadata,
then saves them to:

`secrets/local_secrets.json`

That file is ignored by git so the repo can stay public without leaking secrets.


## Provider Interface Layer

This unified bundle now includes a provider layer for:

- writing
- TTS
- image generation
- publishing

Use:

`python tools/test_provider_layer.py`

to verify the registry and provider selection logic.


## Episode Factory + Provider Registry

The Episode Factory is now wired into the provider registry.

Run:

`python tools/run_factory_with_providers.py`

Queue a publish preview:

`python tools/run_factory_with_providers.py --queue`

This means the unified system now respects configured providers for:
- writing
- TTS
- image generation
- publishing
