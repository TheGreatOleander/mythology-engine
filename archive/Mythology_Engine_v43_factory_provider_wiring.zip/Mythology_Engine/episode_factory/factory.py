import json
from pathlib import Path
from datetime import datetime

from providers.registry import (
    get_writing_provider,
    get_tts_provider,
    get_image_provider,
    get_publish_provider,
)
from title_thumbnail_lab.title_engine import generate_titles
from title_thumbnail_lab.thumbnail_engine import generate_thumbnail_concepts
from trend_radar.radar_engine import scan_trends
from story_forge.forge_engine import build_episode_idea
from cinematic_engine.scene_plan_builder import build_scene_plan
from cinematic_engine.render_plan import write_render_plan
from visual_generation_engine.prompt_helper import build_basic_scene_prompt

EPISODES = Path("episodes")
EPISODES.mkdir(exist_ok=True)

def _choose_topic(trend_result: dict, idea: dict) -> str:
    if trend_result and trend_result.get("trend_topic"):
        return trend_result["trend_topic"]
    return idea.get("topic", "Unknown Mystery")

def run_factory(queue_for_publish: bool = False) -> dict:
    writing = get_writing_provider()
    tts = get_tts_provider()
    image = get_image_provider()
    publish = get_publish_provider()

    trend_result = scan_trends()
    idea = build_episode_idea()
    topic = _choose_topic(trend_result, idea)

    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    ep = EPISODES / f"EP_{stamp}"
    ep.mkdir(parents=True, exist_ok=True)

    script = writing.generate_script(topic)
    (ep / "script.txt").write_text(script, encoding="utf-8")

    titles = generate_titles(topic)
    thumbs = generate_thumbnail_concepts(topic)
    (ep / "thumbnail_concepts.json").write_text(json.dumps(thumbs, indent=2), encoding="utf-8")

    audio_path = str(ep / "narration.wav")
    tts.generate_audio(script, audio_path)

    subtitles = "1\n00:00:00,000 --> 00:00:04,000\nSome discoveries refuse to stay buried.\n"
    (ep / "subtitles.srt").write_text(subtitles, encoding="utf-8")

    scene_plan = build_scene_plan(script)
    (ep / "scene_plan.json").write_text(json.dumps(scene_plan, indent=2), encoding="utf-8")

    generated_assets = []
    assets_dir = ep / "generated_assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    for scene in scene_plan:
        prompt = build_basic_scene_prompt(topic, scene.get("text", ""), scene.get("visual_type", "artifact"))
        asset_path = str(assets_dir / f'scene_asset_{scene["scene_index"]:03d}.png')
        image.generate_image(prompt, asset_path)
        generated_assets.append({
            "scene_index": scene["scene_index"],
            "prompt": prompt,
            "asset": asset_path
        })

    (ep / "generated_assets.json").write_text(json.dumps(generated_assets, indent=2), encoding="utf-8")

    render_plan = write_render_plan(str(ep))

    manifest = {
        "episode_id": ep.name,
        "topic": topic,
        "trend_result": trend_result,
        "story_idea": idea,
        "selected_title": titles[0] if titles else topic,
        "title_options": titles,
        "thumbnail_concepts_file": str(ep / "thumbnail_concepts.json"),
        "script_file": str(ep / "script.txt"),
        "scene_plan_file": str(ep / "scene_plan.json"),
        "generated_assets_file": str(ep / "generated_assets.json"),
        "render_plan_file": render_plan,
        "narration_file": audio_path,
        "subtitles_file": str(ep / "subtitles.srt"),
        "providers_used": {
            "writing": writing.name,
            "tts": tts.name,
            "image": image.name,
            "publish": publish.name,
        },
        "status": "factory_generated"
    }
    (ep / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    queue_job = None
    publish_preview = None

    if queue_for_publish:
        queue_dir = Path("publish_queue")
        queue_dir.mkdir(exist_ok=True)
        job = {
            "episode_id": ep.name,
            "title": manifest["selected_title"],
            "video_path": str(ep / "final_video.mp4"),
            "manifest": str(ep / "manifest.json"),
            "provider": publish.name,
        }
        queue_path = queue_dir / f"{ep.name}_publish_job.json"
        queue_path.write_text(json.dumps(job, indent=2), encoding="utf-8")
        queue_job = str(queue_path)
        publish_preview = publish.upload(
            video_path=str(ep / "final_video.mp4"),
            title=manifest["selected_title"],
            description=f"Automated documentary episode about {topic}.",
            thumbnail_path=None
        )

    return {
        "episode_dir": str(ep),
        "manifest": manifest,
        "queue_job": queue_job,
        "publish_preview": publish_preview
    }
