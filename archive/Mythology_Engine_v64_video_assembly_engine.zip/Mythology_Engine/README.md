# Mythology Engine v64 – Video Assembly Engine

This version adds the finished-video assembly layer.

## What it does

Takes:
- rendered scene clips
- narration audio

Produces:
- final_video.mp4

## Run demo

`python video_assembly/tools/assemble_episode.py`

## Requirement

FFmpeg installed on system.
