# Video Assembly Engine

This module assembles a finished episode video from:

- rendered scene clips
- narration audio

## Flow

scene_manifest.json
→ concat file builder
→ FFmpeg assembler
→ final_video.mp4

## Why it matters

This is the step that turns the system from:
- a scene and asset generator

into:
- a finished-video producer

## Expected inputs

Each scene in the manifest should point to a rendered `.mp4` clip.

## Run

`python video_assembly/tools/assemble_episode.py`

## Requirement

FFmpeg must be installed and available in PATH.
