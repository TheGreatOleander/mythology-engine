from video_assembly.engines.assembly_pipeline import run_assembly
from pathlib import Path
import json

episode_dir = "examples/episode_pack"
audio_file = "examples/episode_pack/narration.wav"
scene_manifest = "examples/episode_pack/scenes/scene_manifest.json"

result = run_assembly(episode_dir, audio_file, scene_manifest)
print(json.dumps(result, indent=2))
