import subprocess

def assemble_video(concat_file, audio_file, output_file):
    cmd = [
        "ffmpeg",
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", concat_file,
        "-i", audio_file,
        "-c:v", "libx264",
        "-c:a", "aac",
        "-pix_fmt", "yuv420p",
        "-shortest",
        output_file
    ]
    subprocess.run(cmd)
    return {
        "command": cmd,
        "output_file": output_file
    }
