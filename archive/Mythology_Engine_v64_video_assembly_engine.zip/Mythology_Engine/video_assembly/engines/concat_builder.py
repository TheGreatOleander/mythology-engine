from pathlib import Path

def build_concat_file(scene_manifest, output_path):
    lines = []
    for item in scene_manifest:
        # expects each item to have a rendered scene video file path
        lines.append(f"file '{item['file']}'")
    out = Path(output_path)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(out)
