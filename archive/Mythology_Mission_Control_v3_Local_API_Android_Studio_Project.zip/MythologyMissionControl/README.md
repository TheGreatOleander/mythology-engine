# Mythology Mission Control v3

Android Studio project scaffold wired toward the local API bridge.

## What changed

This version calls the local bridge endpoints directly:

- GET /health
- POST /generate-episode
- POST /generate-and-queue
- GET /youtube-intelligence

## Required backend

Run the local API bridge from Mythology Engine v60:

`python tools/start_local_api_bridge.py`

Default base URL in the Android app:

`http://127.0.0.1:8765`

## Notes

For real use on Android, you'll likely want to:
- point this at a LAN machine running the engine, or
- run the engine locally in a Termux / embedded environment and adjust networking as needed.
