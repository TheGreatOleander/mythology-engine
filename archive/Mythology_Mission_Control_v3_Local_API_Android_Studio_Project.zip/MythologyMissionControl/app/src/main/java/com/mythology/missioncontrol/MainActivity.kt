package com.mythology.missioncontrol

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var txtStatus: TextView
    private lateinit var txtConsole: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txtHeaderStatus)
        txtConsole = findViewById(R.id.txtConsole)

        val btnHealth = findViewById<Button>(R.id.btnHealth)
        val btnGenerate = findViewById<Button>(R.id.btnGenerateEpisode)
        val btnQueue = findViewById<Button>(R.id.btnGenerateAndQueue)
        val btnIntel = findViewById<Button>(R.id.btnYouTubeIntel)

        txtStatus.text = "Awaiting local API bridge"

        btnHealth.setOnClickListener {
            callApi("GET /health") { LocalApiClient.get("/health") }
        }

        btnGenerate.setOnClickListener {
            callApi("POST /generate-episode") { LocalApiClient.post("/generate-episode") }
        }

        btnQueue.setOnClickListener {
            callApi("POST /generate-and-queue") { LocalApiClient.post("/generate-and-queue") }
        }

        btnIntel.setOnClickListener {
            callApi("GET /youtube-intelligence") { LocalApiClient.get("/youtube-intelligence") }
        }
    }

    private fun callApi(label: String, request: () -> String) {
        txtStatus.text = "Calling $label ..."
        txtConsole.text = "Working..."
        thread {
            try {
                val result = request()
                runOnUiThread {
                    txtStatus.text = "Success: $label"
                    txtConsole.text = result
                }
            } catch (e: Exception) {
                runOnUiThread {
                    txtStatus.text = "Error: $label"
                    txtConsole.text = e.stackTraceToString()
                }
            }
        }
    }
}
