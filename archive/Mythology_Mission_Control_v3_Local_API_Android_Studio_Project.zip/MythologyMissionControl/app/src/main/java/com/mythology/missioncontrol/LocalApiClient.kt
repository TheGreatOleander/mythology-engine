package com.mythology.missioncontrol

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object LocalApiClient {
    private const val DEFAULT_BASE_URL = "http://127.0.0.1:8765"

    fun get(path: String, baseUrl: String = DEFAULT_BASE_URL): String {
        val url = URL(baseUrl + path)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        return connection.inputStream.use { input ->
            BufferedReader(InputStreamReader(input)).readText()
        }
    }

    fun post(path: String, baseUrl: String = DEFAULT_BASE_URL): String {
        val url = URL(baseUrl + path)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.doOutput = true
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        return connection.inputStream.use { input ->
            BufferedReader(InputStreamReader(input)).readText()
        }
    }
}
