# Meta Story Engine

Tracks persistent mythology elements across the channel.

Stores:

- artifacts
- characters
- mystery threads

API:

POST /init-meta-story
GET /meta-story

This allows the Mythology Engine to maintain narrative continuity
across episodes and platforms.
