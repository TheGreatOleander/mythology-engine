from meta_story_engine.storage.lore_store import load, save

def register_artifact(name, description):

    data = load()

    artifact = {
        "name": name,
        "description": description,
        "references": []
    }

    data["artifacts"].append(artifact)
    save(data)

    return artifact
