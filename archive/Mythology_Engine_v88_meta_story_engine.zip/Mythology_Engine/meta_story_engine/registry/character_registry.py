from meta_story_engine.storage.lore_store import load, save

def register_character(name, role):

    data = load()

    character = {
        "name": name,
        "role": role,
        "appearances": []
    }

    data["characters"].append(character)
    save(data)

    return character
