class Artifact:

    def __init__(self, name, description, first_seen_episode=None):
        self.name = name
        self.description = description
        self.first_seen_episode = first_seen_episode
        self.references = []

    def add_reference(self, episode):
        self.references.append(episode)

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "first_seen_episode": self.first_seen_episode,
            "references": self.references
        }
