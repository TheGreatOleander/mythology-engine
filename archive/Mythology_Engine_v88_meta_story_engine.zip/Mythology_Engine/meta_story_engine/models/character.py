class Character:

    def __init__(self, name, role):
        self.name = name
        self.role = role
        self.appearances = []

    def add_appearance(self, episode):
        self.appearances.append(episode)

    def to_dict(self):
        return {
            "name": self.name,
            "role": self.role,
            "appearances": self.appearances
        }
