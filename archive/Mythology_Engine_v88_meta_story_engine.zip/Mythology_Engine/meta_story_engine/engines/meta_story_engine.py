from meta_story_engine.registry.artifact_registry import register_artifact
from meta_story_engine.registry.character_registry import register_character
from meta_story_engine.storage.lore_store import load

def initialize_meta_story():

    register_artifact(
        "The Cantus Map",
        "A mysterious parchment map that appears to predate known cartography."
    )

    register_character(
        "The Archivist",
        "A mysterious historian who appears across episodes."
    )

    return load()
