import json
from pathlib import Path

STORE = Path("examples/meta_story/lore.json")

def load():
    if STORE.exists():
        return json.loads(STORE.read_text())
    return {
        "artifacts":[],
        "characters":[],
        "mysteries":[]
    }

def save(data):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(data, indent=2))
