from meta_story_engine.engines.meta_story_engine import initialize_meta_story
from meta_story_engine.storage.lore_store import load

def init_story_service():
    return initialize_meta_story()

def get_story_service():
    return load()
