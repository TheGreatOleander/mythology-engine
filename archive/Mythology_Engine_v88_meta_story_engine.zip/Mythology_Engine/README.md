# Mythology Engine v88 – Meta Story Engine

Adds narrative continuity to the studio system.

Tracks:

- artifacts
- characters
- mysteries

Endpoints:

POST /init-meta-story
GET /meta-story

This layer gives the Mythology Engine a persistent mythology.
