import urllib.request, json

BASE="http://127.0.0.1:8765"

req = urllib.request.Request(BASE + "/init-meta-story", method="POST")

with urllib.request.urlopen(req) as r:
    print("INIT:", json.dumps(json.loads(r.read().decode()), indent=2))

with urllib.request.urlopen(BASE + "/meta-story") as r:
    print("LORE:", json.dumps(json.loads(r.read().decode()), indent=2))
