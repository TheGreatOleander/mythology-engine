def score_title(candidate):

    score = 0
    text = candidate.title.lower()

    if "secret" in text: score += 2
    if "impossible" in text: score += 2
    if "hidden" in text: score += 1
    if "history" in text: score += 1
    if "discovery" in text: score += 1

    candidate.score = score
    return candidate
