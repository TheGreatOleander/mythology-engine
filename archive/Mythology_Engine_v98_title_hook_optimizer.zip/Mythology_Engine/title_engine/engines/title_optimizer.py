from title_engine.engines.title_generator import generate_titles
from title_engine.engines.title_scorer import score_title

def optimize_titles(topic):

    candidates = generate_titles(topic, 8)
    scored = [score_title(c) for c in candidates]

    scored.sort(key=lambda x: x.score, reverse=True)

    return scored
