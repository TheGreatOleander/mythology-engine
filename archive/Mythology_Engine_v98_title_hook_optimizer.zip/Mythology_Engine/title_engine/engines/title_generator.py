from title_engine.data.hook_templates import HOOK_TEMPLATES
from title_engine.models.title_candidate import TitleCandidate
import random

def generate_titles(topic, n=5):

    candidates = []

    for _ in range(n):
        hook = random.choice(HOOK_TEMPLATES)
        title = f"{topic} — {hook}"

        candidates.append(
            TitleCandidate(title, hook)
        )

    return candidates
