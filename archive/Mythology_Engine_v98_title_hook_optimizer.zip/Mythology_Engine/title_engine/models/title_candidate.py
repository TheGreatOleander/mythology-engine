class TitleCandidate:

    def __init__(self, title, hook, score=0):
        self.title = title
        self.hook = hook
        self.score = score

    def to_dict(self):
        return {
            "title": self.title,
            "hook": self.hook,
            "score": self.score
        }
