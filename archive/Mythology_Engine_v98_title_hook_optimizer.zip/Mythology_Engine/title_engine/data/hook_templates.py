HOOK_TEMPLATES = [
    "This Shouldn't Exist…",
    "Historians Can't Explain This",
    "The Discovery That Changes Everything",
    "They Tried to Hide This From History",
    "The Map That Should Be Impossible",
    "No One Was Supposed to Find This",
    "The Secret Buried for Centuries",
]
