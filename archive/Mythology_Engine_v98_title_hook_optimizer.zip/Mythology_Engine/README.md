# Mythology Engine v98 – Title & Hook Optimization Engine

This version introduces automated title and hook generation.

## Features

- hook template system
- title candidate generation
- engagement heuristic scoring
- ranked output

## Run

python runtime/tools/demo_title_optimizer.py

## Output

Ranked list of title candidates.
