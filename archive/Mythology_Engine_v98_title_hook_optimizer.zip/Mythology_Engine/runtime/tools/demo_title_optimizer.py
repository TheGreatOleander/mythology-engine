from title_engine.engines.title_optimizer import optimize_titles
import json

topic = "The Map That Shouldn't Exist"

results = optimize_titles(topic)

print(json.dumps(
    [r.to_dict() for r in results],
    indent=2
))
