# Mythology Engine v116 – Myth Arc Engine

Adds structured multi-episode arc management to the mythology system.

## Run

python runtime/tools/demo_myth_arc_engine.py

## Output

- stored arcs
- active arc list
- suggested next arc
