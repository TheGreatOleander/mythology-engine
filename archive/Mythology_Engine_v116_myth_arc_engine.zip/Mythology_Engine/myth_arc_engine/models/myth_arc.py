class MythArc:
    def __init__(self, name, theme, episodes, status="planned", description=""):
        self.name = name
        self.theme = theme
        self.episodes = episodes
        self.status = status
        self.description = description

    def to_dict(self):
        return {
            "name": self.name,
            "theme": self.theme,
            "episodes": self.episodes,
            "status": self.status,
            "description": self.description
        }
