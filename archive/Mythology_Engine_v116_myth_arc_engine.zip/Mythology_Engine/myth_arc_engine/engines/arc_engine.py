from myth_arc_engine.storage.arc_store import ArcStore

class MythArcEngine:
    def __init__(self):
        self.store = ArcStore()

    def create_arc(self, arc):
        self.store.add(arc.to_dict())
        return arc.to_dict()

    def list_arcs(self):
        return self.store.load()

    def get_active_arcs(self):
        return [a for a in self.store.load() if a.get("status") in ("planned", "active")]

    def suggest_next_arc(self):
        active = self.get_active_arcs()
        if active:
            return active[0]
        return None
