from pathlib import Path
import json

class ArcStore:
    def __init__(self, path="examples/arcs/arc_database.json"):
        self.path = Path(path)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def load(self):
        return json.loads(self.path.read_text(encoding="utf-8"))

    def save(self, items):
        self.path.write_text(json.dumps(items, indent=2), encoding="utf-8")

    def add(self, item):
        items = self.load()
        items.append(item)
        self.save(items)
