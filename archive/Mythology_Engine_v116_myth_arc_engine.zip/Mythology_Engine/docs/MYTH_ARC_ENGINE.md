# Myth Arc Engine

Tracks multi-episode mythology arcs across the channel.

## Purpose

Provide a layer above single episodes so the system can think in terms of:

- saga structures
- thematic seasons
- multi-part investigations
- long-form myth progression

## Why it matters

This is the difference between:
- making episodes

and:
- building a mythology that unfolds in movements
