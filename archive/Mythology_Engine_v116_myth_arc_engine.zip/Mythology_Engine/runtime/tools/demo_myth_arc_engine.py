from myth_arc_engine.models.myth_arc import MythArc
from myth_arc_engine.engines.arc_engine import MythArcEngine
import json

engine = MythArcEngine()

arc = MythArc(
    name="The Archive Cycle",
    theme="forbidden knowledge sealed beneath forgotten stone",
    episodes=[
        "Episode_001: The Impossible Map",
        "Episode_002: Sealing of the Archive",
        "Episode_003: The Sigil on the Wall",
        "Episode_004: Whisper of the Order",
        "Episode_005: What Was Hidden"
    ],
    status="planned",
    description="A foundational arc introducing the Hidden Archive, the map, and the first signs of the Order of Ash."
)

engine.create_arc(arc)

print(json.dumps({
    "all_arcs": engine.list_arcs(),
    "suggested_next_arc": engine.suggest_next_arc()
}, indent=2))
